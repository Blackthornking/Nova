# Anchor-proof fix in the LUMA-X research branch

## Vulnerability in the earlier reference verifier

A Merkle inclusion path only binds a leaf to the root provided to the verifier. If the verifier does not independently confirm that this root was committed by the active canonical chain, a prover can select an arbitrary self-consistent tree and the path is not a valid chain-membership statement.

The earlier Python model checked inclusion against the witness-supplied `root` but did not confirm that this root was part of its canonical root history.

## Implemented research fix

- `LumaReferenceAccumulator` registers every root with the exact committed block count that produced it.
- A witness now carries that anchor block count. Verification rejects an unknown root or count mismatch.
- The output block must be earlier than the anchor snapshot; the root path uses the prefix snapshot, not an arbitrary root.
- The block descriptor, output record, output count, parent hash and fixed local/global path depths are validated.
- After a simulated chain reorg, the accumulator is rebuilt from active blocks; an anchor from the orphaned branch is not registered and is rejected.
- Rust `CanonicalAnchorRegistry` is a host-side counterpart candidate that checks chain tag, known root, future/staleness, contiguous heights and parent-hash links, with a reorg truncation hook.

## Critical production boundary

The Rust registry's `from_trusted_checkpoint` method trusts its input checkpoint. A production daemon must source that checkpoint and all subsequent roots from Nerva's authenticated active-chain database, and atomically update root and nullifier state when blocks connect/disconnect. This reference registry is not currently connected to the C++ chain database or transaction validation. The Rust source has not been compiled in this environment. Do not treat this as a production security fix until the full chain integration and independent review are complete.
