# Nerva integration boundary and required work

The crate remains isolated from Nerva's C++ daemon and wallet. v0.3 fixes two
research-layer problems: public output leaves are now computable from public
commitments, and anchor roots must be matched to a canonical-chain registry.
These fixes do **not** complete integration.

## Required production chain flow

1. The C++ chain database derives the exact accumulator root associated with each
   canonical block and persists it under `(network, block_hash, height, root)`
   with atomic undo information. A transaction must not supply an authoritative
   root of its own.
2. Before cryptographic verification, the node validates that the public root is
   registered on the active chain, not above the spending height, and inside the
   protocol's allowed anchor-age window. Reorg handling must invalidate orphaned
   roots atomically with spent-nullifier undo.
3. The node recomputes the ordered public transaction digest from the parsed
   transaction bytes; it never accepts a digest selected by the prover.
4. It verifies the compressed proof against those exact public inputs, then checks
   nullifier uniqueness, fee policy, output rules, unlock semantics and all Nerva
   consensus invariants not covered by the proof.
5. Mempool admission, block connection, disconnect/reorg, database recovery, RPC,
   P2P, wallet scanning and legacy transaction handling all use the same versioned
   transaction decoder and verifier outcome.

## Not implemented

No Rust-to-C++ FFI, Nerva `transaction` type, wire serialization, proof bytes
format, database schema, chain-index persistence, nullifier transaction, wallet,
receiver scanning, network activation or hard-fork rule has been added. The
`CanonicalAnchorRegistry` is a tested-in-source reference model, not connected to
`Blockchain` or backed by Nerva's canonical chain DB. Its checkpoint must only be
loaded from an independently authenticated canonical database.

The public output schema and Poseidon domain tags changed in v0.3. It is not wire
compatible with v0.2. Any later protocol version must freeze canonical field
serialization, tree layout, leaf format and transaction serialization before
consensus activation.

## Minimum release gates

- `cargo fmt --check`, `cargo test --release`, clippy and CI on pinned toolchain.
- Differential host/circuit hash test vectors and adversarial constraint tests.
- Cryptographic review of the hash parameter set, ownership relation, nullifiers,
  commitments, batch digest, proof system and key lifecycle.
- Persistent tree/root integration with deterministic rebuild and reorg tests.
- End-to-end daemon + wallet tests, transaction serialization fuzzing, consensus
  mutation tests and cross-platform replay vectors.
- Benchmarks for proof generation, compressed batch-proof verification, transaction
  throughput, memory, proof size, sync/reindex performance and denial-of-service
  resistance on pinned hardware.
- Independent privacy analysis and third-party audit before any testnet activation.

Keep LUMA-X disabled in consensus until every release gate has passed.
