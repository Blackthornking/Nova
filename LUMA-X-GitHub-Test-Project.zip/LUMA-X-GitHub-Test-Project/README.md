# LUMA-X Rust Proof Backend — GitHub Test Project

**Experimental cryptography research only. Not integrated into Nerva consensus. Do not use with real funds.**

This repository is packaged to let GitHub Actions attempt the milestone that could not be completed in the authoring environment: compile the actual Rust/Nova backend, execute recursive proof tests, create a compressed proof, and measure repeated compressed-proof verification.

## Upload to GitHub

1. Create a new empty GitHub repository (for example `luma-x-proof-backend-test`).
2. Extract this ZIP on your computer.
3. Upload the *contents* of the extracted folder to the repository root, including the hidden `.github` folder. Alternatively, use Git:

   ```bash
   git init
   git add .
   git commit -m "Add LUMA-X proof backend test harness"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
   git push -u origin main
   ```

4. Open **Actions** in the repository. The workflow `LUMA-X Rust proof backend` runs automatically on push and pull requests. It can also be started manually with **Run workflow**.
5. Open the `compressed-proof-benchmark` job and download the `luma-x-compressed-proof-benchmark` artifact to get the raw timing log.

## Run locally

Install the current stable Rust toolchain, then run from the repository root:

```bash
cargo fmt --all -- --check
cargo test --release --no-run
RUST_TEST_THREADS=1 cargo test --release -- --nocapture
cargo clippy --release --all-targets -- -D warnings
LUMA_VERIFY_ITERS=20 cargo run --release
```

The benchmark builds public parameters and a synthetic recursive batch, generates one compressed proof, warms up verification, and times repeated calls to the actual Nova/Spartan `CompressedSNARK::verify` method. The reported unit is **compressed batch proofs per second**, not individual transactions per second. Setup/proof generation are outside the timed verification loop, but the end-to-end run still performs them before timing.

Set `LUMA_VERIFY_ITERS` to increase repeat count, for example `100` or `500`. Longer runs produce more stable estimates but consume more CPU time.

## What the workflow tests

- Rust compilation of the actual Nova proof backend.
- Unit tests for valid recursive proof construction and malformed witness rejection.
- Anchor registry checks for root substitution, chain tag, height, parent continuity and reorganisation truncation.
- End-to-end recursive proof verification and compressed proof verification.
- Repeated compressed proof verification benchmark, with public output checked on every iteration.
- Rust formatting and Clippy linting.

## Critical limitations

- The authoring environment had no `cargo` or `rustc`, so this code has **not** been locally compiled. A successful GitHub Actions run is still required; do not assume it will pass until you inspect the run.
- The anchor registry is a host-side reference model seeded from a trusted checkpoint. It is not wired to Nerva's canonical chain database, persistent accumulator state, mempool, nullifier database or reorganisation logic.
- This circuit does not preserve Nerva's existing ring-signature/RingCT transaction model and does not provide a production wallet, output encryption or scanning.
- Synthetic test data does not establish cryptographic soundness, privacy, resistance to side channels, production performance, or consensus compatibility.
- A benchmark result is specific to the GitHub runner hardware and software version. Record runner type, Rust version, commit SHA, proof step count and iteration count when comparing results.

**Do not activate this in Nerva mainnet consensus or use it with real funds.** The correct next step after CI passes is independent circuit review, fuzzing/property tests, integration design and reproducible benchmarking—not immediate mainnet activation.
