# LUMA-X v0.6 security, privacy, integration and speed review

Date: 2026-10-19

## Executive result

**Partial research fixes implemented; full Nerva integration not complete.** The strongest concrete result is a corrected anchor-proof reference model with expanded adversarial tests. The Rust proof source now includes a canonical-anchor registry model and a leaf schema that is reconstructible from public output fields. It is still uncompiled, not connected to Nerva consensus, and not ready for testnet or mainnet funds.

## Findings fixed in the research code

### Anchor proof / root binding

A Merkle path only establishes that a leaf matches a root supplied by the verifier; it does not prove that this root is part of the active chain. The Python reference verifier previously did not check its witness root against a canonical root registry. It now requires the root to be known at the exact claimed anchor block count, requires the spent output block to be included by that snapshot, enforces fixed tree path depths, compares the witness output and parent link to canonical block state, and rejects orphaned roots after simulated reorg rollback.

The Rust backend now has `CanonicalAnchorRegistry`. This is a host-side reference candidate, not an accumulator proof itself. Its checkpoint constructor deliberately assumes its input was independently authenticated by the chain database. The registry must be wired to active canonical chain state before a node can safely use it.

### Public output leaf construction

The older circuit computed the accumulator leaf from hidden owner/serial fields. A normal node cannot construct that leaf from a public transaction if those fields are hidden. The revised relation hashes the public output commitment and public unlock height into the accumulator leaf; the circuit proves the hidden owner/serial/amount/blinding open the commitment.

### Public output metadata

Recipient tags and output serials were removed from the `PublicOutput` public structure and transaction digest; commitments and unlock height remain public. This reduces direct metadata exposure but does not provide a production receiver-scanning/address scheme.

## Executed validation

| Check | Result |
|---|---|
| Python accumulator/state-model tests | **30/30 passed** |
| Arbitrary self-chosen anchor root | Rejected by the Python model |
| Mismatched anchor-height/root pair | Rejected by the Python model |
| Output block newer than selected anchor | Rejected |
| Tampered parent link | Rejected |
| Anchor from discarded branch after reorg | Rejected |
| Rust formatting/compilation/tests | Not run: Rust toolchain unavailable |
| Nerva CMake configure | Failed: missing submodule contents and required Boost libraries |
| Actual Nova/Spartan proof verification/sec | Not measured |
| Privacy/security audit by independent reviewer | Not performed |

## Speed

Latest structural benchmark rerun: 2.239 million cached local membership checks/sec with three threads (2.501 million/sec with two threads) for a synthetic one-million-output SHA-256 model, with an authenticated outer anchor reused across multiple local checks. A prior run measured 2.712 million/sec, so the result varies with runtime scheduling. This is **not** zero-knowledge proof verification, not proof-generation speed, and not Nerva transaction throughput. Actual cryptographic throughput remains unknown until Rust builds and runs a compressed Nova/Spartan proof.

## Highest-priority remaining blockers

1. Get the Rust crate building under a pinned toolchain; run `cargo fmt --check`, `cargo test --release`, clippy and the repeated `CompressedSNARK::verify` benchmark.
2. Differential-test host hashing against in-circuit hashing, including all domain tags, field encoding, tree leaf generation, public digest serialization and malformed inputs.
3. Connect canonical anchor roots and the accumulator to Nerva's actual block database with deterministic persistence, reorg undo, pruning and checkpoint policy.
4. Implement a versioned Nerva transaction type, proof wire serialization, public-input reconstruction, mempool/block validation hooks and a reviewed hard-fork activation path. Existing consensus remains unchanged.
5. Replace prototype owner tags with a properly reviewed curve/address scheme and implement private receiver scanning, encrypted output metadata, wallet recovery and hardware-wallet support.
6. Implement full Nerva transaction/consensus behavior: multi-inputs, variable outputs, RingCT, fees, amounts, unlock_time timestamp semantics, coinbase maturity, emission/burn rules and all overflow cases.
7. Conduct constraint-system soundness review, nullifier/replay analysis, timing/side-channel and denial-of-service tests, serialization fuzzing, reorg/fork tests and an independent cryptographic audit.
8. Benchmark full proof generation and verification, batch sizes, proof sizes, peak RAM, verification CPU, transaction throughput, syncing and reindexing against a pinned baseline.

## Safety decision

Do not enable this implementation for consensus or real funds. The Rust proof system itself and its changed relation have not been compiler-tested here; the host anchor registry is not connected to Nerva's chain database; and key/address, wallet, transaction encoding, and hard-fork integration are incomplete. The existing Nerva code remains unchanged by design rather than silently accepting an experimental privacy proof.
