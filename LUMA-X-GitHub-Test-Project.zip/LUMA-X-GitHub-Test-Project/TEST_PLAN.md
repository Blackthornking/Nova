# Validation plan and result interpretation

## Required CI gates

1. `cargo fmt --all -- --check` must pass.
2. `cargo test --release --no-run` must compile the library, binary and tests.
3. `cargo test --release -- --nocapture` must pass all tests.
4. `cargo clippy --release --all-targets -- -D warnings` must pass.
5. The benchmark job must finish and log `PASS: recursive proof and compressed verification both matched expected state` plus `compressed ZK batch-proof verification benchmark: ... batch proofs/sec`.

If compilation fails, the benchmark is not measured. If any test fails, do not treat the benchmark as valid. Save the complete Actions logs and the commit SHA for debugging/reproducibility.

## Security scope

Passing tests demonstrate only that the implemented prototype behaves as tested. They do not constitute a formal security proof or independent audit. Specific remaining review areas include constraint completeness, public/private input separation, range and overflow semantics, nullifier uniqueness, chain-root authentication, reorganisation atomicity, domain separation, side-channel behaviour, and compatibility with Nerva's actual consensus rules.
