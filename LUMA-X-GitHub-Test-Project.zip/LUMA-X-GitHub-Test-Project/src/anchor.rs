//! Host-side canonical-anchor registry for the experimental LUMA-X backend.
//!
//! A Merkle membership path only proves membership relative to a root chosen by
//! the prover. It does NOT prove that the root belongs to the active chain.
//! Consensus must first authenticate the root against its canonical block DB,
//! then pass that exact root as the public input to proof verification.
//!
//! This reference registry models that host-side requirement. Production Nerva
//! integration must source checkpoints and descendants from the active chain
//! database and must undo/truncate this index during reorganisation handling.

use ff::PrimeField;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct AnchorRecord<F: PrimeField> {
    pub height: u64,
    pub chain_tag: F,
    pub accumulator_root: F,
    pub block_hash: [u8; 32],
    pub parent_hash: [u8; 32],
}

#[derive(Clone, Debug)]
pub struct CanonicalAnchorRegistry<F: PrimeField> {
    chain_tag: F,
    records: Vec<AnchorRecord<F>>,
}

impl<F: PrimeField> CanonicalAnchorRegistry<F> {
    pub fn new(chain_tag: F) -> Self {
        Self {
            chain_tag,
            records: Vec::new(),
        }
    }

    /// Seed the registry from a checkpoint already authenticated by the node's
    /// active-chain database. This function does not itself authenticate a
    /// checkpoint; the caller is responsible for that trust boundary.
    pub fn from_trusted_checkpoint(
        chain_tag: F,
        checkpoint: AnchorRecord<F>,
    ) -> Result<Self, &'static str> {
        if checkpoint.chain_tag != chain_tag {
            return Err("checkpoint chain tag mismatch");
        }
        let mut registry = Self::new(chain_tag);
        registry.records.push(checkpoint);
        Ok(registry)
    }

    /// Append the next canonical record. Height and parent linkage are checked
    /// so records cannot silently cross a fork or skip a block.
    pub fn append(&mut self, record: AnchorRecord<F>) -> Result<(), &'static str> {
        if record.chain_tag != self.chain_tag {
            return Err("anchor chain tag mismatch");
        }
        if self.records.iter().any(|r| r.accumulator_root == record.accumulator_root) {
            return Err("duplicate accumulator root");
        }
        match self.records.last() {
            Some(previous) => {
                if previous.height.checked_add(1) != Some(record.height) {
                    return Err("non-contiguous anchor height");
                }
                if previous.block_hash != record.parent_hash {
                    return Err("anchor parent hash mismatch");
                }
            }
            None => {
                if record.height != 0 || record.parent_hash != [0u8; 32] {
                    return Err("first anchor must be genesis when no checkpoint is loaded");
                }
            }
        }
        self.records.push(record);
        Ok(())
    }

    /// Remove anchors from a discarded branch. The caller should invoke this
    /// as part of the same atomic reorganisation transition as nullifier undo.
    pub fn truncate_after(&mut self, height: u64) {
        self.records.retain(|record| record.height <= height);
    }

    /// Verify that the exact public root and chain tag are anchored in the
    /// canonical registry, are not from the future, and satisfy the configured
    /// maximum anchor age. `spend_height` is the block height for this spend.
    pub fn validate_anchor(
        &self,
        root: F,
        chain_tag: F,
        spend_height: u64,
        max_anchor_age: u64,
    ) -> bool {
        if chain_tag != self.chain_tag {
            return false;
        }
        let Some(record) = self.records.iter().rev().find(|r| r.accumulator_root == root) else {
            return false;
        };
        if record.chain_tag != chain_tag || record.height > spend_height {
            return false;
        }
        spend_height - record.height <= max_anchor_age
    }

    pub fn anchor_height(&self, root: F) -> Option<u64> {
        self.records
            .iter()
            .find(|record| record.accumulator_root == root)
            .map(|record| record.height)
    }

    pub fn len(&self) -> usize {
        self.records.len()
    }

    pub fn is_empty(&self) -> bool {
        self.records.is_empty()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nova_snark::provider::PallasEngine;
    use nova_snark::traits::Engine;

    type F = <PallasEngine as Engine>::Scalar;

    fn record(height: u64, root: u64, block: u8, parent: u8, chain: F) -> AnchorRecord<F> {
        AnchorRecord {
            height,
            chain_tag: chain,
            accumulator_root: F::from(root),
            block_hash: [block; 32],
            parent_hash: [parent; 32],
        }
    }

    #[test]
    fn exact_canonical_anchor_is_accepted() {
        let chain = F::from(7u64);
        let checkpoint = record(10, 100, 10, 9, chain);
        let registry = CanonicalAnchorRegistry::from_trusted_checkpoint(chain, checkpoint).unwrap();
        assert!(registry.validate_anchor(F::from(100u64), chain, 11, 10));
        assert_eq!(registry.anchor_height(F::from(100u64)), Some(10));
    }

    #[test]
    fn arbitrary_root_chain_tag_future_and_stale_anchor_are_rejected() {
        let chain = F::from(7u64);
        let checkpoint = record(10, 100, 10, 9, chain);
        let registry = CanonicalAnchorRegistry::from_trusted_checkpoint(chain, checkpoint).unwrap();
        assert!(!registry.validate_anchor(F::from(999u64), chain, 11, 10));
        assert!(!registry.validate_anchor(F::from(100u64), F::from(8u64), 11, 10));
        assert!(!registry.validate_anchor(F::from(100u64), chain, 9, 10));
        assert!(!registry.validate_anchor(F::from(100u64), chain, 30, 10));
    }

    #[test]
    fn append_requires_parent_chain_link_and_contiguous_height() {
        let chain = F::from(7u64);
        let checkpoint = record(10, 100, 10, 9, chain);
        let mut registry = CanonicalAnchorRegistry::from_trusted_checkpoint(chain, checkpoint).unwrap();
        assert!(registry.append(record(11, 101, 11, 10, chain)).is_ok());
        assert!(registry.append(record(12, 102, 12, 99, chain)).is_err());
        assert!(registry.append(record(13, 103, 13, 11, chain)).is_err());
    }

    #[test]
    fn reorg_truncation_removes_orphaned_anchor() {
        let chain = F::from(7u64);
        let checkpoint = record(10, 100, 10, 9, chain);
        let mut registry = CanonicalAnchorRegistry::from_trusted_checkpoint(chain, checkpoint).unwrap();
        registry.append(record(11, 101, 11, 10, chain)).unwrap();
        registry.append(record(12, 102, 12, 11, chain)).unwrap();
        registry.truncate_after(11);
        assert!(registry.validate_anchor(F::from(101u64), chain, 11, 10));
        assert!(!registry.validate_anchor(F::from(102u64), chain, 12, 10));
        assert_eq!(registry.len(), 2);
    }
}
