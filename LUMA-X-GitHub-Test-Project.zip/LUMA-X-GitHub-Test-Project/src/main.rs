use luma_x_proof_backend::{
    anchor::{AnchorRecord, CanonicalAnchorRegistry}, demo_batch, expected_final_state, initial_state,
};
use nova_snark::{
    nova::{CompressedSNARK, PublicParams, RecursiveSNARK},
    provider::{ipa_pc, PallasEngine, VestaEngine},
    spartan::snark::RelaxedR1CSSNARK,
    traits::{Engine, snark::RelaxedR1CSSNARKTrait},
};
use std::time::Instant;

type E1 = PallasEngine;
type E2 = VestaEngine;
type F = <E1 as Engine>::Scalar;
type C = luma_x_proof_backend::LumaSpendStep<F>;
type EE1 = ipa_pc::EvaluationEngine<E1>;
type EE2 = ipa_pc::EvaluationEngine<E2>;
type S1 = RelaxedR1CSSNARK<E1, EE1>;
type S2 = RelaxedR1CSSNARK<E2, EE2>;

fn main() {
    println!("LUMA-X v0.3 recursive spend-proof demonstration");
    println!("WARNING: research prototype only; not Nerva-compatible or safe for funds");

    let (root, chain_tag, height, steps, transactions) = demo_batch::<F>();
    // This is a synthetic trusted checkpoint for the demo. A production daemon
    // must construct/maintain this registry from its canonical block database.
    let registry = CanonicalAnchorRegistry::from_trusted_checkpoint(
        chain_tag,
        AnchorRecord {
            height: height.saturating_sub(1),
            chain_tag,
            accumulator_root: root,
            block_hash: [0x42; 32],
            parent_hash: [0x41; 32],
        },
    ).expect("synthetic trusted checkpoint");
    assert!(registry.validate_anchor(root, chain_tag, height, 2), "non-canonical anchor root");
    assert!(!registry.validate_anchor(F::from(123456u64), chain_tag, height, 2), "arbitrary root accepted");
    let z0 = initial_state(root, chain_tag, height);
    let shape = steps[0].clone();

    let start = Instant::now();
    let pp = PublicParams::<E1, E2, C>::setup(&shape, &*S1::ck_floor(), &*S2::ck_floor())
        .expect("Nova public-parameter setup failed");
    println!("public-parameter setup: {:?}", start.elapsed());

    let mut recursive = RecursiveSNARK::<E1, E2, C>::new(&pp, &shape, &z0)
        .expect("recursive proof initialization failed");
    for (index, step) in steps.iter().enumerate() {
        let start = Instant::now();
        recursive.prove_step(&pp, step).expect("valid spend step failed");
        println!("prove spend step {index}: {:?}", start.elapsed());
    }

    let expected = expected_final_state(root, chain_tag, height, &transactions);
    let recursive_out = recursive.verify(&pp, steps.len(), &z0)
        .expect("recursive proof verification failed");
    assert_eq!(recursive_out, expected, "public transaction digest binding failed");
    println!("recursive proof verified and public transaction batch digest matched");

    // The IPA evaluation engines used below are transparent; no KZG powers-of-
    // tau ceremony is required for this backend configuration.
    let start = Instant::now();
    let (pk, vk) = CompressedSNARK::<_, _, _, S1, S2>::setup(&pp)
        .expect("compressed SNARK setup failed");
    println!("compressed verifier/prover-key setup: {:?}", start.elapsed());

    let start = Instant::now();
    let compressed = CompressedSNARK::<_, _, _, S1, S2>::prove(&pp, &pk, &recursive)
        .expect("compressed proof generation failed");
    println!("compressed proof generation: {:?}", start.elapsed());

    let start = Instant::now();
    let compressed_out = compressed.verify(&vk, steps.len(), &z0)
        .expect("compressed proof verification failed");
    assert_eq!(compressed_out, expected, "compressed public statement mismatch");
    println!("compressed proof verified: {:?}", start.elapsed());

    // Benchmark only the actual compressed-SNARK verifier. Setup, recursive
    // proving, and compressed proof generation are deliberately outside the
    // timed region. This is one compressed batch proof per call, not one proof
    // per transaction. Set LUMA_VERIFY_ITERS to change the repeat count.
    let iterations = std::env::var("LUMA_VERIFY_ITERS")
        .ok()
        .and_then(|value| value.parse::<usize>().ok())
        .filter(|value| *value > 0)
        .unwrap_or(100);

    // Warm up the verifier and ensure the proof still binds to the expected
    // public result before timing.
    for _ in 0..3 {
        let out = compressed
            .verify(&vk, steps.len(), &z0)
            .expect("compressed proof warm-up verification failed");
        assert_eq!(out, expected, "warm-up public statement mismatch");
    }

    let bench_start = Instant::now();
    for _ in 0..iterations {
        let out = compressed
            .verify(&vk, steps.len(), &z0)
            .expect("compressed proof benchmark verification failed");
        assert_eq!(std::hint::black_box(out), expected, "benchmark public statement mismatch");
    }
    let bench_elapsed = bench_start.elapsed();
    let verifications_per_second = iterations as f64 / bench_elapsed.as_secs_f64();
    println!(
        "compressed ZK batch-proof verification benchmark: {iterations} valid verifications in {bench_elapsed:?} = {verifications_per_second:.2} batch proofs/sec"
    );
    println!(
        "Each verified batch proof contains {} recursive spend step(s); this is not raw transactions/sec.",
        steps.len()
    );
    println!("PASS: recursive proof and compressed verification both matched expected state");
    println!("Reminder: this validates this research circuit only, not Nerva consensus or production privacy.");
}
