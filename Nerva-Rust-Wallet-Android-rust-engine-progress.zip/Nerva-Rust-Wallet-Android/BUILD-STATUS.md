# Rust spending migration addendum — 2026-10-22

- Added fork-gated Rust spend-planning primitives in `rust-engine/crates/nerva-core/src/spending.rs`: hard-fork profiles selected from the daemon-reported fork version, ring candidate validation, v2 transaction-prefix serialization, fee rounding and transaction size/weight estimates.
- The upstream HF14 height `4,500,000` is explicitly a placeholder in the supplied source. Current official Nerva information still describes HF14 as in development; the code does not infer HF14 from that placeholder.
- Key-image generation for primary/integrated outputs and explicitly indexed subaddress outputs is implemented via the historic `ge_fromfe_frombytes_vartime` mapping and covered by Nerva C-reference vectors. Primary-address key images are attached to scanned owned outputs for spend matching. Still **not complete**: Nerva privacy decoy sampling, MLSAG/CLSAG signatures, range-proof creation/verification, complete signed serialization, txid/relay and full consensus verification. The Android app keeps official wallet RPC for actual signing/broadcast rather than risk a premature switch.
- Static app invariants passed (`python3 scripts/static_verify.py`). `cargo`, `rustc` and `rustfmt` are absent here; Rust workspace tests/clippy and APK build could not be run. See `rust-engine/IMPLEMENTATION-STATUS.md`.

---

# Phase 3 — simple wallet UX (this revision)

- New create/import-at-startup flow, automatic wallet open, Keystore-held wallet password, device-lock gate, simplified Home/Send/Receive/Settings.
- Import now uses the engine method `restore_deterministic_wallet` (the previous `restore_wallet_from_seed` is not a Monero/Nerva RPC method).
- Wallet-RPC replies are parsed tolerantly; create/open/restore are verified with `get_address` instead of trusting the reply body, and unreadable replies show a short preview of the reply.
- Engine output is logged to a private file (Settings → Technical details). Orphaned engine processes from a killed app are stopped on start.
- The Android JNI crate now links `nerva-core` for local Nerva address validation. The full `nerva-wallet` facade is still experimental and is not used as the live mainnet balance or spending source.
- Verified here: JS syntax, UI flow in a headless browser against a mocked API, source invariants. **Not verified here:** Rust compile, Gradle/APK build, live engine round-trip (no Cargo, SDK or device in this environment).

# Build and engine status — Phase 2

## Android app

- Android UI, Rust JNI/local API, checked Gradle wrapper, build scripts and Android CI are included.
- Real wallet operations still run through the official SHA-256-pinned Nerva `nerva-wallet-rpc` ARM64 engine.
- No APK was built in this environment: Android SDK/NDK, a running Gradle environment and Rust/Cargo were not available here.
- No live wallet creation/restore/send round-trip was run in this environment.

## Rust engine migration

The experimental `rust-engine/` workspace now includes:

- Address, subaddress and account-key derivation helpers; exact atomic amount and varint handling; mnemonic encode/decode.
- Argon2id/ChaCha20-Poly1305 encrypted Rust-format wallet storage and seed-based restore (not legacy `.keys` compatible).
- Transaction-prefix and selected `tx_extra` parsing, including key-image input extraction.
- RingCT base decoding, compact/legacy receiver-side amount recovery and output commitment matching.
- Parallel owned-output matching, persistent scan journal, transaction/owned-output tracking, automatic relevant-transaction history metadata, key-image spend matching when a valid key image is supplied, and reorg rollback.
- Tests authored for primitives, storage, parsing and a synthetic scanner-to-history path; CI workflows present. Static checks pass, but Rust unit tests have not run here.

## Important remaining release blockers

- Rust tests and clippy have not been compiled/executed here because Cargo/rustc are absent. Static checks cannot prove Rust compilation or consensus correctness.
- RingCT proof and signature verification, private decoy selection, canonical block/hash validation, lock/maturity rules, full transaction construction/signing/serialization/relay, automatic subaddress discovery/index persistence and legacy `.keys` import are not implemented. Current Nerva docs identify mainnet as hard-fork 13; type-6/7 parse support in the C++ source is not evidence that CLSAG/Bulletproof+ is active on mainnet. Verify fork activation before using those formats.
- The Rust scanner is not the Android app's source of truth yet. The official Nerva engine remains responsible for live mainnet balance/history and all real spending operations.
- No performance improvement is claimed. Build CI, C++ differential vectors, a security audit, and Android ARM64 test-wallet end-to-end tests must pass first.

Do not replace the official engine or use this Rust migration alone to store/spend mainnet funds until those release gates pass.


## Transaction-flow hardening (2026-10-22)

The Android WebView now uses Rust's staged prepare/review/relay endpoints. Prepared transaction metadata is kept in the Rust process rather than JavaScript state and is accessed with a random one-use capability that expires after 180 seconds. Generic RPC cannot directly invoke transfer or relay methods. Cancel, wallet closure, engine stop, and daemon changes discard pending preparations. The upstream Nerva wallet-RPC binary still owns all consensus-sensitive signing/proof/relay operations; this does not yet make `rust-engine/` a pure-Rust signer. Source checks pass, but Rust compilation, APK build, and a testnet transaction round trip were not available in this environment.
