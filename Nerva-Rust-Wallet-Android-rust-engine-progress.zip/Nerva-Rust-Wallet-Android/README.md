# Nerva Simple Wallet — Rust + Android source project

A minimal Android wallet project with the Home, Send, Receive, History and Settings screens. The local HTTP/API service is written in Rust and exported to Android through JNI. The web UI is served only on `127.0.0.1:8765`. The wallet engine is the **official Nerva `nerva-wallet-rpc` Android ARM64 release**, not a reimplementation of Nerva cryptography.

> **Build status:** This is a full source/build project, **not a verified working APK yet**. The environment where this archive was assembled has no Rust/Cargo, Gradle, Android SDK/NDK or Android device, so the Rust library was not compiled here and no live transaction round-trip could be performed. Static source and JavaScript checks pass; this is not proof that send/restore work end-to-end. Do not deposit significant funds until an Android ARM64 build has passed the full release checklist.

## Features (v0.2 — simple wallet)

- **Startup is automatic.** First launch shows two choices: *Create new wallet* or *I already have a wallet* (25-word seed). After that the wallet opens by itself every time.
- **No wallet password to type or forget.** The wallet-file password is random, encrypted by the Android Keystore and never given to the web UI. The app is protected by the phone's own screen lock (PIN / pattern / fingerprint) on launch and after 30 s in the background.
- **Receive:** QR code + address, copy/share. **Send:** address + amount → review (fee and total shown) → send. **Activity:** received/sent list with confirming state.
- Seed backup is shown once after creation (must be ticked off) and can be shown again from Settings.
- Import restores under a temporary name first, so a mistyped seed never disturbs an existing wallet; old wallet files are archived (`old-<time>-…`), never deleted.
- Wallet RPC stays on `127.0.0.1:18082` with a random per-run Digest login; the local API is session-token protected. No miner controls, no cloud backup.
- Settings: show seed, change node (default `node.nerva.one:17566`), technical details (engine log tail), remove wallet from phone.

## First run and troubleshooting

1. Install the APK, open it, tap **Create new wallet**, write the 25 words on paper, tick the box, continue.
2. Receive → copy/share your address. The first sync is shown on Home.
3. If something fails, the error screen has **Show technical details** (engine state + last lines of the engine log). Send that text when asking for help; it contains no seed or password.
4. If the wallet cannot be unlocked (for example after the Keystore key was invalidated), use **Restore from recovery seed**.

## Build an Android APK

### Requirements

- Android Studio with **Android SDK Platform 35**, Android Build Tools, and Android NDK (Side by side).
- Java 17.
- Rust via rustup/Cargo, plus `cargo-ndk` (the build script installs it if missing).
- Bash, `curl` or `wget`, `unzip`, `tar`, and `sha256sum` (or `shasum`). On Windows, use the included `android/gradlew.bat`; `scripts/build_rust_android.sh` still requires a compatible Bash environment such as WSL2.
- Network access for the checksum-pinned Gradle 8.9 distribution, Gradle dependencies, Rust crates and the official Nerva release asset.

### 1. Open the project

Open the `android/` directory in Android Studio. If Android Studio offers to install required SDK components, install them.

### 2. Build

From the project root, run the included wrapper:

```bash
./android/gradlew :app:assembleDebug
```

On Windows, use `android\gradlew.bat :app:assembleDebug`. The wrapper downloads Gradle 8.9 and verifies its official SHA-256 before use. The Gradle `preBuild` task then downloads and verifies the pinned Nerva engine, cross-compiles the Rust JNI library, and packages the APK.

Alternatively, use the included GitHub Actions workflow (`.github/workflows/android-apk.yml`) to build on an Android-enabled runner. It publishes the debug APK as a workflow artifact. A generated debug APK is for testing, not production distribution.

The resulting APK should be at:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

For a one-command Android Studio build, the Gradle `preBuild` task calls the two preparation scripts automatically. The scripts are idempotent once the verified engine and Rust library exist.

### 3. Install on an ARM64 Android device

Enable Android Developer options and USB debugging, connect the device, then run:

```bash
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

The app copies the engine and its shared libraries to app-private storage, sets the wallet RPC executable permission, launches it through Android's `/system/bin/linker64`, and serves the local UI. No storage permission is requested; wallet files stay in the app's private directory. Keep your recovery seed offline. Uninstalling an app can remove its private wallet files—back up the recovery seed before reinstalling or changing devices.

## Official engine provenance

`scripts/prepare_android_engine.sh` downloads the Nerva project's `v0.3.0.0` Android ARM v8 release archive and checks its pinned SHA-256 before extraction:

- Release: <https://github.com/nerva-project/nerva/releases/tag/v0.3.0.0>
- Asset: `nerva-android-armv8-v0.3.0.0.tar.bz2`
- SHA-256: `905716a117a1575c67925b929b2f2c15cafac0ff94394b4c00610448e522e401`

The `v0.3.0.0` release is the Nerva hard-fork-13 release. If a new mandatory Nerva release supersedes it, update the version, download URL and hash only after checking the signed upstream release hashes and confirming that the replacement Android archive contains `nerva-wallet-rpc`.

## Architecture

```text
Android WebView (HTML/JS/CSS bundled in APK, loaded via WebViewAssetLoader)
  └── fetch http://127.0.0.1:8765 (Rust/Axum JNI service; API only)
        ├── Session-checked, allowlisted local API
        └── HTTP Digest-authenticated JSON-RPC proxy
              └── nerva-wallet-rpc (official Nerva engine)
                    └── node.nerva.one:17566 (default blockchain daemon)
```

The local API intentionally does **not** serve the HTML/JavaScript containing the per-run session token. The token-bearing UI is loaded from APK assets through Android's asset loader, and the API is protected by a random session token, restrictive CORS/Origin checks, Host checks, and loopback binding.

The local API listens on loopback only. The wallet RPC server also listens on loopback only, with a generated password held in process memory. The seed, wallet file and signing operations remain inside the official wallet engine and app-private storage. A remote daemon can observe the device IP and timing of blockchain requests; using your own trusted daemon reduces that dependency.

## Checks and limitations

Run the source-level checks:

```bash
python3 scripts/static_verify.py
```

Run both Rust test suites after Rust/Cargo is installed:

```bash
# Android JNI/API host crate (repository root)
cargo test

# Independent Rust engine workspace and its C-reference vector tests
(cd rust-engine && cargo test --workspace)
(cd rust-engine && cargo clippy --workspace --all-targets)
```

The Rust unit tests cover the RPC method allowlist, daemon-address validation, Digest challenge parsing, atomic amount parsing and exact integer transfer-amount normalization. The WebView sends through Rust's staged `/api/transaction/prepare` → review → `/api/transaction/relay` flow. Rust validates the address and exact atomic-unit amount, checks unlocked balance plus the returned fee, stores opaque transaction metadata in server memory behind a random one-use 180-second capability, and blocks generic RPC from bypassing the review flow. Canceling, changing the daemon or closing/replacing the wallet clears prepared transactions. The pinned upstream Nerva `nerva-wallet-rpc` still performs protocol-sensitive decoy selection, key-image use, RingCT proof/signature generation, final transaction encoding and relay; the standalone `rust-engine/` crates are not yet a full Rust replacement for those cryptographic operations. A true end-to-end verification still requires a native build, app launch on Android ARM64, and a dedicated test wallet / test transaction.

No fast-scan speedup is claimed in this project. `experimental/Nerva-FastScan-Engine.patch` is research-only; it is deliberately **not** applied to the signed upstream engine because the patch was not compiled and independently validated against the current release.

## Directory map

- `android/` — Android application and Gradle config
- `rust/src/lib.rs` — Rust API server, RPC Digest client, local engine process host, and JNI entry points
- `web/` — Wallet screens (create/import, home, send, receive, settings)
- `scripts/prepare_android_engine.sh` — pinned release download + SHA-256 verification
- `scripts/build_rust_android.sh` — ARM64 Rust JNI build
- `experimental/` — unverified scan-engine research patch

## Security release checklist

Before distributing this wallet or using it for significant funds, test all of the following on a physical ARM64 Android device: fresh wallet creation, seed displayed and backed up, full close/reopen, restore from seed with correct restore height, balance and incoming transfer detection, send a small test payment, verify fee/txid, verify confirmed transfer history, change daemon, interrupt/restart scan, and confirm no seed/password appears in logs. Perform a security review and build a signed release APK with a protected signing key. Do not use demo data as proof that a real transaction works.

## Experimental Rust engine migration (Phase 2)

The `rust-engine/` workspace now includes address/subaddress and account primitives, English mnemonic handling, a new encrypted Rust wallet format, bounded transaction-prefix/extra parsing, RingCT base decoding and receiver-side amount recovery with commitment checks, parallel owned-output matching, key-image input extraction, and persistent reorg-aware wallet scan records. Unit tests are authored and CI is configured, but Cargo is not installed in the assembly environment, so those tests have not been executed here.

**This remains an incomplete migration, not a standalone fund-safe wallet.** The Rust code now generates key images for primary/integrated outputs and explicitly indexed subaddress outputs, with test vectors produced by the supplied Nerva C implementation. Primary-address outputs scanned by the Rust wallet facade now receive key images for spend matching. It still lacks complete consensus/proof/signature validation, active-fork-compatible transaction signing, privacy-preserving decoy selection, complete transaction construction/serialization/relay, automatic subaddress discovery/index persistence, and legacy C++ wallet-file import. Current Nerva documentation says mainnet remains at hard-fork 13; recognizing future RingCT type IDs in a parser does not mean CLSAG/Bulletproof+ is active. The Android app deliberately continues to use the official `nerva-wallet-rpc` binary for all real wallet operations until C++ differential tests and Android end-to-end tests pass. See `rust-engine/README.md`, `rust-engine/MIGRATION-MAP.md`, and `rust-engine/PORT-STATUS.md`.


## Rust spending migration status (2026-10-22)

The Rust workspace now has fork-aware spend-planning primitives, ring-candidate validation, Nerva-style fee rounding and transaction-size/weight estimation, and a v2 transaction-prefix serializer. This is **not** a completed or fund-safe Rust spending engine: private decoy sampling, MLSAG/CLSAG signing, Bulletproof2/Bulletproof+ proof generation, commitment balancing, complete signed serialization, transaction IDs, consensus verification and native Rust relay remain missing/unverified. Key-image generation exists for primary/integrated outputs and explicitly indexed subaddress outputs, and primary outputs are linked into scan tracking; it is not integrated into a complete signing pipeline. The app intentionally retains the official Nerva wallet RPC for real signatures and broadcasts until the Rust pipeline passes compiled reference-vector tests and live end-to-end tests. See `rust-engine/IMPLEMENTATION-STATUS.md` for the detailed release decision.
