import org.gradle.api.tasks.Exec
import org.gradle.api.tasks.Copy

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val projectRoot = rootProject.projectDir.parentFile
val engineAssets = layout.projectDirectory.dir("src/main/assets/engine")

android {
    namespace = "com.nervasimple"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nervasimple.wallet"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    sourceSets["main"].jniLibs.srcDirs("src/main/jniLibs")
    packaging { jniLibs { useLegacyPackaging = true } }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    implementation("androidx.webkit:webkit:1.12.1")
}


tasks.register<Copy>("copyWalletWebAssets") {
    group = "build setup"
    description = "Copies the reviewed wallet UI into Android's private APK assets."
    from(projectRoot.resolve("web"))
    into(layout.projectDirectory.dir("src/main/assets/www"))
}

tasks.register<Exec>("prepareNervaEngine") {
    group = "build setup"
    description = "Downloads and verifies the official Nerva v0.3.0.0 Android ARM64 release engine."
    workingDir = projectRoot
    commandLine("bash", "scripts/prepare_android_engine.sh")
    inputs.file(projectRoot.resolve("scripts/prepare_android_engine.sh"))
    outputs.file(engineAssets.file("nerva-wallet-rpc"))
}

tasks.register<Exec>("buildRustAndroid") {
    group = "build setup"
    description = "Builds the Rust JNI library for Android ARM64."
    workingDir = projectRoot
    commandLine("bash", "scripts/build_rust_android.sh")
    inputs.file(projectRoot.resolve("Cargo.toml"))
    inputs.dir(projectRoot.resolve("rust/src"))
    outputs.file(layout.projectDirectory.file("src/main/jniLibs/arm64-v8a/libnerva_rust.so"))
}

tasks.named("preBuild").configure { dependsOn("copyWalletWebAssets", "prepareNervaEngine", "buildRustAndroid") }
