(() => {
  'use strict';
  const TOKEN = window.NERVA_SESSION || '';
  const API = window.NERVA_API_BASE || '';
  const ATOMIC = 1000000000000n;
  const $ = (id) => document.getElementById(id);
  const esc = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const S = { screen: 'splash', address: '', balance: '0', unlocked: '0', transfers: [], walletHeight: 0, netHeight: 0, fails: 0, tick: 0, timer: null, prepared: null, seedFromCreate: false, removeArmed: false };

  // ---------- local API ----------
  async function post(path, body) {
    let res;
    try {
      res = await fetch(API + path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Nerva-Session': TOKEN }, body: JSON.stringify(body || {}) });
    } catch (_) { throw new Error('The wallet service is not reachable. Close the app completely and open it again.'); }
    let data;
    try { data = await res.json(); } catch (_) { throw new Error('The wallet service sent an unreadable reply.'); }
    if (!res.ok || data.ok === false) throw new Error(data.error || 'Request failed (' + res.status + ').');
    return data;
  }
  async function getJson(path) { const r = await fetch(API + path); return r.json(); }
  async function rpc(method, params) { return (await post('/api/call', { method, params: params || {} })).result || {}; }

  // ---------- helpers ----------
  function toast(msg, kind) {
    const el = document.createElement('div'); el.className = 'toast ' + (kind || ''); el.textContent = msg;
    $('toasts').appendChild(el); setTimeout(() => el.remove(), 4000);
  }
  function show(id) {
    document.querySelectorAll('.screen').forEach((el) => el.classList.toggle('active', el.id === id));
    S.screen = id; window.scrollTo(0, 0);
  }
  function fmt(raw, maxDp) {
    try {
      let n = BigInt(String(raw || '0')); const neg = n < 0n; if (neg) n = -n;
      let frac = (n % ATOMIC).toString().padStart(12, '0').slice(0, maxDp == null ? 6 : maxDp).replace(/0+$/, '');
      return (neg ? '-' : '') + (n / ATOMIC).toLocaleString('en-US') + (frac ? '.' + frac : '');
    } catch (_) { return '0'; }
  }
  function toAtomic(text) {
    const s = String(text).trim().replace(',', '.');
    if (!/^\d+(\.\d{1,12})?$/.test(s)) throw new Error('Enter a valid amount (up to 12 decimals).');
    const p = s.split('.');
    const total = BigInt(p[0]) * ATOMIC + BigInt(((p[1] || '') + '000000000000').slice(0, 12));
    if (total <= 0n) throw new Error('Amount must be greater than zero.');
    return total;
  }
  function when(ts) {
    let n = Number(ts); if (!Number.isFinite(n) || n <= 0) return '';
    if (n < 1e11) n *= 1000;
    try { return new Date(n).toLocaleString(undefined, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }); } catch (_) { return ''; }
  }
  async function copyText(t) {
    try { await navigator.clipboard.writeText(t); return true; } catch (_) { /* fall back */ }
    try {
      const ta = document.createElement('textarea'); ta.value = t; ta.style.cssText = 'position:fixed;opacity:0';
      document.body.appendChild(ta); ta.select(); const ok = document.execCommand('copy'); ta.remove(); return ok;
    } catch (_) { return false; }
  }
  function busy(btn, text, on) { if (!btn) return; if (on) { btn.dataset.t = btn.textContent; btn.textContent = text; btn.disabled = true; } else { btn.textContent = btn.dataset.t || btn.textContent; btn.disabled = false; } }
  function showError(id, msg) { const el = $(id); el.textContent = msg; el.hidden = !msg; }

  // ---------- splash ----------
  function splash(title, text, opts) {
    opts = opts || {};
    $('splashTitle').textContent = title; $('splashText').textContent = text || '';
    $('splashSpin').hidden = !!opts.error; $('splashActions').hidden = !opts.error;
    $('splashRestore').hidden = !opts.restore; $('splashDiagBox').hidden = true;
    show('splash');
  }
  async function loadDiagnostics(box) {
    try {
      const d = await post('/api/diagnostics');
      box.textContent = 'engine running: ' + d.engine_running + '\nconnected: ' + d.connected + '\nwallet file: ' + d.wallet_file + '\nnode: ' + d.daemon + '\nversion: ' + (d.version || '-') + '\n\n' + (d.log || '(engine log is empty)');
    } catch (e) { box.textContent = 'Could not read details: ' + e.message; }
    box.hidden = false;
  }

  // ---------- startup ----------
  async function boot() {
    splash('Starting wallet…', 'Connecting to the wallet engine');
    try {
      await post('/api/connect');
      splash('Opening wallet…', '');
      const st = await post('/api/wallet/status');
      if (st.state === 'ready') return enterHome();
      if (st.state === 'none') return show('welcome');
      splash('Could not unlock the wallet', (st.error || '') + ' If this keeps happening, restore the wallet from your recovery seed.', { error: true, restore: true });
    } catch (e) { splash('Could not start', e.message, { error: true }); }
  }

  async function createWallet() {
    splash('Creating your wallet…', 'This takes a few seconds.');
    try {
      const out = await post('/api/wallet/create');
      if (out.seed) { S.seedFromCreate = true; showSeed(out.seed); }
      else { toast('Wallet created, but the recovery seed could not be shown. Open Settings → Show recovery seed.', 'bad'); enterHome(); }
    } catch (e) { splash('Could not create wallet', e.message, { error: true }); }
  }
  function showSeed(seed) {
    const words = String(seed).trim().split(/\s+/);
    $('seedGrid').innerHTML = words.map((w, i) => '<span><b>' + (i + 1) + '</b>' + esc(w) + '</span>').join('');
    $('seedAck').checked = false; $('seedDone').disabled = true;
    $('seedAckRow').hidden = !S.seedFromCreate;
    $('seedDone').textContent = S.seedFromCreate ? 'Continue' : 'Done'; $('seedDone').disabled = S.seedFromCreate;
    show('seed');
  }
  function leaveSeed() {
    $('seedGrid').innerHTML = '';
    if (S.seedFromCreate) { S.seedFromCreate = false; enterHome(); } else show('settings');
  }
  async function importWallet() {
    showError('importError', '');
    const seed = $('importSeed').value.trim().replace(/\s+/g, ' ');
    const h = $('importHeight').value.trim();
    if (seed.split(' ').length !== 25) return showError('importError', 'A recovery seed has 25 words. You entered ' + (seed ? seed.split(' ').length : 0) + '.');
    if (h && !/^\d+$/.test(h)) return showError('importError', 'Block height must be a whole number.');
    splash('Importing wallet…', 'Restoring your wallet. Large or old wallets can take a while to scan.');
    try {
      await post('/api/wallet/import', { seed, restore_height: h ? Number(h) : 0 });
      $('importSeed').value = '';
      enterHome();
    } catch (e) { show('import'); showError('importError', e.message); }
  }

  // ---------- home ----------
  async function enterHome() {
    S.fails = 0; show('home'); renderHome();
    await refresh(true); startPolling();
  }
  function startPolling() {
    if (S.timer) clearInterval(S.timer);
    S.timer = setInterval(() => { if (!document.hidden && ['home', 'receive', 'send'].includes(S.screen)) refresh(false); }, 10000);
  }
  async function refresh(first) {
    try {
      const [a, b, t, h] = await Promise.all([
        rpc('get_address', { account_index: 0 }), rpc('get_balance', { account_index: 0 }),
        rpc('get_transfers', { in: true, out: true, pending: true, failed: true, pool: true, account_index: 0 }), rpc('get_height', {}),
      ]);
      S.address = a.address || ''; S.balance = b.balance || '0'; S.unlocked = b.unlocked_balance || '0';
      S.walletHeight = Number(h.height || 0); S.transfers = flatten(t);
      if (first || S.tick++ % 3 === 0) { try { const n = (await getJson('/api/network')).network || {}; S.netHeight = Number(n.height || n.target_height || 0); } catch (_) { /* optional */ } }
      S.fails = 0; $('banner').hidden = true; renderHome();
    } catch (e) {
      S.fails++;
      if (S.fails >= 2) { $('banner').textContent = 'Reconnecting to the wallet engine…'; $('banner').hidden = false; }
      if (S.fails >= 3) { S.fails = 0; try { const st = await post('/api/wallet/status'); if (st.state !== 'ready') return boot(); } catch (_) { /* keep retrying */ } }
    }
  }
  function flatten(t) {
    const out = []; const seen = new Set();
    for (const bucket of ['in', 'out', 'pending', 'failed', 'pool']) {
      for (const x of (t && Array.isArray(t[bucket]) ? t[bucket] : [])) {
        const id = String(x.txid || bucket + out.length); if (seen.has(id)) continue; seen.add(id);
        out.push(Object.assign({}, x, { bucket, incoming: bucket === 'in' || bucket === 'pool' }));
      }
    }
    return out.sort((a, b) => Number(b.timestamp || 0) - Number(a.timestamp || 0));
  }
  function renderHome() {
    $('balance').textContent = fmt(S.balance);
    const locked = BigInt(S.balance || '0') - BigInt(S.unlocked || '0');
    $('available').textContent = locked > 0n ? 'Available to send: ' + fmt(S.unlocked) + ' XNV (' + fmt(locked.toString()) + ' still unlocking)' : '';
    const behind = S.netHeight > 0 && S.walletHeight < S.netHeight - 2;
    const pct = S.netHeight > 0 ? Math.max(0, Math.min(100, Math.floor((S.walletHeight / S.netHeight) * 100))) : (S.walletHeight ? 100 : 0);
    $('syncFill').style.width = (behind ? pct : 100) + '%';
    $('syncText').textContent = behind ? 'Syncing… ' + pct + '% · balance may be incomplete' : (S.walletHeight ? 'Up to date' : 'Connecting…');
    const rows = S.transfers.slice(0, 40).map((x) => {
      const inc = x.incoming; const conf = Number(x.confirmations);
      const status = x.bucket === 'failed' ? 'Failed' : x.bucket === 'pending' ? 'Pending' : (x.bucket === 'pool' || (Number.isFinite(conf) && conf < 10)) ? 'Confirming' : '';
      const sub = [when(x.timestamp), status].filter(Boolean).join(' · ');
      return '<div class="tx ' + (inc ? 'in' : 'out') + '"><i>' + (inc ? '↓' : '↑') + '</i><div><b>' + (inc ? 'Received' : 'Sent') + '</b><small>' + esc(sub) + '</small></div><div class="a">' + (inc ? '+' : '-') + esc(fmt(x.amount)) + '</div></div>';
    });
    $('txList').innerHTML = rows.length ? rows.join('') : '<div class="empty">No transactions yet.<br>Tap Receive to get your address.</div>';
  }

  // ---------- receive ----------
  function openReceive() {
    $('addr').textContent = S.address || 'Address not ready yet';
    $('qr').src = S.address ? API + '/api/qr?text=' + encodeURIComponent(S.address) : '';
    $('shareAddr').hidden = !navigator.share; show('receive');
  }

  // ---------- send ----------
  function discardPrepared() { const prior = S.prepared; S.prepared = null; if (prior && prior.id) post('/api/transaction/cancel', { id: prior.id }).catch(() => {}); }
  function openSend() { discardPrepared(); $('sendAvail').textContent = fmt(S.unlocked); showError('sendError', ''); show('send'); }
  async function reviewSend() {
    showError('sendError', '');
    if (S.prepared) discardPrepared();
    const btn = $('sendReview'); const address = $('sendTo').value.trim().replace(/\s+/g, '');
    let amount;
    try {
      if (!address) throw new Error('Enter the recipient address.');
      amount = toAtomic($('sendAmt').value);
      if (amount > BigInt(S.unlocked || '0')) throw new Error('Not enough available balance.');
    } catch (e) { return showError('sendError', e.message); }
    busy(btn, 'Checking…', true);
    try {
      const p = await post('/api/transaction/prepare', { address, amount_atomic: amount.toString() });
      if (!p.id || !p.fee_atomic || !p.amount_atomic) throw new Error('The wallet engine did not return a safe prepared transaction. Nothing was sent.');
      const fee = BigInt(p.fee_atomic);
      S.prepared = { id: p.id, expiresAt: Date.now() + Number(p.expires_in_seconds || 0) * 1000 };
      $('cTo').textContent = p.address || address; $('cAmt').textContent = fmt(p.amount_atomic, 12) + ' XNV';
      $('cFee').textContent = fmt(fee.toString(), 12) + ' XNV'; $('cTotal').textContent = fmt((amount + fee).toString(), 12) + ' XNV';
      showError('confirmError', ''); show('confirm');
    } catch (e) { showError('sendError', e.message); }
    finally { busy(btn, '', false); }
  }
  async function sendNow() {
    if (!S.prepared) return;
    const btn = $('sendNow'); busy(btn, 'Sending…', true); showError('confirmError', '');
    try {
      if (Date.now() >= S.prepared.expiresAt) throw new Error('This prepared transaction expired. Return to Send and review it again.');
      const out = await post('/api/transaction/relay', { id: S.prepared.id });
      S.prepared = null; $('sendTo').value = ''; $('sendAmt').value = '';
      toast(out.txid ? 'Payment sent · ' + out.txid.slice(0, 12) + '…' : 'Payment submitted', 'ok'); show('home'); refresh(true);
    } catch (e) {
      if (/submission result is uncertain|expired or was already submitted/i.test(e.message)) S.prepared = null;
      showError('confirmError', e.message);
    }
    finally { busy(btn, '', false); }
  }

  // ---------- settings ----------
  async function openSettings() {
    show('settings'); $('diagBox').hidden = true; $('nodeError').hidden = true; resetRemove();
    try { const d = await getJson('/api/daemon'); $('nodeAddr').textContent = d.address || '—'; $('nodeInput').value = d.address || ''; } catch (_) { $('nodeAddr').textContent = '—'; }
  }
  async function showSeedFromSettings() {
    try { const out = await post('/api/wallet/seed'); S.seedFromCreate = false; showSeed(out.seed); }
    catch (e) { toast(e.message, 'bad'); }
  }
  async function saveNode() {
    showError('nodeError', ''); const btn = $('nodeSave'); busy(btn, 'Restarting…', true);
    try { await post('/api/daemon', { address: $('nodeInput').value.trim() }); toast('Node changed', 'ok'); await boot(); }
    catch (e) { showError('nodeError', e.message); }
    finally { busy(btn, '', false); }
  }
  function resetRemove() { S.removeArmed = false; $('removeBtn').firstElementChild.textContent = 'Remove wallet from this phone'; }
  async function removeWallet() {
    if (!S.removeArmed) {
      S.removeArmed = true; $('removeBtn').firstElementChild.textContent = 'Tap again to confirm removal';
      setTimeout(() => { if (S.screen === 'settings') resetRemove(); }, 6000); return;
    }
    try {
      await post('/api/wallet/remove');
      if (S.timer) clearInterval(S.timer);
      Object.assign(S, { address: '', balance: '0', unlocked: '0', transfers: [], walletHeight: 0 });
      toast('Wallet removed from this phone'); show('welcome');
    } catch (e) { toast(e.message, 'bad'); }
  }

  // ---------- navigation ----------
  window.nervaBack = () => {
    switch (S.screen) {
      case 'receive': case 'send': case 'settings': show('home'); return true;
      case 'confirm': discardPrepared(); show('send'); return true;
      case 'import': show('welcome'); return true;
      case 'seed': if (S.seedFromCreate) { toast('Please back up your seed first.'); return true; } leaveSeed(); return true;
      case 'splash': return false;
      default: return false;
    }
  };

  function wire() {
    $('splashRetry').onclick = boot;
    $('splashRestore').onclick = () => show('import');
    $('splashDiag').onclick = () => loadDiagnostics($('splashDiagBox'));
    $('createBtn').onclick = createWallet;
    $('importBtn').onclick = () => { showError('importError', ''); show('import'); };
    $('importBack').onclick = () => show('welcome');
    $('importGo').onclick = importWallet;
    $('seedAck').onchange = () => { $('seedDone').disabled = !$('seedAck').checked; };
    $('seedDone').onclick = leaveSeed;
    $('openSettings').onclick = openSettings;
    $('sendBtn').onclick = openSend; $('receiveBtn').onclick = openReceive;
    document.querySelectorAll('[data-back]').forEach((b) => { b.onclick = () => window.nervaBack(); });
    $('copyAddr').onclick = async () => toast((await copyText(S.address)) ? 'Address copied' : 'Could not copy. Select the address and copy it manually.', 'ok');
    $('shareAddr').onclick = async () => { try { await navigator.share({ text: S.address }); } catch (_) { /* cancelled */ } };
    $('sendReview').onclick = reviewSend; $('confirmBack').onclick = () => { discardPrepared(); show('send'); };
    $('sendNow').onclick = sendNow; $('sendCancel').onclick = () => { discardPrepared(); show('home'); };
    $('showSeed').onclick = showSeedFromSettings; $('nodeSave').onclick = saveNode;
    $('diagBtn').onclick = () => loadDiagnostics($('diagBox')); $('removeBtn').onclick = removeWallet;
  }

  wire();
  boot();
})();
