package com.nervasimple

import android.app.Activity
import android.app.KeyguardManager
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import java.io.File
import java.io.FileOutputStream
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var walletShown = false
    private var promptingUnlock = false
    private var pendingUnlock: (() -> Unit)? = null
    private var stoppedAt = 0L
    @Volatile private var sessionToken: String = ""

    private external fun startNativeServer(binaryPath: String, walletDir: String, daemon: String, sessionToken: String, walletPassword: String): Int
    private external fun stopNativeServer()

    companion object {
        init { System.loadLibrary("nerva_rust") }
        private const val DEFAULT_DAEMON = "node.nerva.one:17566"
        private const val UNLOCK_REQUEST = 4711
        private const val RELOCK_AFTER_MS = 30_000L
        private const val KEY_ALIAS = "nerva_wallet_password_key"
        private val BG = Color.rgb(16, 14, 32)
        @Volatile private var processSessionToken: String? = null

        @Synchronized private fun sessionTokenForProcess(): String {
            processSessionToken?.let { return it }
            return randomHex(32).also { processSessionToken = it }
        }

        private fun randomHex(bytes: Int): String {
            val random = ByteArray(bytes).also { SecureRandom().nextBytes(it) }
            return random.joinToString("") { "%02x".format(it) }
        }
    }

    // The wallet-file password is random, never typed by the user and never shown to the WebView.
    // It is encrypted with a non-exportable Android Keystore key. The 25-word seed is the real backup.
    private fun walletPassword(): String {
        val prefs = getSharedPreferences("nerva_wallet_secure", MODE_PRIVATE)
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        fun newKey(): SecretKey {
            val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            generator.init(
                KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
            )
            return generator.generateKey()
        }
        val stored = prefs.getString("pw", null)
        if (stored != null && keyStore.containsAlias(KEY_ALIAS)) {
            try {
                val key = keyStore.getKey(KEY_ALIAS, null) as SecretKey
                val raw = Base64.decode(stored, Base64.NO_WRAP)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, raw.copyOfRange(0, 12)))
                return String(cipher.doFinal(raw.copyOfRange(12, raw.size)), Charsets.UTF_8)
            } catch (_: Exception) {
                // Key was invalidated: fall through and create a new one. An existing wallet file
                // then cannot be opened and the app offers "restore from recovery seed".
            }
        }
        if (keyStore.containsAlias(KEY_ALIAS)) keyStore.deleteEntry(KEY_ALIAS)
        val key = newKey()
        val password = randomHex(32)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val blob = cipher.iv + cipher.doFinal(password.toByteArray(Charsets.UTF_8))
        prefs.edit().putString("pw", Base64.encodeToString(blob, Base64.NO_WRAP)).commit()
        return password
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        showLoading("Starting wallet…")
        Thread {
            try {
                val engineDir = File(filesDir, "engine")
                copyAssetTree("engine", engineDir)
                val binary = File(engineDir, "nerva-wallet-rpc")
                if (!binary.isFile || binary.length() < 1_000_000L) {
                    runOnUiThread { showFatal("The Nerva wallet engine is missing from this build. Rebuild the app with network access so the engine can be downloaded.") }
                    return@Thread
                }
                binary.setReadable(true, true)
                binary.setExecutable(true, true)
                val walletDir = File(filesDir, "wallets")
                walletDir.mkdirs()
                val prefs = getSharedPreferences("nerva_wallet_settings", MODE_PRIVATE)
                val daemon = prefs.getString("daemon", DEFAULT_DAEMON) ?: DEFAULT_DAEMON
                sessionToken = sessionTokenForProcess()
                val result = startNativeServer(binary.absolutePath, walletDir.absolutePath, daemon, sessionToken, walletPassword())
                if (result != 0) {
                    runOnUiThread { showFatal("The wallet service could not start (code $result). Close the app completely and open it again.") }
                    return@Thread
                }
                runOnUiThread { requireUnlock { showWallet() } }
            } catch (e: Throwable) {
                runOnUiThread { showFatal("Wallet startup failed: ${e.message ?: e.javaClass.simpleName}") }
            }
        }.start()
    }

    // Uses the phone's own screen lock (PIN, pattern, fingerprint). Skipped if the phone has none.
    private fun requireUnlock(onSuccess: () -> Unit) {
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        val intent = if (km.isDeviceSecure) km.createConfirmDeviceCredentialIntent("Nerva Wallet", "Unlock to open your wallet") else null
        if (intent == null) { onSuccess(); return }
        if (promptingUnlock) return
        promptingUnlock = true
        pendingUnlock = onSuccess
        @Suppress("DEPRECATION")
        startActivityForResult(intent, UNLOCK_REQUEST)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != UNLOCK_REQUEST) return
        promptingUnlock = false
        val next = pendingUnlock
        pendingUnlock = null
        if (resultCode == RESULT_OK) next?.invoke() else finish()
    }

    override fun onStop() {
        super.onStop()
        stoppedAt = System.currentTimeMillis()
    }

    override fun onStart() {
        super.onStart()
        if (walletShown && !promptingUnlock && stoppedAt > 0 && System.currentTimeMillis() - stoppedAt > RELOCK_AFTER_MS) {
            webView.visibility = View.INVISIBLE
            requireUnlock { webView.visibility = View.VISIBLE }
        }
    }

    private fun applyInsets(view: View) {
        ViewCompat.setOnApplyWindowInsetsListener(view) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }
    }

    private fun showLoading(message: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
            setBackgroundColor(BG)
            gravity = Gravity.CENTER
        }
        val title = TextView(this).apply {
            text = "NERVA WALLET"
            textSize = 22f
            setTextColor(Color.rgb(117, 201, 216))
            gravity = Gravity.CENTER
        }
        val progress = ProgressBar(this).apply { isIndeterminate = true }
        val sub = TextView(this).apply {
            text = message
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 0)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(progress, LinearLayout.LayoutParams(-2, -2).apply { topMargin = 30 })
        root.addView(sub, LinearLayout.LayoutParams(-1, -2))
        applyInsets(root)
        setContentView(root)
    }

    private fun showFatal(message: String) {
        showLoading("Could not start wallet")
        val root = findViewById<View>(android.R.id.content).let { (it as? FrameLayout)?.getChildAt(0) } as? LinearLayout ?: return
        (root.getChildAt(1) as? ProgressBar)?.visibility = View.GONE
        val detail = TextView(this).apply {
            text = message + "\n\nNothing was changed in your wallet."
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        root.addView(detail, LinearLayout.LayoutParams(-1, -2))
        root.addView(Button(this).apply { text = "Close"; setOnClickListener { finish() } }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun showWallet() {
        webView = WebView(this)
        webView.setBackgroundColor(BG)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            setSupportZoom(false)
        }
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest) =
                assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.scheme == "https" && uri.host == "appassets.androidplatform.net") return false
                // Never navigate the document to the local API; external links open in the browser.
                if (uri.scheme == "https" && request.isForMainFrame) {
                    try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) { }
                }
                return true
            }
        }
        val container = FrameLayout(this).apply { setBackgroundColor(BG) }
        container.addView(webView, FrameLayout.LayoutParams(-1, -1))
        applyInsets(container)
        setContentView(container)
        val html = assets.open("www/index.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
            .replace("__SESSION_TOKEN__", sessionToken)
            .replace("__API_BASE__", "http://127.0.0.1:8765")
        webView.loadDataWithBaseURL("https://appassets.androidplatform.net/", html, "text/html", "UTF-8", null)
        walletShown = true
    }

    private fun copyAssetTree(assetPath: String, destination: File) {
        val children = assets.list(assetPath) ?: emptyArray()
        if (children.isNotEmpty()) {
            destination.mkdirs()
            children.filterNot { it == ".gitkeep" }.forEach { child ->
                copyAssetTree("$assetPath/$child", File(destination, child))
            }
        } else {
            destination.parentFile?.mkdirs()
            assets.open(assetPath).use { input -> FileOutputStream(destination).use { output -> input.copyTo(output) } }
        }
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onBackPressed() {
        if (!::webView.isInitialized) { finish(); return }
        // The page decides: step back inside the wallet, or tell us to leave the app.
        webView.evaluateJavascript("(window.nervaBack ? window.nervaBack() : false)") { handled ->
            if (handled != "true") finish()
        }
    }
}
