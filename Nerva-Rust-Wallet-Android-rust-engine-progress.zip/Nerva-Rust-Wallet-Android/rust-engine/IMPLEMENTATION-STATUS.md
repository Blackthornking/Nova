# Rust engine implementation status (updated 2026-10-22)

## Added in this revision

`nerva-core::spending` now contains a fork-aware protocol profile derived from the included Nerva C++ snapshot, hardened ring shape/key validation, version-2 transaction-prefix serialization, transaction-size estimation, Nerva-style fee rounding and the HF14 Bulletproof+ clawback estimate. The tests cover HF13/HF14 profiles, fee rounding, fork-specific size estimates, prefix round trips and ring validation.

The profile gates the released HF13 form to ring size 5 + RingCT type 5/Bulletproof2/MLSAG, and the staged HF14 form to ring size 16 + type 7/Bulletproof+/CLSAG. Mainnet HF13 activated at block 4,320,000. The 4,500,000 HF14 value in the supplied C++ source is explicitly marked as a placeholder; do not infer HF14 from that height. The Rust API therefore selects by an explicitly supplied active hard-fork version. At runtime this must come from a trusted, current daemon response after checking that the fork is actually active.

## Still not a complete spending engine

This is a meaningful planning/serialization layer, not an end-to-end signer. The following fund-critical pieces are not implemented or verified in Rust:

- Automatic subaddress discovery/index persistence. The historic `ge_fromfe_frombytes_vartime` key-image primitive now supports primary/integrated outputs and explicitly indexed subaddress outputs, with C-reference vectors. Primary-address key images are attached to scanned owned outputs for spend matching; Rust tests have not yet been run in this environment.
- Nerva's privacy-preserving decoy sampling policy (including output-age distribution, fork segregation, unlock/maturity filtering and daemon-result sanity checks). `validate_input_ring` validates supplied candidates but does not choose decoys.
- MLSAG signing and Bulletproof2/Bulletproof+ range-proof generation, verification and exact Nerva transcript/hash behavior.
- Complete transaction construction, pseudo-output and commitment balancing, full RingCT/prunable serialization, canonical transaction prehash/txid, signature verification, chain-context checks and network relay.
- Consensus-accurate spendable-output selection, dynamic network fee negotiation and final signed-transaction weight checking. The estimate functions are preflight helpers only.
- Legacy C++ `.keys`/cache import parity and recovery, reorg-aware canonical block verification, and live mainnet/testnet differential tests.

The Android app still keeps the upstream wallet RPC as the real signing/broadcast path. It has not been replaced by this Rust migration because doing so before these algorithms pass reference-vector and end-to-end tests would risk losing funds. No Cargo compiler/runtime is present in this execution environment and outbound network access is unavailable, so these new Rust tests have not been compiled or executed here. The workspace CI workflow is configured to run `cargo test --workspace` and `cargo clippy --workspace --all-targets` when pushed.

**Release decision: do not send or store meaningful funds using the Rust migration alone. Do not advertise this revision as a complete Rust wallet.**

## Protocol references checked on 2026-10-22

- Official Nerva HF14 development update (published 2026-08-31): https://nerva.one/august-update-new-website-new-explorer-and-hard-fork-14-in-progress/ (the site's current post is the source of truth if the URL or status has changed).
- Official Nerva site and roadmap: https://nerva.one/
- Released HF13 specifications: https://docs.nerva.one/about/
- Wallet RPC spending methods: https://docs.nerva.one/developer/wallet-rpc/


## Android transaction path hardening (2026-10-22)

The Android app's Rust API now stages prepared transaction metadata server-side behind a random one-use capability, checks amount plus fee against unlocked balance, and requires an explicit post-review relay call. The WebView never receives serialized transaction metadata. These changes reduce accidental/replayed relay risk but do not implement the missing cryptographic signing algorithms in this workspace. `nerva-wallet-rpc` remains the actual protocol-compatible backend for key-image handling, decoy selection, RingCT proof/signature generation, full serialization and network relay. The pure-Rust replacement is not release-complete.
