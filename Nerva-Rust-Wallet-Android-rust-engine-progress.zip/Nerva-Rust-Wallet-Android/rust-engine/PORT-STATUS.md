# Rust engine port status — Phase 2

## Implemented in this source tree

- Nerva mainnet standard, integrated and subaddress encoding/decoding, CryptoNote block Base58, Keccak checksums, and spend/view public key derivation.
- Exact XNV 12-decimal amount formatting/parsing and canonical varint encoding.
- English CryptoNote mnemonic encode/decode for the supported 12/24/25-word forms, deterministic account key derivation and seed-based restore into the **new Rust wallet format**.
- An Argon2id + ChaCha20-Poly1305 encrypted Rust wallet container, authenticated metadata, key consistency checks, atomic writes and owner-only Unix permissions. This container is **not** compatible with upstream `.keys` files.
- Bounded transaction-prefix parsing with transparent outputs, generation/key inputs, relative offsets and key images; bounded transaction-extra parsing including additional transaction public keys.
- RingCT base parsing for Nerva's current type identifiers, receiver-side ECDH amount recovery (legacy and compact encodings), output commitment matching, and a full serialized-transaction scanner that combines output ownership with amount recovery.
- Rayon parallel output matching with transaction-key derivation reuse.
- Historic CryptoNote `Hp(P)` key-image generation from a validated one-time secret, with public/secret consistency checking and Nerva C-reference vectors for primary and subaddress outputs. `WalletEngine::key_image_for_primary_output` and `key_image_for_subaddress_output` verify derived one-time output keys first; primary-address scanned outputs receive key images in tracking.
- Persistent reorg-aware scan journal and wallet scan records, amount/balance summaries, supplied-key-image spend matching, automatic history recording for transactions with owned outputs/known spent outputs, and reorg rollback of outputs, history and spend marks.
- Unit tests authored for these modules and CI workflows for Rust workspace tests and Android packaging.

## Still not a complete or fund-safe replacement

- No complete consensus validation: range-proof/signature verification for Nerva's active transaction formats, transaction hash/prehash reconstruction, unlock/maturity checks and block/chain validation are not implemented. Current official Nerva material identifies hard-fork 13 as active; parser support for future CLSAG/Bulletproof+ type IDs is not confirmation of activation.
- Explicit-index subaddress key-image derivation is implemented. Automatic subaddress discovery/index persistence and subaddress scan integration remain incomplete. The tracker recognizes spends using assigned key images; a complete signed-transaction pipeline is not implemented.
- Fork-aware spend-planning primitives are now in `nerva-core/src/spending.rs`: selection by an explicitly supplied active HF13/HF14 version, decoy-ring shape/key validation, Nerva-style KiB fee rounding, fork-specific size/weight estimates, and v2 transaction-prefix serialization. The supplied HF14 height is only a placeholder; code must not infer activation from it. These helpers do not create a broadcastable transaction.
- No privacy-preserving decoy selection, active-fork RingCT range-proof or MLSAG/CLSAG signature generation/verification, pseudo-output/commitment balancing, full signed transaction/prunable serialization, canonical txid generation, or native Rust relay implementation.
- No import/export compatibility for upstream C++ wallet files, password-change/migration workflow or secure mnemonic presentation UI.
- No end-to-end dual-engine parity tests or valid-mainnet/testnet transaction round-trip.
- The Android UI continues to use the official, checksum-pinned `nerva-wallet-rpc` for real create/restore/balance/transfer/sign/broadcast operations. The Rust parser/scanner and storage are not yet the mainnet engine.

## Build/test status

The implementation source and tests were added, but `cargo`, `rustc`, Android SDK/NDK and the Gradle runtime are not installed in this environment. Therefore Rust tests, `clippy`, and the APK have **not** been built or executed here. The code must be compiled and tested by `.github/workflows/rust-engine.yml`; failures or compatibility mismatches must be fixed before this can be considered usable.

## Required release gate

Do not switch the Android app to the Rust spending path or use this as a standalone mainnet wallet until the workspace compiles, differential C++ vectors match, fuzzing and review are completed, active-fork RingCT/signature and key-image compatibility is verified, and Android ARM64 end-to-end send/receive/restore tests pass. This is a protocol-security requirement, not a UI polish item.
