//! CryptoNote key derivation primitives for standard addresses and subaddresses.
//!
//! The related RingCT decoder lives in `ringct.rs`; the historic CryptoNote key-image primitive
//! is implemented with a Nerva C-reference vector. Complete transaction signing and legacy wallet-file
//! compatibility remain unported.
use curve25519_dalek::{
    constants::ED25519_BASEPOINT_POINT,
    edwards::{CompressedEdwardsY, EdwardsPoint},
    scalar::Scalar,
    traits::IsIdentity,
};
use tiny_keccak::{Hasher, Keccak};
use zeroize::{Zeroize, ZeroizeOnDrop};
use thiserror::Error;
use crate::varint;

#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum CryptoError {
    #[error("invalid/non-canonical secret scalar")]
    InvalidSecret,
    #[error("invalid or non-prime-order Edwards public key")]
    InvalidPublicKey,
    #[error("one-time secret key does not correspond to the supplied output public key")]
    PublicSecretMismatch,
    #[error("derivation failed")]
    DerivationFailed,
}

#[derive(Zeroize, ZeroizeOnDrop)]
pub struct SecretKey([u8; 32]);
impl SecretKey {
    pub fn from_bytes(bytes: [u8; 32]) -> Result<Self, CryptoError> {
        let scalar = Scalar::from_canonical_bytes(bytes).into_option().ok_or(CryptoError::InvalidSecret)?;
        if scalar == Scalar::ZERO { return Err(CryptoError::InvalidSecret); }
        Ok(Self(bytes))
    }
    /// Reduce an arbitrary 32-byte seed representation modulo the scalar order, matching Nerva's
    /// `generate_keys(..., recover=true)` behavior for a recovery seed. Zero is rejected.
    pub fn from_bytes_mod_order(bytes: [u8; 32]) -> Result<Self, CryptoError> {
        let scalar = Scalar::from_bytes_mod_order(bytes);
        if scalar == Scalar::ZERO { return Err(CryptoError::InvalidSecret); }
        Ok(Self(scalar.to_bytes()))
    }
    pub fn as_bytes(&self) -> &[u8; 32] { &self.0 }
    fn scalar(&self) -> Scalar { Scalar::from_canonical_bytes(self.0).into_option().expect("constructed as canonical scalar") }
}
impl std::fmt::Debug for SecretKey {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result { f.write_str("SecretKey([REDACTED])") }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct KeyDerivation(pub [u8; 32]);

pub fn keccak256(input: &[u8]) -> [u8; 32] {
    let mut hash = [0u8; 32];
    let mut hasher = Keccak::v256();
    hasher.update(input);
    hasher.finalize(&mut hash);
    hash
}

pub fn hash_to_scalar(input: &[u8]) -> Scalar {
    Scalar::from_bytes_mod_order(keccak256(input))
}

pub fn decode_public_key(bytes: &[u8; 32]) -> Result<EdwardsPoint, CryptoError> {
    let point = CompressedEdwardsY(*bytes).decompress().ok_or(CryptoError::InvalidPublicKey)?;
    if !point.is_torsion_free() { return Err(CryptoError::InvalidPublicKey); }
    Ok(point)
}

pub fn public_key_from_secret(secret: &SecretKey) -> [u8; 32] {
    (&ED25519_BASEPOINT_POINT * &secret.scalar()).compress().to_bytes()
}

/// Generate the legacy CryptoNote key image `I = x * Hp(P)` used by Nerva's released
/// RingCT/MLSAG transaction format. `monero-generators::hash_to_point` implements the historic
/// `ge_fromfe_frombytes_vartime` map; do not replace this with ordinary Edwards decompression or
/// a generic RFC  hash-to-curve function, since those produce incompatible key images.
/// The public/secret correspondence is checked before returning any image.
pub fn generate_key_image(output_public_key: &[u8; 32], one_time_secret: &SecretKey) -> Result<[u8; 32], CryptoError> {
    if public_key_from_secret(one_time_secret) != *output_public_key {
        return Err(CryptoError::PublicSecretMismatch);
    }
    // `monero-generators` 0.3 uses curve25519-dalek 3 while this crate uses dalek 4.
    // Cross that dependency boundary only through the consensus point encoding; never mix the
    // two EdwardsPoint/Scalar types directly. `hash_to_point` includes the legacy cofactor multiply.
    let hashed_point_bytes = monero_generators::hash_to_point(*output_public_key).compress().to_bytes();
    let hashed_point = decode_public_key(&hashed_point_bytes).map_err(|_| CryptoError::DerivationFailed)?;
    let image = &hashed_point * &one_time_secret.scalar();
    if image.is_identity() { return Err(CryptoError::DerivationFailed); }
    Ok(image.compress().to_bytes())
}

/// Multiply an encoded public key by a private scalar (used by subaddress tx-key handling).
pub fn multiply_public_key(public_key: &[u8; 32], secret: &SecretKey) -> Result<[u8; 32], CryptoError> {
    let point = decode_public_key(public_key)?;
    Ok((&point * &secret.scalar()).compress().to_bytes())
}

/// Calculate Nerva/CryptoNote subaddress spend and view public keys from the primary secrets.
/// The SubAddr domain separator includes the terminating NUL byte as in the upstream C++ code.
pub fn derive_subaddress_public_keys(
    spend_secret: &SecretKey,
    view_secret: &SecretKey,
    major_index: u32,
    minor_index: u32,
) -> Result<([u8; 32], [u8; 32]), CryptoError> {
    if major_index == 0 && minor_index == 0 {
        return Ok((public_key_from_secret(spend_secret), public_key_from_secret(view_secret)));
    }
    let mut input = Vec::with_capacity(8 + 32 + 4 + 4);
    input.extend_from_slice(b"SubAddr\0");
    input.extend_from_slice(view_secret.as_bytes());
    input.extend_from_slice(&major_index.to_le_bytes());
    input.extend_from_slice(&minor_index.to_le_bytes());
    let m = hash_to_scalar(&input);
    let spend_scalar = spend_secret.scalar();
    let view_scalar = view_secret.scalar();
    let primary_spend = &ED25519_BASEPOINT_POINT * &spend_scalar;
    let offset_point = &ED25519_BASEPOINT_POINT * &m;
    let d = &primary_spend + &offset_point;
    let c = &d * &view_scalar;
    Ok((d.compress().to_bytes(), c.compress().to_bytes()))
}

/// CryptoNote generate_key_derivation: cofactor * (tx_public_key * view_secret_key).
pub fn generate_key_derivation(tx_public_key: &[u8; 32], view_secret: &SecretKey) -> Result<KeyDerivation, CryptoError> {
    let point = decode_public_key(tx_public_key)?;
    let view_scalar = view_secret.scalar();
    let shared = (&point * &view_scalar).mul_by_cofactor();
    if shared.is_identity() { return Err(CryptoError::DerivationFailed); }
    Ok(KeyDerivation(shared.compress().to_bytes()))
}

fn output_scalar(derivation: &KeyDerivation, output_index: u64) -> Scalar {
    let mut input = Vec::with_capacity(42);
    input.extend_from_slice(&derivation.0);
    input.extend_from_slice(&varint::encode(output_index));
    hash_to_scalar(&input)
}

/// Derive the per-output scalar used by CryptoNote RingCT ECDH amount decoding.
/// This value is not a spend secret; callers must still verify the output commitment.
pub fn derivation_scalar_bytes(derivation: &KeyDerivation, output_index: u64) -> [u8; 32] {
    output_scalar(derivation, output_index).to_bytes()
}

/// Derive the one-time public output key for any supported CryptoNote address spend key.
pub fn derive_public_key(derivation: &KeyDerivation, output_index: u64, spend_public_key: &[u8; 32]) -> Result<[u8; 32], CryptoError> {
    let spend = decode_public_key(spend_public_key)?;
    Ok(derive_public_key_from_point(derivation, output_index, &spend))
}

pub(crate) fn derive_public_key_from_point(derivation: &KeyDerivation, output_index: u64, spend: &EdwardsPoint) -> [u8; 32] {
    let offset = output_scalar(derivation, output_index);
    let offset_point = &ED25519_BASEPOINT_POINT * &offset;
    (spend + &offset_point).compress().to_bytes()
}

/// Derive the one-time private key for a primary-address output. Only call this for an output
/// whose public key has already been matched against the derivation for this wallet.
pub fn derive_secret_key(derivation: &KeyDerivation, output_index: u64, spend_secret: &SecretKey) -> [u8; 32] {
    (spend_secret.scalar() + output_scalar(derivation, output_index)).to_bytes()
}

/// Derive the one-time private key for a subaddress output. CryptoNote subaddress spend secrets
/// include `m = H_s("SubAddr\0" || view_secret || major || minor)` in addition to the primary
/// spend secret and output derivation scalar. The caller must also compare the derived subaddress
/// public keys with the address and verify the final one-time public key before using the result.
pub fn derive_subaddress_secret_key(
    derivation: &KeyDerivation,
    output_index: u64,
    spend_secret: &SecretKey,
    view_secret: &SecretKey,
    major_index: u32,
    minor_index: u32,
) -> [u8; 32] {
    let mut input = Vec::with_capacity(8 + 32 + 4 + 4);
    input.extend_from_slice(b"SubAddr\0");
    input.extend_from_slice(view_secret.as_bytes());
    input.extend_from_slice(&major_index.to_le_bytes());
    input.extend_from_slice(&minor_index.to_le_bytes());
    let subaddress_offset = if major_index == 0 && minor_index == 0 {
        Scalar::ZERO
    } else {
        hash_to_scalar(&input)
    };
    (spend_secret.scalar() + subaddress_offset + output_scalar(derivation, output_index)).to_bytes()
}

#[cfg(test)]
mod tests {
    use super::*;
    fn sk(n: u8) -> SecretKey { let mut b = [0u8; 32]; b[0] = n; SecretKey::from_bytes(b).unwrap() }

    #[test]
    fn keccak256_is_keccak_not_sha3() {
        assert_eq!(hexless(keccak256(b"")), "c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470");
    }
    fn hexless(bytes: [u8;32]) -> String { bytes.iter().map(|b| format!("{b:02x}")).collect() }
    fn unhex32(text: &str) -> [u8; 32] {
        assert_eq!(text.len(), 64);
        let mut bytes = [0u8; 32];
        for (i, byte) in bytes.iter_mut().enumerate() {
            *byte = u8::from_str_radix(&text[i * 2..i * 2 + 2], 16).unwrap();
        }
        bytes
    }

    #[test]
    fn subaddress_keys_are_deterministic_and_distinct() {
        let spend = sk(7);
        let view = sk(11);
        let primary = derive_subaddress_public_keys(&spend, &view, 0, 0).unwrap();
        assert_eq!(primary, (public_key_from_secret(&spend), public_key_from_secret(&view)));
        let a = derive_subaddress_public_keys(&spend, &view, 1, 2).unwrap();
        let b = derive_subaddress_public_keys(&spend, &view, 1, 2).unwrap();
        let c = derive_subaddress_public_keys(&spend, &view, 1, 3).unwrap();
        assert_eq!(a, b);
        assert_ne!(a, c);
        assert_ne!(a.0, primary.0);
    }

    #[test]
    fn key_image_is_deterministic_and_requires_matching_one_time_key() {
        let one_time_secret = sk(19);
        let output_public_key = public_key_from_secret(&one_time_secret);
        let image = generate_key_image(&output_public_key, &one_time_secret).unwrap();
        // Reference vector generated with the supplied Nerva C implementation's
        // crypto-ops.c (ge_fromfe_frombytes_vartime + ge_mul8 + ge_scalarmult).
        assert_eq!(hexless(output_public_key), "b9551d690261fe83305f433f8230182ef45cd6ddb65b7c2247435ad9935a183f");
        assert_eq!(image, unhex32("46befb67063f2d217bcc0a371f148f6a6348fc53ff68ac29e9348f3cfe76a4dc"));
        assert_eq!(generate_key_image(&output_public_key, &one_time_secret).unwrap(), image);
        assert_ne!(image, output_public_key);
        assert!(decode_public_key(&image).is_ok());
        assert_eq!(generate_key_image(&output_public_key, &sk(20)), Err(CryptoError::PublicSecretMismatch));
        assert_ne!(image, generate_key_image(&public_key_from_secret(&sk(21)), &sk(21)).unwrap());
    }

    #[test]
    fn subaddress_key_image_matches_nerva_cpp_reference_vector() {
        let spend = sk(7);
        let view = SecretKey::from_bytes_mod_order(keccak256(spend.as_bytes())).unwrap();
        let (subaddress_spend_public, subaddress_view_public) =
            derive_subaddress_public_keys(&spend, &view, 2, 9).unwrap();
        assert_eq!(hexless(subaddress_spend_public), "249b2cbee3261df3d10104897d6016667aaa9b0b076dbbdbf0cc29edcaa645ef");
        let tx_secret = sk(13);
        let tx_public_key = multiply_public_key(&subaddress_spend_public, &tx_secret).unwrap();
        assert_eq!(hexless(tx_public_key), "d80030b4dde1d43793e531b7921f289b0f4c8dfb84fb1cfa2f3b9b034c14b0d6");
        let receiver_derivation = generate_key_derivation(&tx_public_key, &view).unwrap();
        let sender_derivation = generate_key_derivation(&subaddress_view_public, &tx_secret).unwrap();
        assert_eq!(receiver_derivation, sender_derivation);
        assert_eq!(hexless(receiver_derivation.0), "fc5f06536c5fff8c32e27753c41055838e477928fcef2361d2db0237a229563b");
        let output_public_key = derive_public_key(&receiver_derivation, 4, &subaddress_spend_public).unwrap();
        assert_eq!(hexless(output_public_key), "634cf29e2da0bafa8d02fcfac37eea9aa0856a717461fa0edfbe54df9d8381db");
        let one_time_bytes = derive_subaddress_secret_key(&receiver_derivation, 4, &spend, &view, 2, 9);
        assert_eq!(hexless(one_time_bytes), "47358e8689aa4da8f578cc649da5dc77286dce0e392895a5e99927236c13580c");
        let one_time_secret = SecretKey::from_bytes(one_time_bytes).unwrap();
        assert_eq!(public_key_from_secret(&one_time_secret), output_public_key);
        let image = generate_key_image(&output_public_key, &one_time_secret).unwrap();
        assert_eq!(hexless(image), "c037278fc2282c0c0a4189e200a870bf2803c2cd7cfff1c77b68c70cd65c00eb");
    }

    #[test]
    fn key_derivation_matches_sender_and_receiver_construction() {
        let view = sk(11);
        let spend = sk(7);
        let tx_secret = sk(5);
        let spend_pub = public_key_from_secret(&spend);
        let tx_pub = public_key_from_secret(&tx_secret);
        let receiver_derivation = generate_key_derivation(&tx_pub, &view).unwrap();
        // Sender-side derivation uses the recipient's public view key and tx secret.
        // Constructing the view public key then deriving the same shared point verifies symmetry.
        let view_pub = public_key_from_secret(&view);
        let sender_derivation = generate_key_derivation(&view_pub, &tx_secret).unwrap();
        assert_eq!(receiver_derivation, sender_derivation);
        let out_pub = derive_public_key(&receiver_derivation, 3, &spend_pub).unwrap();
        let one_time_secret = derive_secret_key(&receiver_derivation, 3, &spend);
        let one_time_secret = SecretKey::from_bytes(one_time_secret).unwrap();
        assert_eq!(public_key_from_secret(&one_time_secret), out_pub);
    }
}
