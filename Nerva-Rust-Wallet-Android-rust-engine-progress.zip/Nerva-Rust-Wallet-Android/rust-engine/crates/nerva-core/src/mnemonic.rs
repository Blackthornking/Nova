//! Nerva's English CryptoNote/Electrum-style mnemonic seed encoding.
//!
//! The word grouping, integer transforms and CRC32 checksum follow the upstream Nerva
//! `src/mnemonics/electrum-words.cpp`. Supported inputs are the standard 25-word seed, the
//! legacy 24-word no-checksum form, and the 12-word legacy form duplicated to 32 bytes.
use thiserror::Error;
use crate::{account::{AccountError, AccountKeys}, crypto::SecretKey};

const WORD_COUNT: u32 = 1626;
const WORDS: &str = include_str!("english.txt");

#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum MnemonicError {
    #[error("seed must contain 12, 24, or 25 English words")]
    WordCount,
    #[error("seed contains an unknown English word or an ambiguous prefix")]
    UnknownWord,
    #[error("seed checksum is invalid")]
    Checksum,
    #[error("seed words do not encode a canonical 32-byte key")]
    InvalidEncoding,
    #[error("seed encodes an invalid or zero spend scalar")]
    InvalidSecret,
    #[error("could not derive wallet keys: {0}")]
    Account(String),
}

fn word_list() -> Vec<&'static str> { WORDS.lines().filter(|w| !w.is_empty()).collect() }

/// Encode 32 bytes using the Nerva English word list. For existing wallets, encode their
/// *spend secret scalar bytes* to obtain a normalized restorable seed. Upstream-generated seed
/// strings can differ because their original recovery bytes may not yet have been scalar-reduced.
pub fn encode_seed(bytes: &[u8; 32]) -> String {
    let words = word_list();
    debug_assert_eq!(words.len(), WORD_COUNT as usize);
    let mut selected: Vec<&str> = Vec::with_capacity(25);
    for chunk in bytes.chunks_exact(4) {
        let value = u32::from_le_bytes([chunk[0], chunk[1], chunk[2], chunk[3]]);
        let w1 = value % WORD_COUNT;
        let w2 = ((value / WORD_COUNT).wrapping_add(w1)) % WORD_COUNT;
        let w3 = (((value / WORD_COUNT) / WORD_COUNT).wrapping_add(w2)) % WORD_COUNT;
        selected.push(words[w1 as usize]);
        selected.push(words[w2 as usize]);
        selected.push(words[w3 as usize]);
    }
    let index = checksum_index(&selected);
    let checksum_word = selected[index];
    selected.push(checksum_word);
    selected.join(" ")
}

/// Decode a Nerva English seed into its original 32-byte seed representation.
/// A 12-word legacy seed repeats the decoded 16-byte half, matching the C++ wallet behavior.
pub fn decode_seed(seed: &str) -> Result<[u8; 32], MnemonicError> {
    let tokens: Vec<&str> = seed.split_whitespace().collect();
    if tokens.len() != 12 && tokens.len() != 24 && tokens.len() != 25 { return Err(MnemonicError::WordCount); }
    let words = word_list();
    if words.len() != WORD_COUNT as usize { return Err(MnemonicError::InvalidEncoding); }
    let with_checksum = tokens.len() == 25;
    let data_words = if with_checksum { 24 } else { tokens.len() };
    let mut indexes = Vec::with_capacity(tokens.len());
    for token in &tokens {
        let normalized = token.to_ascii_lowercase();
        if with_checksum {
            if !normalized.is_ascii() || normalized.len() < 3 { return Err(MnemonicError::UnknownWord); }
            let prefix = &normalized[..3];
            let idx = words.iter().position(|word| word.get(..3) == Some(prefix)).ok_or(MnemonicError::UnknownWord)?;
            indexes.push(idx as u32);
        } else {
            let idx = words.iter().position(|word| *word == normalized).ok_or(MnemonicError::UnknownWord)?;
            indexes.push(idx as u32);
        }
    }
    if with_checksum {
        let prefix_words: Vec<&str> = indexes[..24].iter().map(|i| &words[*i as usize][..3]).collect();
        let expected_index = checksum_index(&prefix_words);
        if indexes[24] != indexes[expected_index] { return Err(MnemonicError::Checksum); }
    }
    let mut output = Vec::with_capacity(32);
    for trio in indexes[..data_words].chunks_exact(3) {
        let w1 = trio[0]; let w2 = trio[1]; let w3 = trio[2];
        let d12 = (WORD_COUNT - w1 + w2) % WORD_COUNT;
        let d23 = (WORD_COUNT - w2 + w3) % WORD_COUNT;
        let value = w1
            .wrapping_add(WORD_COUNT.wrapping_mul(d12))
            .wrapping_add(WORD_COUNT.wrapping_mul(WORD_COUNT).wrapping_mul(d23));
        if value % WORD_COUNT != w1 { return Err(MnemonicError::InvalidEncoding); }
        output.extend_from_slice(&value.to_le_bytes());
    }
    if output.len() == 16 { let half = output.clone(); output.extend_from_slice(&half); }
    if output.len() != 32 { return Err(MnemonicError::InvalidEncoding); }
    let mut result = [0u8; 32]; result.copy_from_slice(&output); Ok(result)
}

/// Recover a conventional Nerva account from a 12/24/25-word English seed.
pub fn recover_account(seed: &str) -> Result<AccountKeys, MnemonicError> {
    let raw = decode_seed(seed)?;
    let spend = SecretKey::from_bytes_mod_order(raw).map_err(|_| MnemonicError::InvalidSecret)?;
    AccountKeys::from_spend_secret(spend).map_err(|e: AccountError| MnemonicError::Account(e.to_string()))
}

fn checksum_index(words: &[&str]) -> usize {
    let mut crc = !0u32;
    for word in words {
        for byte in word.as_bytes().iter().take(3) {
            crc ^= *byte as u32;
            for _ in 0..8 {
                crc = (crc >> 1) ^ if crc & 1 == 1 { 0xedb8_8320 } else { 0 };
            }
        }
    }
    ((!crc) as usize) % words.len()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{account::AccountKeys, crypto::SecretKey};

    fn sk() -> SecretKey { let mut b=[0u8;32]; b[0]=7; SecretKey::from_bytes(b).unwrap() }

    #[test]
    fn canonical_key_roundtrips_through_25_word_seed() {
        let secret=sk();
        let seed=encode_seed(secret.as_bytes());
        assert_eq!(seed.split_whitespace().count(),25);
        assert_eq!(decode_seed(&seed).unwrap(),*secret.as_bytes());
        let recovered=recover_account(&seed).unwrap();
        let expected=AccountKeys::from_spend_secret(sk()).unwrap();
        assert_eq!(recovered.address(),expected.address());
    }

    #[test]
    fn checksum_and_unknown_words_are_rejected() {
        let seed=encode_seed(sk().as_bytes());
        let mut tokens: Vec<String>=seed.split_whitespace().map(ToOwned::to_owned).collect();
        let old_index=word_list().iter().position(|word| *word == tokens[24].as_str()).unwrap();
        tokens[24]=word_list()[(old_index+1) % WORD_COUNT as usize].to_string();
        assert_eq!(decode_seed(&tokens.join(" ")),Err(MnemonicError::Checksum));
        assert_eq!(decode_seed("zzzword ".repeat(25).trim()),Err(MnemonicError::UnknownWord));
    }

    #[test]
    fn legacy_24_and_12_word_forms_decode() {
        let secret=sk(); let seed=encode_seed(secret.as_bytes());
        let words: Vec<&str>=seed.split_whitespace().collect();
        let legacy24=words[..24].join(" ");
        assert_eq!(decode_seed(&legacy24).unwrap(),*secret.as_bytes());
        let legacy12=words[..12].join(" ");
        let decoded=decode_seed(&legacy12).unwrap();
        assert_eq!(&decoded[..16],&decoded[16..]);
    }
}
