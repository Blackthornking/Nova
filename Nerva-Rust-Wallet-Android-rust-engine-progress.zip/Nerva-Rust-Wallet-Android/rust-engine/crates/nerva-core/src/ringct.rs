//! Decoder for Nerva's RingCT base serialization and receiver-side amount ECDH.
//!
//! This module intentionally does not parse or verify Bulletproof/Bulletproof+ range proofs,
//! MLSAG/CLSAG signatures, or complete transaction consensus validity. Before a recovered amount
//! is used, this module checks the output Pedersen commitment. Chain inclusion and tx signatures
//! must still be trusted/verified by the caller.
use curve25519_dalek::{constants::ED25519_BASEPOINT_POINT, edwards::EdwardsPoint, scalar::Scalar};
use thiserror::Error;
use crate::{crypto::{decode_public_key, hash_to_scalar, keccak256}, tx_prefix::ParsedTxPrefix, varint};

pub const MAX_RINGCT_BASE_BYTES: usize = 1_048_576;
const MAX_OUTPUTS: usize = 100_000;
const MAX_INPUTS: usize = 100_000;
const H_COMPRESSED: [u8; 32] = [
    0x8b, 0x65, 0x59, 0x70, 0x15, 0x37, 0x99, 0xaf, 0x2a, 0xea, 0xdc, 0x9f,
    0xf1, 0xad, 0xd0, 0xea, 0x6c, 0x72, 0x51, 0xd5, 0x41, 0x54, 0xcf, 0xa9,
    0x2c, 0x17, 0x3a, 0x0d, 0xd3, 0x9c, 0x1f, 0x94,
];

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum RingCtType {
    Null = 0,
    Full = 1,
    Simple = 2,
    Bulletproof1Full = 3,
    Bulletproof1Simple = 4,
    Bulletproof2 = 5,
    Clsag = 6,
    BulletproofPlus = 7,
}
impl RingCtType {
    pub fn is_null(self) -> bool { matches!(self, Self::Null) }
    fn compact_ecdh(self) -> bool { matches!(self, Self::Bulletproof2 | Self::Clsag | Self::BulletproofPlus) }
    fn has_pseudoouts_in_base(self) -> bool { matches!(self, Self::Simple) }
    fn from_byte(b: u8) -> Result<Self, RingCtError> {
        Ok(match b {
            0 => Self::Null, 1 => Self::Full, 2 => Self::Simple, 3 => Self::Bulletproof1Full,
            4 => Self::Bulletproof1Simple, 5 => Self::Bulletproof2, 6 => Self::Clsag,
            7 => Self::BulletproofPlus, _ => return Err(RingCtError::UnsupportedType(b)),
        })
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum EcdhAmount {
    /// Legacy layout: 32-byte encrypted mask followed by a 32-byte encrypted amount scalar.
    Legacy { mask: [u8; 32], amount: [u8; 32] },
    /// Bulletproof2 / CLSAG / Bulletproof+ layout: only the encrypted low 8 amount bytes.
    Compact { amount: [u8; 8] },
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RingCtBase {
    pub rct_type: RingCtType,
    pub fee: Option<u64>,
    pub ecdh: Vec<EcdhAmount>,
    /// Per-output Pedersen commitment C = mask*G + amount*H.
    pub commitments: Vec<[u8; 32]>,
    pub base_bytes: usize,
}

#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum RingCtError {
    #[error("RingCT base is empty or truncated at byte {0}")]
    Truncated(usize),
    #[error("RingCT base exceeds the configured limit")]
    TooLarge,
    #[error("unsupported Nerva RingCT type {0}")]
    UnsupportedType(u8),
    #[error("RingCT base has an invalid varint at byte {0}")]
    InvalidVarint(usize),
    #[error("RingCT input/output count exceeds safe limits")]
    TooManyItems,
    #[error("RingCT base length arithmetic overflow")]
    LengthOverflow,
    #[error("RingCT output count does not match transaction prefix")]
    OutputCountMismatch,
    #[error("RingCT amount metadata is missing for this output")]
    MissingAmount,
    #[error("RingCT ECDH amount is not a canonical uint64 amount")]
    InvalidAmountEncoding,
    #[error("RingCT commitment or amount is not a valid curve point/scalar")]
    InvalidCommitment,
    #[error("RingCT amount did not match its output commitment")]
    CommitmentMismatch,
}

impl RingCtBase {
    /// Parse just the canonical base portion after `transaction_prefix.extra`.
    /// The range proof and signature suffix is deliberately left opaque.
    pub fn parse(blob: &[u8], input_count: usize, output_count: usize) -> Result<Self, RingCtError> {
        if blob.is_empty() { return Err(RingCtError::Truncated(0)); }
        // `blob` also contains the opaque prunable suffix. Bound only bytes actually consumed by
        // the base parser so large, valid range-proof/signature suffixes are not rejected here.
        if input_count > MAX_INPUTS || output_count > MAX_OUTPUTS { return Err(RingCtError::TooManyItems); }
        let mut r = Reader { bytes: blob, pos: 0 };
        let rct_type = RingCtType::from_byte(r.byte()?)?;
        if rct_type.is_null() {
            return Ok(Self { rct_type, fee: None, ecdh: Vec::new(), commitments: Vec::new(), base_bytes: r.pos });
        }
        let fee = Some(r.varint()?);
        if rct_type.has_pseudoouts_in_base() {
            r.take(input_count.checked_mul(32).ok_or(RingCtError::LengthOverflow)?)?;
        }
        let mut ecdh = Vec::with_capacity(output_count);
        for _ in 0..output_count {
            if rct_type.compact_ecdh() {
                let mut amount = [0u8; 8]; amount.copy_from_slice(r.take(8)?);
                ecdh.push(EcdhAmount::Compact { amount });
            } else {
                let mut mask = [0u8; 32]; mask.copy_from_slice(r.take(32)?);
                let mut amount = [0u8; 32]; amount.copy_from_slice(r.take(32)?);
                ecdh.push(EcdhAmount::Legacy { mask, amount });
            }
        }
        let mut commitments = Vec::with_capacity(output_count);
        for _ in 0..output_count {
            let mut c = [0u8; 32]; c.copy_from_slice(r.take(32)?); commitments.push(c);
        }
        Ok(Self { rct_type, fee, ecdh, commitments, base_bytes: r.pos })
    }

    /// Recover a receiver's output amount from its derivation scalar and require the decoded
    /// amount and recovered mask to recreate the serialized Pedersen commitment.
    /// `clear_amount` is the transparent amount in `txout_to_key`, used for RCTTypeNull only.
    pub fn recover_amount(
        &self,
        output_index: usize,
        clear_amount: u64,
        derivation_scalar: &[u8; 32],
    ) -> Result<u64, RingCtError> {
        if self.rct_type.is_null() { return Ok(clear_amount); }
        let encoded = self.ecdh.get(output_index).ok_or(RingCtError::MissingAmount)?;
        let commitment_bytes = self.commitments.get(output_index).ok_or(RingCtError::MissingAmount)?;
        let shared = Scalar::from_bytes_mod_order(*derivation_scalar).to_bytes();
        let (mask_scalar, amount_scalar, amount) = match encoded {
            EcdhAmount::Compact { amount } => {
                let mut data = [0u8; 38]; data[..6].copy_from_slice(b"amount"); data[6..].copy_from_slice(&shared);
                // Nerva's ecdhHash uses the raw Keccak-256 digest for the compact amount,
                // while the commitment mask below uses hash-to-scalar.
                let amount_key = keccak256(&data);
                let mut amount_bytes = *amount;
                for i in 0..8 { amount_bytes[i] ^= amount_key[i]; }
                let amount = u64::from_le_bytes(amount_bytes);
                let mut mask_input = [0u8; 47]; mask_input[..15].copy_from_slice(b"commitment_mask"); mask_input[15..].copy_from_slice(&shared);
                let mask_scalar = hash_to_scalar(&mask_input);
                (mask_scalar, Scalar::from(amount), amount)
            }
            EcdhAmount::Legacy { mask, amount } => {
                let h1 = hash_to_scalar(&shared);
                let h2 = hash_to_scalar(&h1.to_bytes());
                let mask = Scalar::from_bytes_mod_order(*mask) - h1;
                let amount = Scalar::from_bytes_mod_order(*amount) - h2;
                let encoded_amount = amount.to_bytes();
                if encoded_amount[8..].iter().any(|b| *b != 0) { return Err(RingCtError::InvalidAmountEncoding); }
                let amount_value = u64::from_le_bytes(encoded_amount[..8].try_into().map_err(|_| RingCtError::InvalidAmountEncoding)?);
                (mask, amount, amount_value)
            }
        };
        let h = decode_public_key(&H_COMPRESSED).map_err(|_| RingCtError::InvalidCommitment)?;
        let expected: EdwardsPoint = &ED25519_BASEPOINT_POINT * &mask_scalar + &h * &amount_scalar;
        let observed = decode_public_key(commitment_bytes).map_err(|_| RingCtError::InvalidCommitment)?;
        if expected != observed { return Err(RingCtError::CommitmentMismatch); }
        Ok(amount)
    }
}

/// Parse a Nerva transaction prefix followed by the transparent/RingCT base. Trailing range proofs
/// and transaction signatures are not parsed by this function.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ParsedTransaction {
    pub prefix: ParsedTxPrefix,
    pub ringct: RingCtBase,
}
pub fn parse_transaction(blob: &[u8]) -> Result<ParsedTransaction, TransactionError> {
    let prefix = crate::tx_prefix::parse_transaction_prefix(blob).map_err(TransactionError::Prefix)?;
    // Legacy v1 transactions serialize signatures immediately after the prefix; there is no
    // RingCT type byte. Amounts are transparent in this format.
    let ringct = if prefix.version == 1 {
        RingCtBase { rct_type: RingCtType::Null, fee: None, ecdh: Vec::new(), commitments: Vec::new(), base_bytes: 0 }
    } else {
        let suffix = blob.get(prefix.prefix_bytes..).ok_or(TransactionError::RingCt(RingCtError::Truncated(prefix.prefix_bytes)))?;
        RingCtBase::parse(suffix, prefix.input_count, prefix.outputs.len()).map_err(TransactionError::RingCt)?
    };
    Ok(ParsedTransaction { prefix, ringct })
}

#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum TransactionError {
    #[error("transaction prefix error: {0}")]
    Prefix(#[source] crate::tx_prefix::TxPrefixError),
    #[error("transaction RingCT base error: {0}")]
    RingCt(#[source] RingCtError),
}

struct Reader<'a> { bytes: &'a [u8], pos: usize }
impl<'a> Reader<'a> {
    fn byte(&mut self) -> Result<u8, RingCtError> { Ok(self.take(1)?[0]) }
    fn take(&mut self, len: usize) -> Result<&'a [u8], RingCtError> {
        let end = self.pos.checked_add(len).ok_or(RingCtError::LengthOverflow)?;
        if end > self.bytes.len() { return Err(RingCtError::Truncated(self.pos)); }
        if end > MAX_RINGCT_BASE_BYTES { return Err(RingCtError::TooLarge); }
        let out = &self.bytes[self.pos..end]; self.pos = end; Ok(out)
    }
    fn varint(&mut self) -> Result<u64, RingCtError> {
        let start = self.pos;
        let (value, used) = varint::decode(self.bytes.get(start..).ok_or(RingCtError::Truncated(start))?)
            .map_err(|_| RingCtError::InvalidVarint(start))?;
        let end = self.pos.checked_add(used).ok_or(RingCtError::LengthOverflow)?;
        if end > MAX_RINGCT_BASE_BYTES { return Err(RingCtError::TooLarge); }
        self.pos = end;
        Ok(value)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{crypto::{derivation_scalar_bytes, generate_key_derivation, public_key_from_secret, SecretKey}, varint};

    fn sk(value: u8) -> SecretKey { let mut bytes=[0u8;32]; bytes[0]=value; SecretKey::from_bytes(bytes).unwrap() }

    fn compact_base(encoded_amount: [u8;8], commitment: [u8;32], outputs: usize) -> Vec<u8> {
        let mut out=vec![RingCtType::BulletproofPlus as u8]; out.extend(varint::encode(11));
        for _ in 0..outputs { out.extend_from_slice(&encoded_amount); }
        for _ in 0..outputs { out.extend_from_slice(&commitment); }
        out
    }

    #[test]
    fn parses_current_bulletproof_plus_base_shape() {
        let blob=compact_base([1,2,3,4,5,6,7,8],[0x11;32],2);
        let parsed=RingCtBase::parse(&blob,2,2).unwrap();
        assert_eq!(parsed.rct_type,RingCtType::BulletproofPlus);
        assert_eq!(parsed.fee,Some(11)); assert_eq!(parsed.ecdh.len(),2); assert_eq!(parsed.commitments.len(),2);
        assert_eq!(parsed.base_bytes,blob.len());
    }

    #[test]
    fn null_ringct_is_transparent_and_stops_after_type_byte() {
        let p=RingCtBase::parse(&[0,9,8,7],1,1).unwrap();
        assert_eq!(p.rct_type,RingCtType::Null); assert_eq!(p.base_bytes,1);
        assert_eq!(p.recover_amount(0,123,&[0;32]).unwrap(),123);
    }

    #[test]
    fn compact_ecdh_recovers_amount_only_when_commitment_matches() {
        let view=sk(11); let tx_secret=sk(13); let tx_pub=public_key_from_secret(&tx_secret);
        let derivation=generate_key_derivation(&tx_pub,&view).unwrap();
        let shared=derivation_scalar_bytes(&derivation,0);
        let amount=17_234_567u64;
        let mut amount_cipher=amount.to_le_bytes();
        let mut data=[0u8;38]; data[..6].copy_from_slice(b"amount"); data[6..].copy_from_slice(&shared);
        let amount_key=keccak256(&data);
        for i in 0..8 { amount_cipher[i]^=amount_key[i]; }
        let mut mask_input=[0u8;47]; mask_input[..15].copy_from_slice(b"commitment_mask"); mask_input[15..].copy_from_slice(&shared);
        let mask=hash_to_scalar(&mask_input);
        let h=decode_public_key(&H_COMPRESSED).unwrap();
        let commitment=(&ED25519_BASEPOINT_POINT * &mask + &h * &Scalar::from(amount)).compress().to_bytes();
        let base=RingCtBase::parse(&compact_base(amount_cipher,commitment,1),1,1).unwrap();
        assert_eq!(base.recover_amount(0,0,&shared).unwrap(),amount);
        let bad_blob=compact_base(amount_cipher,[0x22;32],1);
        let bad=RingCtBase::parse(&bad_blob,1,1).unwrap();
        assert!(matches!(bad.recover_amount(0,0,&shared),Err(RingCtError::InvalidCommitment) | Err(RingCtError::CommitmentMismatch)));
    }

    #[test]
    fn legacy_ecdh_amounts_roundtrip_commitment() {
        let shared=Scalar::from_bytes_mod_order([0x55;32]).to_bytes(); let amount=123456789u64;
        let mask=Scalar::from(41u64); let h1=hash_to_scalar(&shared); let h2=hash_to_scalar(&h1.to_bytes());
        let encoded_mask=(mask+h1).to_bytes(); let encoded_amount=(Scalar::from(amount)+h2).to_bytes();
        let h=decode_public_key(&H_COMPRESSED).unwrap();
        let commitment=(&ED25519_BASEPOINT_POINT * &mask + &h * &Scalar::from(amount)).compress().to_bytes();
        let mut blob=vec![RingCtType::Simple as u8]; blob.extend(varint::encode(0)); blob.extend_from_slice(&[0u8;32]);
        blob.extend_from_slice(&encoded_mask); blob.extend_from_slice(&encoded_amount); blob.extend_from_slice(&commitment);
        let parsed=RingCtBase::parse(&blob,1,1).unwrap();
        assert_eq!(parsed.recover_amount(0,0,&shared).unwrap(),amount);
    }

    #[test]
    fn version_one_transaction_has_no_ringct_type_byte() {
        use crate::{tx_prefix::parse_transaction_prefix, varint};
        let mut raw=Vec::new();
        raw.extend(varint::encode(1)); raw.extend(varint::encode(0));
        raw.extend(varint::encode(1)); raw.push(0xff); raw.extend(varint::encode(7));
        raw.extend(varint::encode(1)); raw.extend(varint::encode(42)); raw.push(2); raw.extend_from_slice(&[0x44;32]);
        raw.extend(varint::encode(0));
        raw.extend_from_slice(&[0xab;64]); // legacy signature bytes, not an RingCT type
        let parsed=parse_transaction(&raw).unwrap();
        assert_eq!(parsed.prefix.outputs[0].amount,42);
        assert!(parsed.ringct.rct_type.is_null());
        assert_eq!(parsed.ringct.base_bytes,0);
        let _=parse_transaction_prefix(&raw).unwrap();
    }

    #[test]
    fn rejects_truncated_base_and_unknown_type() {
        assert_eq!(RingCtBase::parse(&[],0,0),Err(RingCtError::Truncated(0)));
        assert_eq!(RingCtBase::parse(&[0xff],0,0),Err(RingCtError::UnsupportedType(0xff)));
        assert!(matches!(RingCtBase::parse(&[7],0,1),Err(RingCtError::InvalidVarint(_)) | Err(RingCtError::Truncated(_))));
    }
}
