//! Fork-aware transaction planning/serialization primitives for Nerva.
//!
//! This module deliberately stops before creating cryptographic signatures. It does not claim
//! that a prefix is a valid transaction. The active fork determines ring size and RingCT type;
//! decoy rings are validated before a signer may consume them.
use thiserror::Error;

use crate::{crypto::decode_public_key, varint};

const MAX_INPUTS: usize = 128;
const MAX_OUTPUTS: usize = 128;
const MAX_EXTRA: usize = 16 * 1024;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Network { Mainnet, Testnet, Stagenet }

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RingCtType { Bulletproof2 = 5, Clsag = 6, BulletproofPlus = 7 }

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RingSignature { Mlsag, Clsag }

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RangeProof { Bulletproof2, BulletproofPlus }

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SpendProtocol {
    pub hard_fork: u8,
    /// Number of ring members, including the real output.
    pub ring_size: usize,
    pub ringct_type: RingCtType,
    pub signature: RingSignature,
    pub range_proof: RangeProof,
}

#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum SpendError {
    #[error("the requested network height is not covered by this source snapshot")]
    UnknownFork,
    #[error("invalid ring size: expected {expected}, got {actual}")]
    WrongRingSize { expected: usize, actual: usize },
    #[error("ring members must be ordered by strictly increasing global output index")]
    RingIndicesNotStrictlyIncreasing,
    #[error("the ring contains a duplicate public key")]
    DuplicateRingKey,
    #[error("the real output index is not present in the ring")]
    RealOutputMissing,
    #[error("ring member {0} is not a valid prime-order Edwards public key")]
    InvalidRingPublicKey(usize),
    #[error("transaction has no inputs")]
    NoInputs,
    #[error("transaction has no outputs")]
    NoOutputs,
    #[error("too many inputs or outputs")]
    TooManyItems,
    #[error("transaction extra field exceeds the size limit")]
    ExtraTooLarge,
    #[error("fee calculation overflow")]
    FeeOverflow,
    #[error("a transaction prefix must use the active RingCT protocol")]
    ForkMismatch,
    #[error("confidential transactions must serialize input amounts as zero")]
    InvalidConfidentialAmount,
}

fn validate_protocol(protocol: SpendProtocol) -> Result<(), SpendError> {
    let matches_hf13 = protocol.hard_fork == 13
        && protocol.ring_size == 5
        && protocol.ringct_type == RingCtType::Bulletproof2
        && protocol.signature == RingSignature::Mlsag
        && protocol.range_proof == RangeProof::Bulletproof2;
    let matches_hf14_plus = protocol.hard_fork == 14
        && protocol.ring_size == 16
        && protocol.ringct_type == RingCtType::BulletproofPlus
        && protocol.signature == RingSignature::Clsag
        && protocol.range_proof == RangeProof::BulletproofPlus;
    if matches_hf13 || matches_hf14_plus { Ok(()) } else { Err(SpendError::ForkMismatch) }
}

/// Protocol profile chosen from the **active hard-fork version reported by a trusted daemon**.
/// Do not infer HF14 from the 4,500,000 placeholder in the supplied C++ snapshot: the upstream
/// project says this height is not final while HF14 is in development. Mainnet's released HF13
/// profile is ring size 5 + RingCT type 5/Bulletproof2/MLSAG. The HF14 profile is staged for
/// testing and must only be used after the network actually reports fork version 14.
pub fn protocol_for_hard_fork(_network: Network, active_hard_fork: u8) -> Result<SpendProtocol, SpendError> {
    match active_hard_fork {
        13 => Ok(SpendProtocol {
            hard_fork: 13,
            ring_size: 5,
            ringct_type: RingCtType::Bulletproof2,
            signature: RingSignature::Mlsag,
            range_proof: RangeProof::Bulletproof2,
        }),
        14 => Ok(SpendProtocol {
            hard_fork: 14,
            ring_size: 16,
            ringct_type: RingCtType::BulletproofPlus,
            signature: RingSignature::Clsag,
            range_proof: RangeProof::BulletproofPlus,
        }),
        _ => Err(SpendError::UnknownFork),
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RingMember {
    pub global_output_index: u64,
    pub public_key: [u8; 32],
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct InputRing {
    /// Absolute global output index of the wallet's real output.
    pub real_output_index: u64,
    /// Members sorted by increasing global output index.
    pub members: Vec<RingMember>,
}

/// Validate decoys returned by a daemon before a transaction signer uses them. This does not
/// implement Nerva's time-distribution/gamma selection policy; it validates shape and key safety
/// only and therefore is not a replacement for the upstream wallet's decoy selection algorithm.
pub fn validate_input_ring(protocol: SpendProtocol, ring: &InputRing) -> Result<(), SpendError> {
    validate_protocol(protocol)?;
    if ring.members.len() != protocol.ring_size {
        return Err(SpendError::WrongRingSize { expected: protocol.ring_size, actual: ring.members.len() });
    }
    let mut real_found = false;
    let mut previous: Option<u64> = None;
    let mut keys = std::collections::HashSet::with_capacity(ring.members.len());
    for (i, member) in ring.members.iter().enumerate() {
        if previous.is_some_and(|p| member.global_output_index <= p) {
            return Err(SpendError::RingIndicesNotStrictlyIncreasing);
        }
        previous = Some(member.global_output_index);
        if !keys.insert(member.public_key) { return Err(SpendError::DuplicateRingKey); }
        decode_public_key(&member.public_key).map_err(|_| SpendError::InvalidRingPublicKey(i))?;
        real_found |= member.global_output_index == ring.real_output_index;
    }
    if !real_found { return Err(SpendError::RealOutputMissing); }
    Ok(())
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct KeyInputPrefix {
    /// Nerva RingCT inputs use amount 0; the amount is hidden by RingCT.
    pub amount: u64,
    /// Absolute global output indexes, already validated and sorted.
    pub absolute_offsets: Vec<u64>,
    pub key_image: [u8; 32],
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct KeyOutputPrefix {
    /// Standard `txout_to_key` recipient one-time public key.
    pub public_key: [u8; 32],
}

/// Serialize the version/unlock/input/output/extra prefix of an RCT transaction (version 2).
/// This is *not* a complete signed transaction: the RingCT base, range proof, ring signatures,
/// transaction hash, consensus validation and relay still have to be produced and verified.
pub fn serialize_v2_prefix(
    protocol: SpendProtocol,
    unlock_time: u64,
    inputs: &[KeyInputPrefix],
    outputs: &[KeyOutputPrefix],
    extra: &[u8],
) -> Result<Vec<u8>, SpendError> {
    if inputs.is_empty() { return Err(SpendError::NoInputs); }
    if outputs.is_empty() { return Err(SpendError::NoOutputs); }
    if inputs.len() > MAX_INPUTS || outputs.len() > MAX_OUTPUTS { return Err(SpendError::TooManyItems); }
    if extra.len() > MAX_EXTRA { return Err(SpendError::ExtraTooLarge); }
    validate_protocol(protocol)?;
    let mut capacity = 128usize;
    capacity = capacity.checked_add(inputs.len().checked_mul(protocol.ring_size.checked_mul(2).and_then(|x| x.checked_add(40)).ok_or(SpendError::FeeOverflow)?).ok_or(SpendError::FeeOverflow)?).ok_or(SpendError::FeeOverflow)?;
    capacity = capacity.checked_add(outputs.len().checked_mul(34).ok_or(SpendError::FeeOverflow)?).ok_or(SpendError::FeeOverflow)?;
    capacity = capacity.checked_add(extra.len()).ok_or(SpendError::FeeOverflow)?;
    let mut out = Vec::with_capacity(capacity);
    append_varint(2, &mut out); // TRANSACTION_VERSION_2
    append_varint(unlock_time, &mut out);
    append_varint(inputs.len() as u64, &mut out);
    for input in inputs {
        if input.amount != 0 { return Err(SpendError::InvalidConfidentialAmount); }
        if input.absolute_offsets.len() != protocol.ring_size {
            return Err(SpendError::WrongRingSize { expected: protocol.ring_size, actual: input.absolute_offsets.len() });
        }
        if input.absolute_offsets.windows(2).any(|w| w[1] <= w[0]) {
            return Err(SpendError::RingIndicesNotStrictlyIncreasing);
        }
        out.push(0x02); // txin_to_key
        append_varint(input.amount, &mut out);
        append_varint(input.absolute_offsets.len() as u64, &mut out);
        let mut previous = 0u64;
        for &absolute in &input.absolute_offsets {
            let relative = absolute.checked_sub(previous).ok_or(SpendError::RingIndicesNotStrictlyIncreasing)?;
            append_varint(relative, &mut out);
            previous = absolute;
        }
        out.extend_from_slice(&input.key_image);
    }
    append_varint(outputs.len() as u64, &mut out);
    for output in outputs {
        append_varint(0, &mut out); // confidential amount is zero in the public prefix
        out.push(0x02); // txout_to_key
        out.extend_from_slice(&output.public_key);
    }
    append_varint(extra.len() as u64, &mut out);
    out.extend_from_slice(extra);
    Ok(out)
}

/// Estimate the serialized RingCT transaction size using Nerva wallet2's size model.
/// `output_count` is the final output count including change. The estimate is suitable for fee
/// planning only; the final signed blob must be reweighed before it is submitted.
pub fn estimate_rct_tx_size(
    input_count: usize,
    protocol: SpendProtocol,
    output_count: usize,
    extra_size: usize,
) -> Result<usize, SpendError> {
    if input_count == 0 { return Err(SpendError::NoInputs); }
    if output_count == 0 { return Err(SpendError::NoOutputs); }
    if input_count > MAX_INPUTS || output_count > MAX_OUTPUTS { return Err(SpendError::TooManyItems); }
    if extra_size > MAX_EXTRA { return Err(SpendError::ExtraTooLarge); }
    validate_protocol(protocol)?;
    let checked_add = |a: usize, b: usize| a.checked_add(b).ok_or(SpendError::FeeOverflow);
    let checked_mul = |a: usize, b: usize| a.checked_mul(b).ok_or(SpendError::FeeOverflow);
    let mut size = 1usize + 6; // version/unlock header estimate
    size = checked_add(size, checked_mul(input_count, 1 + 6 + checked_mul(protocol.ring_size, 2)? + 32)?)?;
    size = checked_add(size, checked_mul(output_count, 6 + 32)?)?;
    size = checked_add(size, extra_size)?;
    size = checked_add(size, 1)?; // RingCT type byte

    let plus = protocol.range_proof == RangeProof::BulletproofPlus;
    let bulletproof = protocol.range_proof == RangeProof::Bulletproof2;
    if bulletproof || plus {
        let mut log_padded_outputs = 0usize;
        let mut padded = 1usize;
        while padded < output_count {
            padded = checked_mul(padded, 2)?;
            log_padded_outputs += 1;
        }
        let proof_terms = 2usize.checked_mul(6usize.checked_add(log_padded_outputs).ok_or(SpendError::FeeOverflow)?).ok_or(SpendError::FeeOverflow)?
            .checked_add(if plus { 6 } else { 9 }).ok_or(SpendError::FeeOverflow)?;
        size = checked_add(size, checked_mul(proof_terms, 32)?.checked_add(3).ok_or(SpendError::FeeOverflow)?)?;
    } else {
        return Err(SpendError::UnknownFork);
    }

    let signature_size_per_input = if protocol.signature == RingSignature::Clsag {
        checked_add(checked_mul(32, protocol.ring_size)?, 64)?
    } else {
        checked_add(checked_mul(64, protocol.ring_size)?, 32)?
    };
    size = checked_add(size, checked_mul(input_count, signature_size_per_input)?)?;
    size = checked_add(size, checked_mul(input_count, 32)?)?; // pseudo-outs
    size = checked_add(size, checked_mul(output_count, if plus { 8 } else { 64 })?)?; // ECDH info
    size = checked_add(size, checked_mul(output_count, 32)?)?; // output commitments
    size = checked_add(size, 4)?; // fee varint estimate
    Ok(size)
}

/// Estimate wallet2-compatible transaction weight for fee planning. `destination_count` excludes
/// the change output because Nerva's wallet2 estimator adds one change output internally.
pub fn estimate_transaction_weight(
    input_count: usize,
    protocol: SpendProtocol,
    destination_count: usize,
    extra_size: usize,
) -> Result<u64, SpendError> {
    if destination_count == 0 { return Err(SpendError::NoOutputs); }
    let output_count = destination_count.checked_add(1).ok_or(SpendError::FeeOverflow)?;
    let size = estimate_rct_tx_size(input_count, protocol, output_count, extra_size)?;
    let mut weight = u64::try_from(size).map_err(|_| SpendError::FeeOverflow)?;
    if protocol.range_proof == RangeProof::BulletproofPlus && output_count > 2 {
        // Nerva's HF14 daemon checks type-7 fees against Bulletproof+ clawback weight.
        let mut log_padded_outputs = 2usize;
        let mut padded = 4usize;
        while padded < output_count {
            padded = padded.checked_mul(2).ok_or(SpendError::FeeOverflow)?;
            log_padded_outputs += 1;
        }
        let bp_base = (32u64 * (6 + 7 * 2)) / 2;
        let nlr = 2u64.checked_mul(6 + log_padded_outputs as u64).ok_or(SpendError::FeeOverflow)?;
        let bp_size = 32u64.checked_mul(6 + nlr).ok_or(SpendError::FeeOverflow)?;
        let bp_padded = bp_base.checked_mul(padded as u64).ok_or(SpendError::FeeOverflow)?;
        let clawback = bp_padded.checked_sub(bp_size).ok_or(SpendError::FeeOverflow)?
            .checked_mul(4).ok_or(SpendError::FeeOverflow)? / 5;
        weight = weight.checked_add(clawback).ok_or(SpendError::FeeOverflow)?;
    }
    Ok(weight)
}

/// Matches Nerva wallet2 `calculate_fee`: KiB rounded up, fee-per-KiB times multiplier. For
/// HF14 type 7 use `estimate_transaction_weight` or the final daemon-compatible transaction
/// weight, not the raw transaction blob length.
pub fn calculate_fee(fee_per_kib: u64, billable_bytes_or_weight: usize, multiplier: u64) -> Result<u64, SpendError> {
    let kib = billable_bytes_or_weight.checked_add(1023).ok_or(SpendError::FeeOverflow)? / 1024;
    let kib = u64::try_from(kib).map_err(|_| SpendError::FeeOverflow)?;
    kib.checked_mul(fee_per_kib).and_then(|n| n.checked_mul(multiplier)).ok_or(SpendError::FeeOverflow)
}

fn append_varint(value: u64, out: &mut Vec<u8>) { out.extend(varint::encode(value)); }

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn mainnet_fork_profiles_are_consensus_aware() {
        let hf13 = protocol_for_hard_fork(Network::Mainnet, 13).unwrap();
        assert_eq!(hf13.hard_fork, 13);
        assert_eq!(hf13.ring_size, 5);
        assert_eq!(hf13.ringct_type, RingCtType::Bulletproof2);
        assert_eq!(hf13.signature, RingSignature::Mlsag);
        let hf14 = protocol_for_hard_fork(Network::Mainnet, 14).unwrap();
        assert_eq!(hf14.hard_fork, 14);
        assert_eq!(hf14.ring_size, 16);
        assert_eq!(hf14.ringct_type, RingCtType::BulletproofPlus);
        assert_eq!(hf14.signature, RingSignature::Clsag);
    }

    #[test]
    fn mainnet_legacy_format_is_not_guessed() {
        assert_eq!(protocol_for_hard_fork(Network::Mainnet, 12), Err(SpendError::UnknownFork));
        assert_eq!(protocol_for_hard_fork(Network::Mainnet, 15), Err(SpendError::UnknownFork));
    }

    #[test]
    fn fee_rounds_up_to_whole_kib_like_upstream() {
        assert_eq!(calculate_fee(400, 0, 1).unwrap(), 0);
        assert_eq!(calculate_fee(400, 1, 1).unwrap(), 400);
        assert_eq!(calculate_fee(400, 1024, 2).unwrap(), 800);
        assert_eq!(calculate_fee(400, 1025, 2).unwrap(), 1600);
    }

    #[test]
    fn transaction_size_estimates_use_fork_signature_formats() {
        let legacy = protocol_for_hard_fork(Network::Mainnet, 13).unwrap();
        let modern = protocol_for_hard_fork(Network::Mainnet, 14).unwrap();
        let legacy_size = estimate_rct_tx_size(1, legacy, 2, 33).unwrap();
        let modern_size = estimate_rct_tx_size(1, modern, 2, 33).unwrap();
        assert!(legacy_size > 0 && modern_size > 0);
        assert_ne!(legacy_size, modern_size);
        assert!(estimate_transaction_weight(1, modern, 2, 33).unwrap() >= modern_size as u64);
    }

    #[test]
    fn serializer_requires_ring_size_for_selected_fork() {
        let protocol = protocol_for_hard_fork(Network::Mainnet, 13).unwrap();
        let input = KeyInputPrefix { amount: 0, absolute_offsets: vec![1, 5, 9, 20, 21], key_image: [3; 32] };
        let output = KeyOutputPrefix { public_key: [5; 32] };
        let blob = serialize_v2_prefix(protocol, 0, &[input.clone()], &[output.clone()], &[1, 2, 3]).unwrap();
        assert_eq!(crate::tx_prefix::parse_transaction_prefix(&blob).unwrap().prefix_bytes, blob.len());
        let short = KeyInputPrefix { absolute_offsets: vec![1, 3], ..input };
        assert!(matches!(serialize_v2_prefix(protocol, 0, &[short], &[output], &[]), Err(SpendError::WrongRingSize { .. })));
    }

    #[test]
    fn valid_ring_has_sorted_unique_prime_order_keys_and_real_member() {
        use crate::crypto::{public_key_from_secret, SecretKey};
        let protocol = protocol_for_hard_fork(Network::Mainnet, 13).unwrap();
        let members = (1u8..=5).map(|i| {
            let mut secret_bytes = [0u8; 32];
            secret_bytes[0] = i;
            let secret = SecretKey::from_bytes(secret_bytes).unwrap();
            RingMember { global_output_index: i as u64, public_key: public_key_from_secret(&secret) }
        }).collect();
        let ring = InputRing { real_output_index: 3, members };
        assert_eq!(validate_input_ring(protocol, &ring), Ok(()));
    }

    #[test]
    fn invalid_ring_size_fails_closed() {
        let protocol = protocol_for_hard_fork(Network::Mainnet, 13).unwrap();
        let ring = InputRing { real_output_index: 2, members: Vec::new() };
        assert_eq!(validate_input_ring(protocol, &ring), Err(SpendError::WrongRingSize { expected: 5, actual: 0 }));
    }
}
