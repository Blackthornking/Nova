//! High-level Rust wallet scan orchestration.
//!
//! This facade binds encrypted account storage, the core transaction scanner and persistent scan
//! state together, and assigns output key images for spent-output tracking. It deliberately does not broadcast or sign transactions. Before calling
//! `scan_transaction_metadata`, the caller must independently validate that the transaction is in
//! the indicated canonical block and that the block chain is authenticated; this module does not
//! verify block inclusion, range proofs or transaction signatures.
use crate::{
    scan_journal::{BlockRef, ReconcileReport},
    storage::{StorageError, UnlockedWallet, WalletFile},
    tracking::{BalanceSummary, Direction, OutputId, TrackingError, TransactionRecord, WalletScanState},
    EnginePhase,
};
use nerva_core::{
    account::AccountKeys,
    address::{Address, AddressError, AddressKind},
    crypto::{derive_public_key, derive_secret_key, derive_subaddress_secret_key, generate_key_derivation, generate_key_image, hash_to_scalar, CryptoError, SecretKey},
    mnemonic::encode_seed,
    scanner::{AddressScanner, OwnedOutputAmount, ScanError, TransactionScanError},
};
use std::path::Path;
use thiserror::Error;
use zeroize::Zeroize;

#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum WalletEngineError {
    #[error("account key error: {0}")]
    Crypto(#[from] CryptoError),
    #[error("address encoding failed: {0}")]
    Address(#[from] AddressError),
    #[error("scanner setup failed: {0}")]
    ScannerSetup(#[from] ScanError),
    #[error("transaction scan failed: {0}")]
    TransactionScan(#[from] TransactionScanError),
    #[error("wallet scan tracking failed: {0}")]
    Tracking(#[from] TrackingError),
    #[error("wallet storage failed: {0}")]
    Storage(#[from] StorageError),
    #[error("output index cannot fit the persisted wallet format")]
    OutputIndex,
    #[error("scan completion height does not match the current canonical tip")]
    ScanNotAtTip,
    #[error("watch-only wallet cannot create key images")]
    WatchOnlyKeyImage,
    #[error("subaddress key-image derivation requires the wallet primary address")]
    SubaddressRequiresPrimary,
    #[error("the supplied subaddress index does not match the derived address keys")]
    SubaddressIndexMismatch,
    #[error("output public key does not match this wallet's derivation")]
    OutputKeyMismatch,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ProcessedTransaction {
    pub txid: [u8; 32],
    pub block_height: u64,
    pub received_outputs: Vec<OwnedOutputAmount>,
    pub spent_outputs: Vec<OutputId>,
}

pub struct WalletEngine {
    wallet_name: String,
    restore_height: u64,
    address: Address,
    scanner: AddressScanner,
    view_secret: SecretKey,
    spend_secret: Option<SecretKey>,
    seed_compatible: bool,
    scan_state: WalletScanState,
    phase: EnginePhase,
}

impl WalletEngine {
    pub fn from_account(account: AccountKeys, wallet_name: impl Into<String>, restore_height: u64) -> Result<Self, WalletEngineError> {
        // This duplication is short-lived and explicit. The consumed AccountKeys then zeroises its
        // original secret handles as it is dropped; the engine's copies are also zeroised on drop.
        let address = account.address().clone();
        let seed_compatible = hash_to_scalar(account.spend_secret().as_bytes()).to_bytes() == *account.view_secret().as_bytes();
        let view_secret = SecretKey::from_bytes(*account.view_secret().as_bytes())?;
        let scanner_view_secret = SecretKey::from_bytes(*view_secret.as_bytes())?;
        let spend_secret = SecretKey::from_bytes(*account.spend_secret().as_bytes())?;
        let scanner = AddressScanner::new(&address, scanner_view_secret)?;
        Ok(Self {
            wallet_name: wallet_name.into(), restore_height, address, scanner, view_secret,
            spend_secret: Some(spend_secret), seed_compatible, scan_state: WalletScanState::default(), phase: EnginePhase::Opening,
        })
    }

    pub fn from_unlocked_wallet(wallet: UnlockedWallet, scan_state: WalletScanState) -> Result<Self, WalletEngineError> {
        let (wallet_name, restore_height, address, view_secret, spend_secret) = wallet.into_engine_parts();
        let seed_compatible = spend_secret.as_ref().is_some_and(|spend|
            hash_to_scalar(spend.as_bytes()).to_bytes() == *view_secret.as_bytes());
        let scanner_view_secret = SecretKey::from_bytes(*view_secret.as_bytes())?;
        let scanner = AddressScanner::new(&address, scanner_view_secret)?;
        Ok(Self { wallet_name, restore_height, address, scanner, view_secret, spend_secret, seed_compatible, scan_state, phase: EnginePhase::Opening })
    }

    pub fn open_wallet(
        wallet_path: impl AsRef<Path>,
        scan_state_path: impl AsRef<Path>,
        password: &[u8],
    ) -> Result<Self, WalletEngineError> {
        let wallet = WalletFile::open_path(wallet_path, password)?;
        let scan_state = WalletScanState::load_or_default(scan_state_path)?;
        Self::from_unlocked_wallet(wallet, scan_state)
    }

    pub fn wallet_name(&self) -> &str { &self.wallet_name }
    pub fn restore_height(&self) -> u64 { self.restore_height }
    pub fn address(&self) -> &Address { &self.address }
    pub fn address_string(&self) -> Result<String, WalletEngineError> { Ok(self.address.encode()?) }
    pub fn is_watch_only(&self) -> bool { self.spend_secret.is_none() }
    pub fn phase(&self) -> &EnginePhase { &self.phase }
    pub fn scan_state(&self) -> &WalletScanState { &self.scan_state }
    pub fn balance_summary(&self) -> Result<BalanceSummary, WalletEngineError> { Ok(self.scan_state.balance_summary()?) }

    /// Derive the key image for one primary-address output. The caller must pass the actual
    /// transaction public key and canonical output index. The derived one-time public key is
    /// compared to the transaction output before returning any key image.
    pub fn key_image_for_primary_output(
        &self,
        transaction_public_key: &[u8; 32],
        output_index: u64,
        output_public_key: &[u8; 32],
    ) -> Result<[u8; 32], WalletEngineError> {
        if self.address.kind == AddressKind::Subaddress {
            return Err(WalletEngineError::SubaddressRequiresPrimary);
        }
        let spend_secret = self.spend_secret.as_ref().ok_or(WalletEngineError::WatchOnlyKeyImage)?;
        let derivation = generate_key_derivation(transaction_public_key, &self.view_secret)?;
        let expected_public = derive_public_key(&derivation, output_index, &self.address.spend_public_key)?;
        if expected_public != *output_public_key { return Err(WalletEngineError::OutputKeyMismatch); }
        let mut one_time_bytes = derive_secret_key(&derivation, output_index, spend_secret);
        let one_time_secret_result = SecretKey::from_bytes(one_time_bytes);
        one_time_bytes.zeroize();
        let one_time_secret = one_time_secret_result?;
        Ok(generate_key_image(output_public_key, &one_time_secret)?)
    }

    /// Derive a key image for an output sent to an explicitly indexed subaddress. This does not
    /// discover/persist subaddress indexes; the caller must obtain the correct (major, minor) pair
    /// from a complete subaddress scan. Both the subaddress keys and the one-time output key are
    /// checked before the key image is returned.
    pub fn key_image_for_subaddress_output(
        &self,
        transaction_public_key: &[u8; 32],
        output_index: u64,
        output_public_key: &[u8; 32],
        major_index: u32,
        minor_index: u32,
    ) -> Result<[u8; 32], WalletEngineError> {
        if self.address.kind != AddressKind::Standard {
            return Err(WalletEngineError::SubaddressRequiresPrimary);
        }
        let spend_secret = self.spend_secret.as_ref().ok_or(WalletEngineError::WatchOnlyKeyImage)?;
        let subaddress = Address::derive_subaddress(
            &self.address, spend_secret, &self.view_secret, major_index, minor_index,
        )?;
        if major_index != 0 || minor_index != 0 {
            // Ensures the caller-provided index maps to this exact Nerva subaddress.
            if subaddress.kind != AddressKind::Subaddress {
                return Err(WalletEngineError::SubaddressIndexMismatch);
            }
        }
        let derivation = generate_key_derivation(transaction_public_key, &self.view_secret)?;
        let expected_public = derive_public_key(&derivation, output_index, &subaddress.spend_public_key)?;
        if expected_public != *output_public_key { return Err(WalletEngineError::OutputKeyMismatch); }
        let mut one_time_bytes = derive_subaddress_secret_key(
            &derivation, output_index, spend_secret, &self.view_secret, major_index, minor_index,
        );
        let one_time_secret_result = SecretKey::from_bytes(one_time_bytes);
        one_time_bytes.zeroize();
        let one_time_secret = one_time_secret_result?;
        Ok(generate_key_image(output_public_key, &one_time_secret)?)
    }

    /// Return the canonical English recovery phrase only for a spend-capable account. The caller
    /// is responsible for an offline, explicitly-confirmed backup screen and must never log it.
    pub fn recovery_seed(&self) -> Option<String> {
        if !self.seed_compatible { return None; }
        self.spend_secret.as_ref().map(|secret| encode_seed(secret.as_bytes()))
    }

    /// Reconcile the scan checkpoint to a trusted canonical header window. This removes stale
    /// noncanonical records and resets spends whose transaction was removed by a reorg.
    pub fn reconcile_chain(&mut self, canonical: &[BlockRef]) -> Result<ReconcileReport, WalletEngineError> {
        let report = self.scan_state.reconcile_chain(canonical)?;
        if let (Some(first), Some(tip)) = (canonical.first(), canonical.last()) {
            self.phase = EnginePhase::Scanning { height: first.height, target_height: tip.height };
        } else {
            self.phase = EnginePhase::Opening;
        }
        Ok(report)
    }

    /// Scan one transaction that the caller has already associated with a canonical block.
    /// This extracts key images, scans for owned outputs, recovers receiver amounts and checks each
    /// recovered amount against its output commitment. It does NOT verify transaction inclusion,
    /// RingCT proofs or signatures; do not feed untrusted raw transactions into a balance display.
    pub fn scan_transaction_metadata(
        &mut self,
        txid: [u8; 32],
        block: &BlockRef,
        raw_transaction: &[u8],
    ) -> Result<ProcessedTransaction, WalletEngineError> {
        if !self.scan_state.journal().blocks().iter().any(|b| b.height == block.height && b.hash == block.hash) {
            return Err(TrackingError::UnknownBlock.into());
        }
        let parsed = nerva_core::ringct::parse_transaction(raw_transaction)
            .map_err(TransactionScanError::Transaction)?;
        let received_outputs = self.scanner.scan_parsed_transaction(&parsed)?;
        let mut records = Vec::with_capacity(received_outputs.len());
        let mut key_images = Vec::with_capacity(received_outputs.len());
        let mut received_amount = 0u64;
        // For spend-capable primary/integrated wallets, calculate each owned output's key image
        // from the exact tx-public-key slot and output key. Subaddress scans still require a
        // separately persisted (major, minor) index and therefore fail closed without auto-assigning.
        let tx_public_keys = if self.spend_secret.is_some()
            && self.address.kind != AddressKind::Subaddress
            && !received_outputs.is_empty()
        {
            Some(parsed.prefix.parsed_extra()
                .map_err(TransactionScanError::Extra)?
                .tx_public_keys_for_outputs(parsed.prefix.outputs.len())
                .map_err(TransactionScanError::Extra)?)
        } else { None };
        for output in &received_outputs {
            let output_index = u32::try_from(output.output_index).map_err(|_| WalletEngineError::OutputIndex)?;
            received_amount = received_amount.checked_add(output.amount).ok_or(TrackingError::AmountOverflow)?;
            let id = OutputId { txid, output_index };
            if let Some(tx_keys) = &tx_public_keys {
                let tx_public_key = tx_keys.get(output.tx_public_key_slot)
                    .ok_or_else(|| TransactionScanError::Scan(ScanError::MissingPublicKeySlot(output.tx_public_key_slot)))?;
                let output_public_key = match &parsed.prefix.outputs
                    .get(usize::try_from(output.output_index).map_err(|_| WalletEngineError::OutputIndex)?)
                    .ok_or(TransactionScanError::OutputIndex)?.target
                {
                    nerva_core::tx_prefix::OutputTarget::ToKey(key) => key,
                    _ => return Err(TransactionScanError::OutputIndex.into()),
                };
                let image = self.key_image_for_primary_output(tx_public_key, output.output_index, output_public_key)?;
                key_images.push((id.clone(), image));
            }
            records.push((id, output.amount));
        }
        // Detect a duplicate key image before mutating any scan records. A repeated image would
        // otherwise make the ownership/spent table ambiguous.
        let mut seen_key_images = std::collections::HashSet::new();
        let existing_key_images: std::collections::HashMap<[u8; 32], OutputId> = self.scan_state.outputs()
            .filter_map(|old| old.key_image.map(|image| (image, old.id.clone())))
            .collect();
        for (id, image) in &key_images {
            if !seen_key_images.insert(*image)
                || existing_key_images.get(image).is_some_and(|old_id| old_id != id)
            {
                return Err(TrackingError::DuplicateKeyImage.into());
            }
        }
        let matching_spends = self.scan_state.matching_spend_outputs(&txid, &parsed.prefix);
        let mut spent_amount = 0u64;
        for (_, amount) in &matching_spends {
            spent_amount = spent_amount.checked_add(*amount).ok_or(TrackingError::AmountOverflow)?;
        }
        let is_coinbase = parsed.prefix.inputs.iter().any(|input|
            matches!(input, nerva_core::tx_prefix::TxInput::Generation { .. }));
        let relevant = !records.is_empty() || !matching_spends.is_empty();
        if relevant { self.scan_state.can_record_transaction(&txid, block)?; }

        // Validate and insert incoming output records atomically before changing spend flags.
        self.scan_state.record_outputs(&records, block)?;
        self.scan_state.assign_key_images(&key_images)?;
        let spent_outputs = self.scan_state.apply_spend_inputs(txid, &parsed.prefix);
        if relevant {
            let direction = match (is_coinbase, !records.is_empty(), !spent_outputs.is_empty()) {
                (true, true, _) => Direction::Coinbase,
                (_, true, true) => Direction::SelfTransfer,
                (_, true, false) => Direction::Incoming,
                (_, false, true) => Direction::Outgoing,
                (_, false, false) => unreachable!("relevance was derived from output or spend records"),
            };
            let amount = if matches!(direction, Direction::Outgoing) { spent_amount } else { received_amount };
            self.scan_state.record_transaction(TransactionRecord {
                txid, block_height: block.height, block_hash: block.hash, direction,
                amount, fee: parsed.ringct.fee,
            })?;
        }
        Ok(ProcessedTransaction { txid, block_height: block.height, received_outputs, spent_outputs })
    }

    /// Mark a scan complete only after the caller has processed all transactions through the
    /// current canonical tip. The engine cannot infer completeness from individual transactions.
    pub fn mark_scan_complete(&mut self, height: u64) -> Result<(), WalletEngineError> {
        if self.scan_state.journal().tip().map(|tip| tip.height) != Some(height) {
            return Err(WalletEngineError::ScanNotAtTip);
        }
        self.phase = EnginePhase::Ready { height };
        Ok(())
    }

    pub fn save_scan_state(&self, path: impl AsRef<Path>) -> Result<(), WalletEngineError> {
        self.scan_state.save_atomic(path)?;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nerva_core::crypto::SecretKey;

    fn secret(n: u8) -> SecretKey { let mut bytes=[0u8;32]; bytes[0]=n; SecretKey::from_bytes(bytes).unwrap() }

    #[test]
    fn derives_primary_output_key_image_only_for_owned_output() {
        use nerva_core::crypto::{derive_public_key, generate_key_derivation, public_key_from_secret};
        let account = AccountKeys::from_spend_secret(secret(7)).unwrap();
        let address = account.address().clone();
        let view_secret = SecretKey::from_bytes(*account.view_secret().as_bytes()).unwrap();
        let tx_secret = secret(13);
        let tx_public_key = public_key_from_secret(&tx_secret);
        let derivation = generate_key_derivation(&tx_public_key, &view_secret).unwrap();
        let output_public_key = derive_public_key(&derivation, 4, &address.spend_public_key).unwrap();
        let engine = WalletEngine::from_account(account, "key-image-test", 0).unwrap();
        let image = engine.key_image_for_primary_output(&tx_public_key, 4, &output_public_key).unwrap();
        assert!(nerva_core::crypto::decode_public_key(&image).is_ok());
        assert_eq!(engine.key_image_for_primary_output(&tx_public_key, 5, &output_public_key), Err(WalletEngineError::OutputKeyMismatch));
    }

    #[test]
    fn derives_subaddress_output_key_image_from_explicit_index() {
        use nerva_core::{
            address::Address,
            crypto::{derive_public_key, generate_key_derivation},
        };
        let account = AccountKeys::from_spend_secret(secret(7)).unwrap();
        let primary_address = account.address().clone();
        let view_secret = SecretKey::from_bytes(*account.view_secret().as_bytes()).unwrap();
        let spend_secret = SecretKey::from_bytes(*account.spend_secret().as_bytes()).unwrap();
        let subaddress = Address::derive_subaddress(&primary_address, &spend_secret, &view_secret, 2, 9).unwrap();
        let tx_secret = secret(13);
        // Nerva uses R = r * D for a transaction whose single destination is a subaddress.
        let tx_public_key = nerva_core::crypto::multiply_public_key(&subaddress.spend_public_key, &tx_secret).unwrap();
        let derivation = generate_key_derivation(&tx_public_key, &view_secret).unwrap();
        let sender_derivation = generate_key_derivation(&subaddress.view_public_key, &tx_secret).unwrap();
        assert_eq!(derivation, sender_derivation);
        let output_public_key = derive_public_key(&derivation, 4, &subaddress.spend_public_key).unwrap();
        let engine = WalletEngine::from_account(account, "subaddress-key-image-test", 0).unwrap();
        let result = engine.key_image_for_subaddress_output(&tx_public_key, 4, &output_public_key, 2, 9).unwrap();
        assert_eq!(result.iter().map(|b| format!("{b:02x}")).collect::<String>(), "c037278fc2282c0c0a4189e200a870bf2803c2cd7cfff1c77b68c70cd65c00eb");
        assert_eq!(engine.key_image_for_subaddress_output(&tx_public_key, 4, &output_public_key, 2, 10), Err(WalletEngineError::OutputKeyMismatch));
        assert_eq!(engine.key_image_for_subaddress_output(&tx_public_key, 4, &output_public_key, 0, 0), Err(WalletEngineError::OutputKeyMismatch));
    }

    #[test]
    fn opens_scan_engine_for_spend_capable_account_and_exports_expected_address() {
        let account=AccountKeys::from_spend_secret(secret(7)).unwrap();
        let expected=account.address().encode().unwrap();
        let engine=WalletEngine::from_account(account,"test",0).unwrap();
        assert_eq!(engine.address_string().unwrap(),expected);
        assert!(!engine.is_watch_only());
        assert_eq!(engine.phase(),&EnginePhase::Opening);
        assert!(engine.recovery_seed().unwrap().split_whitespace().count()==25);
    }

    #[test]
    fn custom_key_wallet_does_not_claim_seed_phrase_restores_the_same_address() {
        let account=AccountKeys::from_secret_keys(secret(7),secret(11)).unwrap();
        let engine=WalletEngine::from_account(account,"custom",0).unwrap();
        assert!(engine.recovery_seed().is_none());
    }

    #[test]
    fn scans_a_transparent_coinbase_output_and_records_reorg_anchored_history() {
        use nerva_core::{
            crypto::{derive_public_key, generate_key_derivation, public_key_from_secret},
            varint,
        };
        let account = AccountKeys::from_spend_secret(secret(7)).unwrap();
        let tx_secret = secret(13);
        let tx_public_key = public_key_from_secret(&tx_secret);
        let derivation = generate_key_derivation(&tx_public_key, account.view_secret()).unwrap();
        let output_key = derive_public_key(&derivation, 0, &account.address().spend_public_key).unwrap();
        let block = BlockRef { height: 10, hash: [0x10; 32], parent_hash: [0; 32] };
        let mut engine = WalletEngine::from_account(account, "integration-test", 0).unwrap();
        engine.reconcile_chain(&[block.clone()]).unwrap();

        // Synthetic v2 coinbase with one transparent output, one primary tx public key,
        // and a null RingCT type. This is a parser/scanner integration fixture, not a
        // consensus-valid block or a broadcastable transaction.
        let mut raw = Vec::new();
        raw.extend(varint::encode(2)); // transaction version
        raw.extend(varint::encode(0)); // unlock time
        raw.extend(varint::encode(1)); raw.push(0xff); raw.extend(varint::encode(block.height));
        raw.extend(varint::encode(1)); // outputs
        raw.extend(varint::encode(50)); raw.push(2); raw.extend_from_slice(&output_key);
        let mut extra = vec![1]; extra.extend_from_slice(&tx_public_key);
        raw.extend(varint::encode(extra.len() as u64)); raw.extend(extra);
        raw.push(0); // RCTTypeNull

        let processed = engine.scan_transaction_metadata([0x77; 32], &block, &raw).unwrap();
        assert_eq!(processed.received_outputs.len(), 1);
        assert_eq!(processed.received_outputs[0].amount, 50);
        assert_eq!(engine.balance_summary().unwrap().unspent, 50);
        let owned_output = engine.scan_state().outputs().next().unwrap();
        assert!(owned_output.key_image.is_some(), "spend-capable primary outputs should receive key images");
        let history = engine.scan_state().transactions().next().unwrap();
        assert_eq!(history.txid, [0x77; 32]);
        assert_eq!(history.direction, Direction::Coinbase);
        assert_eq!(history.amount, 50);

        // Feed a second synthetic transaction containing the exact image assigned above. It
        // exercises the full Rust path from owned-output scan -> key image -> input matching.
        let spending_block = BlockRef { height: 11, hash: [0x11; 32], parent_hash: block.hash };
        engine.reconcile_chain(&[block.clone(), spending_block.clone()]).unwrap();
        let key_image = engine.scan_state().outputs().next().unwrap().key_image.unwrap();
        let unrelated_key = public_key_from_secret(&secret(21));
        let spending_tx_public_key = public_key_from_secret(&secret(22));
        let mut spending_raw = Vec::new();
        spending_raw.extend(varint::encode(2)); // version
        spending_raw.extend(varint::encode(0)); // unlock time
        spending_raw.extend(varint::encode(1)); // one key input
        spending_raw.push(0x02); // txin_to_key
        spending_raw.extend(varint::encode(0)); // confidential amount
        spending_raw.extend(varint::encode(1)); // one relative output offset
        spending_raw.extend(varint::encode(1));
        spending_raw.extend_from_slice(&key_image);
        spending_raw.extend(varint::encode(1)); // one unrelated output
        spending_raw.extend(varint::encode(42));
        spending_raw.push(0x02);
        spending_raw.extend_from_slice(&unrelated_key);
        let mut spending_extra = vec![1];
        spending_extra.extend_from_slice(&spending_tx_public_key);
        spending_raw.extend(varint::encode(spending_extra.len() as u64));
        spending_raw.extend(spending_extra);
        spending_raw.push(0); // synthetic RCTTypeNull suffix; not a consensus fixture
        let spent = engine.scan_transaction_metadata([0x88; 32], &spending_block, &spending_raw).unwrap();
        assert_eq!(spent.spent_outputs, vec![OutputId { txid: [0x77; 32], output_index: 0 }]);
        let balances = engine.balance_summary().unwrap();
        assert_eq!(balances.unspent, 0);
        assert_eq!(balances.spent, 50);
        let outgoing = engine.scan_state().transactions().find(|tx| tx.txid == [0x88; 32]).unwrap();
        assert_eq!(outgoing.direction, Direction::Outgoing);
        assert_eq!(outgoing.amount, 50);
    }

    #[test]
    fn refuses_to_mark_scan_complete_before_canonical_tip() {
        let account=AccountKeys::from_spend_secret(secret(7)).unwrap();
        let mut engine=WalletEngine::from_account(account,"test",0).unwrap();
        assert_eq!(engine.mark_scan_complete(0),Err(WalletEngineError::ScanNotAtTip));
    }
}
