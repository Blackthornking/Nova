# Nerva key-image differential vectors

These fixed vectors were generated from the supplied Nerva C crypto implementation (`src/crypto/crypto-ops.c`, `crypto-ops-data.c`, `hash.c`, and `keccak.c`). They are regression inputs for the Rust primitives, not proofs of a complete signed transaction or live-network compatibility.

## Primary output

- One-time secret scalar (little-endian): `1300000000000000000000000000000000000000000000000000000000000000`
- Output public key: `b9551d690261fe83305f433f8230182ef45cd6ddb65b7c2247435ad9935a183f`
- Expected key image: `46befb67063f2d217bcc0a371f148f6a6348fc53ff68ac29e9348f3cfe76a4dc`

## Subaddress output

- Primary spend secret: scalar 7 (little-endian)
- View secret: `Hs(spend_secret)` using Nerva Keccak-256 + scalar reduction
- Subaddress index: `(major=2, minor=9)`
- Transaction secret: scalar 13 (little-endian)
- Output index: `4`
- Derived subaddress spend public key: `249b2cbee3261df3d10104897d6016667aaa9b0b076dbbdbf0cc29edcaa645ef`
- Transaction public key (`R = rD`): `d80030b4dde1d43793e531b7921f289b0f4c8dfb84fb1cfa2f3b9b034c14b0d6`
- Key derivation: `fc5f06536c5fff8c32e27753c41055838e477928fcef2361d2db0237a229563b`
- One-time output public key: `634cf29e2da0bafa8d02fcfac37eea9aa0856a717461fa0edfbe54df9d8381db`
- Derived one-time secret: `47358e8689aa4da8f578cc649da5dc77286dce0e392895a5e99927236c13580c`
- Expected key image: `c037278fc2282c0c0a4189e200a870bf2803c2cd7cfff1c77b68c70cd65c00eb`

The key-image calculation is the legacy CryptoNote operation `I = x * Hp(P)`, where Nerva computes `Hp(P)` using `cn_fast_hash(P)`, `ge_fromfe_frombytes_vartime`, then multiplication by the cofactor. The Rust implementation uses `monero-generators` for the historic map and passes the compressed point across the dependency boundary before multiplication with the wallet's Dalek scalar.

The `nerva-core` tests assert these values, and `nerva-wallet` tests assert explicit-index subaddress derivation plus key-image assignment for primary outputs. Rust/Cargo tests have not been run in the current assembly environment because those tools are unavailable; execute `cargo test --workspace` from `rust-engine/` before treating the vectors as verified Rust passes.
