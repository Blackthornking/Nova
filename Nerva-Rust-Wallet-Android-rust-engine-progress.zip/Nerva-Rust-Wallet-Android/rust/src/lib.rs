#![allow(clippy::needless_return)]

use axum::{
    body::Body,
    extract::{DefaultBodyLimit, Query, State},
    http::{header, HeaderMap, HeaderValue, Request, StatusCode},
    middleware::{self, Next},
    response::{IntoResponse, Response},
    routing::{get, post},
    Json, Router,
};
use rand::{rngs::OsRng, RngCore};
use reqwest::Client;
use serde_json::{json, Map, Number, Value};
use std::{
    collections::HashMap,
    net::TcpListener as StdTcpListener,
    path::{Path, PathBuf},
    process::{Child, Command, Stdio},
    sync::{
        atomic::{AtomicBool, AtomicU32, Ordering},
        Arc, Mutex, OnceLock, RwLock,
    },
    thread,
    time::{Duration, SystemTime, UNIX_EPOCH},
};
use tokio::{net::TcpListener, sync::watch, time::timeout};
use tower_http::cors::CorsLayer;

const UI_PORT: u16 = 8765;
const RPC_PORT: u16 = 18082;
const DEFAULT_DAEMON: &str = "node.nerva.one:17566";
const MAX_BODY: usize = 128 * 1024;
const MAX_RPC_RESPONSE: usize = 2 * 1024 * 1024;
const WALLET_NAME: &str = "nerva_wallet";
const IMPORT_TMP_NAME: &str = "import_tmp";
const BAD_REPLY: &str = "Wallet RPC returned an unreadable reply";
const PREPARED_TRANSFER_TTL: Duration = Duration::from_secs(180);
const MAX_PENDING_TRANSFERS: usize = 1;
const MAX_TX_METADATA_BYTES: usize = 1024 * 1024;

static APP: OnceLock<Arc<AppState>> = OnceLock::new();
static STARTED: AtomicBool = AtomicBool::new(false);
static SHUTDOWN: OnceLock<watch::Sender<bool>> = OnceLock::new();

#[derive(Clone)]
struct RpcConfig {
    url: String,
    username: String,
    password: String,
}

struct AppState {
    token: String,
    rpc: RwLock<RpcConfig>,
    daemon: RwLock<String>,
    connected: AtomicBool,
    rpc_version: RwLock<Option<String>>,
    wallet_binary: PathBuf,
    wallet_dir: PathBuf,
    wallet_password: String,
    engine_dir: PathBuf,
    child: Mutex<Option<Child>>,
    digest_nonce_count: AtomicU32,
    pending_transfers: Mutex<HashMap<String, PendingTransfer>>,
    client: Client,
}

impl AppState {
    fn new(binary: PathBuf, wallet_dir: PathBuf, daemon: String, token: String, wallet_password: String) -> Self {
        let mut password_bytes = [0u8; 32];
        OsRng.fill_bytes(&mut password_bytes);
        let password = hex::encode(password_bytes);
        let engine_dir = binary.parent().unwrap_or(Path::new(".")).to_path_buf();
        Self {
            token,
            rpc: RwLock::new(RpcConfig {
                url: format!("http://127.0.0.1:{RPC_PORT}"),
                username: "nerva".to_string(),
                password,
            }),
            daemon: RwLock::new(daemon),
            connected: AtomicBool::new(false),
            rpc_version: RwLock::new(None),
            wallet_binary: binary,
            wallet_dir,
            wallet_password,
            engine_dir,
            child: Mutex::new(None),
            digest_nonce_count: AtomicU32::new(0),
            pending_transfers: Mutex::new(HashMap::new()),
            client: Client::builder()
                .connect_timeout(Duration::from_secs(5))
                .timeout(Duration::from_secs(125))
                .redirect(reqwest::redirect::Policy::none())
                .build()
                .expect("reqwest client construction is infallible with fixed options"),
        }
    }

    fn start_engine(&self) -> Result<(), String> {
        if !self.wallet_binary.is_file() {
            return Err(format!("Nerva wallet engine not found at {}", self.wallet_binary.display()));
        }
        let mut guard = self.child.lock().map_err(|_| "Engine process lock failed".to_string())?;
        let existing_status = match guard.as_mut() { Some(child) => Some(child.try_wait()), None => None };
        match existing_status {
            Some(Ok(None)) => {
                // Restarting after a daemon configuration change takes the child out deliberately below.
                return Ok(());
            }
            Some(Ok(Some(_))) | Some(Err(_)) => { let _ = guard.take(); }
            None => {}
        }
        let cfg = self.rpc.read().map_err(|_| "RPC config lock failed".to_string())?.clone();
        let daemon = self.daemon.read().map_err(|_| "Daemon config lock failed".to_string())?.clone();
        std::fs::create_dir_all(&self.wallet_dir).map_err(|e| format!("Cannot create private wallet directory: {e}"))?;
        let login = format!("{}:{}", cfg.username, cfg.password);
        // Engine output goes to a private log so start-up problems can be diagnosed from Settings.
        let (out_io, err_io) = match std::fs::File::create(self.wallet_dir.join("engine.log")) {
            Ok(f) => match f.try_clone() { Ok(g) => (Stdio::from(f), Stdio::from(g)), Err(_) => (Stdio::from(f), Stdio::null()) },
            Err(_) => (Stdio::null(), Stdio::null()),
        };
        let mut child = Command::new("/system/bin/linker64")
            .arg(&self.wallet_binary)
            .arg("--wallet-dir").arg(&self.wallet_dir)
            .arg("--daemon-address").arg(&daemon)
            .arg("--rpc-bind-ip").arg("127.0.0.1")
            .arg("--rpc-bind-port").arg(RPC_PORT.to_string())
            .arg("--rpc-login").arg(login)
            .env("LD_LIBRARY_PATH", &self.engine_dir)
            .stdin(Stdio::null())
            .stdout(out_io)
            .stderr(err_io)
            .spawn()
            .map_err(|e| format!("Could not start the Nerva wallet engine: {e}. Confirm the ARM64 engine is installed."))?;
        // Give the process a chance to fail immediately (wrong ABI / missing runtime library).
        std::thread::sleep(Duration::from_millis(120));
        match child.try_wait() {
            Ok(Some(status)) => return Err(format!("Nerva wallet engine exited during startup ({status}). The engine bundle may be incompatible with this Android version.")),
            Err(e) => return Err(format!("Could not check Nerva engine startup: {e}")),
            Ok(None) => {}
        }
        let _ = std::fs::write(self.wallet_dir.join("engine.pid"), child.id().to_string());
        *guard = Some(child);
        self.connected.store(false, Ordering::SeqCst);
        if let Ok(mut v) = self.rpc_version.write() { *v = None; }
        Ok(())
    }

    fn clear_pending_transfers(&self) {
        if let Ok(mut pending) = self.pending_transfers.lock() { pending.clear(); }
    }

    async fn restart_engine(&self, new_daemon: String) -> Result<(), String> {
        validate_daemon(&new_daemon)?;
        // A staged transaction is bound to the current wallet and daemon context.
        self.clear_pending_transfers();
        // Flush an open wallet before stopping the native process. A forced process
        // restart without store can lose its latest cached scan/transaction state.
        let _ = timeout(Duration::from_secs(30), rpc_call(self, "store", json!({}))).await;
        {
            let mut child_guard = self.child.lock().map_err(|_| "Engine process lock failed".to_string())?;
            if let Some(mut child) = child_guard.take() {
                let _ = child.kill();
                let _ = child.wait();
            }
        }
        *self.daemon.write().map_err(|_| "Daemon config lock failed".to_string())? = new_daemon.clone();
        self.start_engine()?;
        let path = self.wallet_dir.join("daemon-address.txt");
        let tmp = self.wallet_dir.join("daemon-address.txt.tmp");
        std::fs::write(&tmp, format!("{}\n", new_daemon)).map_err(|e| format!("Could not save daemon settings: {e}"))?;
        std::fs::rename(&tmp, &path).map_err(|e| format!("Could not save daemon settings: {e}"))?;
        Ok(())
    }

    fn stop_engine(&self) {
        self.clear_pending_transfers();
        if let Ok(mut guard) = self.child.lock() {
            if let Some(mut child) = guard.take() {
                let _ = child.kill();
                let _ = child.wait();
            }
        }
        self.connected.store(false, Ordering::SeqCst);
    }
}

fn validate_daemon(address: &str) -> Result<(), String> {
    let s = address.trim();
    if s.is_empty() || s.len() > 260 || s.contains('/') || s.contains('@') || s.contains(' ')
        || s.contains('\\') || s.contains('?') || s.contains('#') || s.contains('\n') || s.contains('\r') {
        return Err("Enter a daemon host and port, for example node.nerva.one:17566".into());
    }
    let (host, port) = s.rsplit_once(':').ok_or("Daemon address must include a port, e.g. node.nerva.one:17566")?;
    if host.is_empty() || host.len() > 253 || host.starts_with('.') || host.ends_with('.') || host.contains("..") {
        return Err("Daemon hostname is invalid.".into());
    }
    if !host.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'.' || b == b'-') {
        return Err("Daemon hostname contains unsupported characters. IPv4/hostname and port are supported.".into());
    }
    let p: u16 = port.parse().map_err(|_| "Daemon port must be between 1 and 65535")?;
    if p == 0 { return Err("Daemon port must be between 1 and 65535".into()); }
    Ok(())
}

fn allowed_method(method: &str) -> bool {
    matches!(method,
        "get_version" | "get_height" | "get_address" | "get_balance" | "get_transfers" |
        "get_transfer_by_txid" | "get_address_book" | "get_accounts" | "get_languages" |
        "create_wallet" | "open_wallet" | "restore_deterministic_wallet" | "close_wallet" |
        "store" | "refresh" | "transfer" | "query_key" | "validate_address" | "make_uri" |
        "get_tx_key" | "check_tx_key" | "relay_tx")
}

fn atomic_safe(v: Value, key: &str) -> Value {
    const ATOMIC_KEYS: &[&str] = &["balance", "unlocked_balance", "amount", "fee", "reward", "amount_in", "amount_out", "locked_amount", "dust", "dust_threshold", "total_amount"];
    match v {
        Value::Object(obj) => Value::Object(obj.into_iter().map(|(k, x)| {
            let value = if let Some(i) = x.as_u64().filter(|_| ATOMIC_KEYS.contains(&k.as_str())) {
                Value::String(i.to_string())
            } else { atomic_safe(x, &k) };
            (k, value)
        }).collect()),
        Value::Array(items) => Value::Array(items.into_iter().map(|x| atomic_safe(x, key)).collect()),
        other => other,
    }
}

fn normalise_transfer_params(params: &mut Value) -> Result<(), String> {
    if let Some(destinations) = params.get_mut("destinations").and_then(Value::as_array_mut) {
        for dest in destinations {
            if let Some(amount) = dest.get("amount").cloned() {
                if let Some(s) = amount.as_str() {
                    if s.is_empty() || !s.bytes().all(|b| b.is_ascii_digit()) { return Err("Transfer amount must be a positive integer number of atomic units.".into()); }
                    let n: u64 = s.parse().map_err(|_| "Transfer amount is outside the supported integer range")?;
                    if n == 0 { return Err("Transfer amount must be positive.".into()); }
                    if let Some(obj) = dest.as_object_mut() { obj.insert("amount".into(), Value::Number(Number::from(n))); }
                }
            }
        }
    }
    Ok(())
}

fn digest_fields(challenge: &str) -> Result<HashMap<String, String>, String> {
    let rest = challenge.trim().strip_prefix("Digest ").ok_or("Wallet RPC did not offer HTTP Digest authentication")?;
    let bytes = rest.as_bytes();
    let mut i = 0;
    let mut out = HashMap::new();
    while i < bytes.len() {
        while i < bytes.len() && (bytes[i] == b',' || bytes[i].is_ascii_whitespace()) { i += 1; }
        let key_start = i;
        while i < bytes.len() && bytes[i] != b'=' && bytes[i] != b',' { i += 1; }
        if i >= bytes.len() || bytes[i] != b'=' { break; }
        let key = rest[key_start..i].trim().to_ascii_lowercase();
        i += 1;
        while i < bytes.len() && bytes[i].is_ascii_whitespace() { i += 1; }
        let value = if i < bytes.len() && bytes[i] == b'"' {
            i += 1; let mut value = String::new();
            while i < bytes.len() {
                if bytes[i] == b'\\' && i + 1 < bytes.len() { value.push(bytes[i + 1] as char); i += 2; }
                else if bytes[i] == b'"' { i += 1; break; }
                else { value.push(bytes[i] as char); i += 1; }
            }
            value
        } else {
            let start = i;
            while i < bytes.len() && bytes[i] != b',' { i += 1; }
            rest[start..i].trim().to_string()
        };
        if !key.is_empty() { out.insert(key, value); }
        while i < bytes.len() && bytes[i] != b',' { i += 1; }
    }
    Ok(out)
}

fn md5_hex(s: &str) -> String { format!("{:x}", md5::compute(s.as_bytes())) }

async fn rpc_call(state: &AppState, method: &str, params: Value) -> Result<Value, String> {
    if !allowed_method(method) { return Err("This wallet operation is not enabled.".into()); }
    let mut params = if params.is_object() { params } else { return Err("RPC parameters must be a JSON object.".into()); };
    if method == "transfer" { normalise_transfer_params(&mut params)?; }
    let cfg = state.rpc.read().map_err(|_| "RPC config unavailable".to_string())?.clone();
    let endpoint = format!("{}/json_rpc", cfg.url.trim_end_matches('/'));
    let body = json!({"jsonrpc":"2.0","id":"nerva-simple-wallet","method":method,"params":params});
    let first = timeout(Duration::from_secs(if matches!(method, "refresh"|"restore_deterministic_wallet"|"create_wallet"|"open_wallet") { 120 } else { 45 }),
        state.client.post(&endpoint).header(header::CONTENT_TYPE, "application/json").json(&body).send())
        .await.map_err(|_| "Wallet RPC timed out. Check the daemon and retry.".to_string())?
        .map_err(|_| "Cannot reach local Nerva wallet RPC. Check whether the wallet engine is running.".to_string())?;
    let response = if first.status() == StatusCode::UNAUTHORIZED {
        let challenge = first.headers().get(header::WWW_AUTHENTICATE).and_then(|x| x.to_str().ok()).ok_or("Wallet RPC authentication challenge missing")?;
        let f = digest_fields(challenge)?;
        let realm = f.get("realm").ok_or("Digest realm missing")?;
        let nonce = f.get("nonce").ok_or("Digest nonce missing")?;
        let qop = f.get("qop").map(|s| s.split(',').map(str::trim).any(|q| q == "auth")).unwrap_or(false);
        let algorithm = f.get("algorithm").map(|x| x.as_str()).unwrap_or("MD5");
        if !qop || !algorithm.eq_ignore_ascii_case("MD5") { return Err("Wallet RPC Digest settings are not supported (expected MD5 with qop=auth).".into()); }
        let uri = "/json_rpc";
        let mut bytes = [0u8; 16]; OsRng.fill_bytes(&mut bytes); let cnonce = hex::encode(bytes);
        // Use a monotonic nonce count rather than replaying nc=00000001 on every
        // request. This remains safe when the RPC server keeps a nonce alive.
        let nc_value = state.digest_nonce_count.fetch_add(1, Ordering::Relaxed).wrapping_add(1);
        let nc = format!("{nc_value:08x}");
        let ha1 = md5_hex(&format!("{}:{}:{}", cfg.username, realm, cfg.password));
        let ha2 = md5_hex(&format!("POST:{}", uri));
        let response_hash = md5_hex(&format!("{}:{}:{}:{}:auth:{}", ha1, nonce, nc, cnonce, ha2));
        let mut auth = format!("Digest username=\"{}\", realm=\"{}\", nonce=\"{}\", uri=\"{}\", algorithm=MD5, response=\"{}\", qop=auth, nc={}, cnonce=\"{}\"",
            quoted(&cfg.username), quoted(realm), quoted(nonce), uri, response_hash, nc, cnonce);
        if let Some(opaque) = f.get("opaque") { auth.push_str(&format!(", opaque=\"{}\"", quoted(opaque))); }
        timeout(Duration::from_secs(125), state.client.post(&endpoint).header(header::AUTHORIZATION, auth).header(header::CONTENT_TYPE, "application/json").json(&body).send())
            .await.map_err(|_| "Wallet RPC timed out.".to_string())?
            .map_err(|_| "Cannot reach local Nerva wallet RPC.".to_string())?
    } else { first };
    if !response.status().is_success() {
        return Err(match response.status() { StatusCode::UNAUTHORIZED => "Wallet RPC authentication failed.".to_string(), StatusCode::NOT_FOUND => "Wallet RPC path was not found.".to_string(), s => format!("Wallet RPC returned HTTP {s}.") });
    }
    let bytes = response.bytes().await.map_err(|_| "Could not read the wallet RPC response.".to_string())?;
    if bytes.len() > MAX_RPC_RESPONSE { return Err("Wallet RPC response exceeded its size limit.".into()); }
    let data: Value = match parse_rpc_body(&bytes) {
        Some(v) => v,
        None => {
            // Never echo replies that may hold secrets (seed words).
            let hint = if matches!(method, "query_key" | "restore_deterministic_wallet") { String::new() } else { format!(" (reply: {})", body_preview(&bytes)) };
            return Err(format!("{BAD_REPLY}{hint}"));
        }
    };
    if let Some(error) = data.get("error").filter(|value| !value.is_null()) {
        let message = error.get("message").and_then(Value::as_str).unwrap_or("Nerva wallet RPC returned an error");
        return Err(message.chars().take(500).collect());
    }
    Ok(atomic_safe(data.get("result").cloned().unwrap_or_else(|| json!({})), ""))
}

fn parse_rpc_body(bytes: &[u8]) -> Option<Value> {
    if let Ok(v) = serde_json::from_slice::<Value>(bytes) { return Some(v); }
    // Tolerate stray bytes around the JSON object (BOM, NULs, log noise).
    let text = String::from_utf8_lossy(bytes);
    let start = text.find('{')?;
    let end = text.rfind('}')?;
    if end <= start { return None; }
    serde_json::from_str::<Value>(&text[start..=end]).ok()
}

fn body_preview(bytes: &[u8]) -> String {
    let cut = &bytes[..bytes.len().min(160)];
    let s: String = String::from_utf8_lossy(cut).chars().map(|c| if c.is_control() { ' ' } else { c }).collect();
    let s = s.trim().to_string();
    if s.is_empty() { "empty".to_string() } else { s }
}

fn quoted(s: &str) -> String { s.replace('\\', "\\\\").replace('"', "\\\"") }

fn json_response(status: StatusCode, body: Value) -> Response {
    let mut response = (status, Json(body)).into_response();
    security_headers(response.headers_mut());
    response
}
fn security_headers(headers: &mut HeaderMap) {
    headers.insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
    headers.insert(axum::http::HeaderName::from_static("x-content-type-options"), HeaderValue::from_static("nosniff"));
    headers.insert(axum::http::HeaderName::from_static("referrer-policy"), HeaderValue::from_static("no-referrer"));
    headers.insert(axum::http::HeaderName::from_static("x-frame-options"), HeaderValue::from_static("DENY"));
    headers.insert(axum::http::HeaderName::from_static("content-security-policy"), HeaderValue::from_static("default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'"));
    // Chromium-based Android WebViews may send a Private Network Access preflight
    // when the appassets origin calls the loopback API; CORS still limits origin.
    headers.insert(axum::http::HeaderName::from_static("access-control-allow-private-network"), HeaderValue::from_static("true"));
}

async fn host_guard(req: Request<Body>, next: Next) -> Response {
    let host = req.headers().get(header::HOST).and_then(|x| x.to_str().ok()).unwrap_or("").to_ascii_lowercase();
    if host != format!("127.0.0.1:{UI_PORT}") && host != format!("localhost:{UI_PORT}") {
        return json_response(StatusCode::FORBIDDEN, json!({"ok":false,"error":"Local host check failed."}));
    }
    next.run(req).await
}

// Apply security headers outside CORS as well, because CORS can short-circuit a
// browser preflight without calling the route middleware. Chromium WebView's
// loopback Private Network Access preflight needs the allow-private-network header.
async fn security_headers_layer(req: Request<Body>, next: Next) -> Response {
    let mut response = next.run(req).await;
    security_headers(response.headers_mut());
    response
}

fn constant_time_equal(a: &[u8], b: &[u8]) -> bool {
    if a.len() != b.len() { return false; }
    a.iter().zip(b.iter()).fold(0u8, |acc, (x, y)| acc | (x ^ y)) == 0
}

fn require_session(state: &AppState, headers: &HeaderMap) -> Result<(), Response> {
    let token = headers.get("x-nerva-session").and_then(|x| x.to_str().ok()).unwrap_or("");
    if !constant_time_equal(token.as_bytes(), state.token.as_bytes()) {
        return Err(json_response(StatusCode::FORBIDDEN, json!({"ok":false,"error":"Session check failed. Reload the wallet."})));
    }
    if let Some(origin) = headers.get(header::ORIGIN).and_then(|x| x.to_str().ok()) {
        if origin != "https://appassets.androidplatform.net" && origin != format!("http://127.0.0.1:{UI_PORT}") && origin != format!("http://localhost:{UI_PORT}") {
            return Err(json_response(StatusCode::FORBIDDEN, json!({"ok":false,"error":"Cross-origin requests are not allowed."})));
        }
    }
    Ok(())
}

async fn status(State(state): State<Arc<AppState>>) -> Json<Value> {
    Json(json!({"ok":true,"connected":state.connected.load(Ordering::SeqCst),"url":format!("http://127.0.0.1:{RPC_PORT}"),"username":"nerva","version":state.rpc_version.read().ok().and_then(|v| v.clone()),"connected_at":null}))
}
async fn ensure_connected(state: &AppState) -> Result<(), String> {
    if state.connected.load(Ordering::SeqCst) { return Ok(()); }
    let _ = state.start_engine(); // no-op while the engine runs; restarts it if it died
    let mut last = "Wallet engine is starting; try again shortly.".to_string();
    for attempt in 0..40 {
        match rpc_call(state, "get_version", json!({})).await {
            Ok(version) => {
                let text = version.get("version").map(|v| v.to_string().trim_matches('"').to_string()).unwrap_or_else(|| "connected".into());
                if let Ok(mut v) = state.rpc_version.write() { *v = Some(text); }
                state.connected.store(true, Ordering::SeqCst);
                return Ok(());
            },
            Err(e) => {
                last = e;
                if attempt == 15 { let _ = state.start_engine(); }
                if attempt < 39 { tokio::time::sleep(Duration::from_millis(350)).await; }
            }
        }
    }
    Err(last)
}
async fn connect(State(state): State<Arc<AppState>>, headers: HeaderMap) -> Response {
    if let Err(r) = require_session(&state, &headers) { return r; }
    state.connected.store(false, Ordering::SeqCst);
    match ensure_connected(&state).await {
        Ok(()) => {
            let version = state.rpc_version.read().ok().and_then(|v| v.clone()).unwrap_or_default();
            json_response(StatusCode::OK, json!({"ok":true,"version":version,"message":"Connected to the local Nerva wallet engine."}))
        },
        Err(e) => json_response(StatusCode::BAD_GATEWAY, json!({"ok":false,"error":e})),
    }
}
async fn disconnect(State(state): State<Arc<AppState>>, headers: HeaderMap) -> Response {
    if let Err(r) = require_session(&state, &headers) { return r; }
    state.connected.store(false, Ordering::SeqCst);
    json_response(StatusCode::OK, json!({"ok":true}))
}
#[derive(serde::Deserialize)]
struct CallRequest { method: String, #[serde(default = "empty_obj")] params: Value }
fn empty_obj() -> Value { json!({}) }

#[derive(serde::Deserialize)]
struct PrepareTransferRequest { address: String, amount_atomic: String }

#[derive(serde::Deserialize)]
struct RelayTransferRequest { id: String }

#[derive(Clone)]
struct PendingTransfer {
    tx_metadata: String,
    address: String,
    amount_atomic: u64,
    fee_atomic: u64,
    expires_at: Instant,
}

fn atomic_u64(value: &Value) -> Option<u64> {
    value.as_u64().or_else(|| value.as_str().and_then(|text| text.parse::<u64>().ok()))
}

fn parse_positive_atomic_amount(text: &str) -> Result<u64, String> {
    if text.is_empty() || !text.bytes().all(|b| b.is_ascii_digit()) {
        return Err("Amount must be a positive integer number of atomic units.".into());
    }
    let amount = text.parse::<u64>().map_err(|_| "Amount exceeds the supported range.")?;
    if amount == 0 { return Err("Amount must be greater than zero.".into()); }
    Ok(amount)
}

fn expire_pending_transfers(pending: &mut HashMap<String, PendingTransfer>) {
    let now = Instant::now();
    pending.retain(|_, transfer| transfer.expires_at > now);
}

async fn prepare_transfer(State(state): State<Arc<AppState>>, headers: HeaderMap, Json(body): Json<Value>) -> Response {
    if let Err(r) = require_session(&state, &headers) { return r; }
    let request: PrepareTransferRequest = match serde_json::from_value(body) {
        Ok(x) => x,
        Err(_) => return json_response(StatusCode::BAD_REQUEST, json!({"ok":false,"error":"A recipient address and exact atomic-unit amount are required."})),
    };
    let address = request.address.trim().to_string();
    if address.is_empty() || address.len() > 256 || address.chars().any(char::is_whitespace) {
        return json_response(StatusCode::BAD_REQUEST, json!({"ok":false,"error":"Recipient address is invalid."}));
    }
    let amount = match parse_positive_atomic_amount(&request.amount_atomic) {
        Ok(value) => value,
        Err(error) => return json_response(StatusCode::BAD_REQUEST, json!({"ok":false,"error":error})),
    };
    // Use the Rust Nerva core for local Base58/checksum/prefix/public-key parsing, then require
    // the active upstream engine to agree before constructing the real transaction.
    if nerva_core::address::Address::decode(&address).is_err() {
        return json_response(StatusCode::BAD_REQUEST, json!({"ok":false,"error":"Recipient is not a valid Nerva mainnet address."}));
    }
    if let Err(e) = ensure_connected(&state).await {
        return json_response(StatusCode::BAD_GATEWAY, json!({"ok":false,"error":e}));
    }

    // Address parsing, spendable-output/decoy selection, fee calculation, RingCT construction,
    // signature generation and transaction encoding are performed by the pinned upstream Nerva
    // wallet engine. Rust validates the request, stages the not-yet-relayed result server-side,
    // and requires a one-time capability to relay it after user confirmation.
    match rpc_call(&state, "validate_address", json!({"address":address})).await {
        Ok(v) if v.get("valid").and_then(Value::as_bool) == Some(true) => {},
        Ok(_) => return json_response(StatusCode::BAD_REQUEST, json!({"ok":false,"error":"This is not a valid Nerva address for the connected network."})),
        Err(e) => return json_response(StatusCode::BAD_GATEWAY, json!({"ok":false,"error":e})),
    }
    let balance = match rpc_call(&state, "get_balance", json!({"account_index":0})).await {
        Ok(v) => v,
        Err(e) => return json_response(StatusCode::BAD_GATEWAY, json!({"ok":false,"error":e})),
    };
    let unlocked = match balance.get("unlocked_balance").and_then(atomic_u64) {
        Some(value) => value,
        None => return json_response(StatusCode::BAD_GATEWAY, json!({"ok":false,"error":"Wallet engine did not return a valid unlocked balance; refusing to prepare a transaction."})),
    };
    if amount > unlocked {
        return json_response(StatusCode::BAD_REQUEST, json!({"ok":false,"error":"Insufficient unlocked balance."}));
    }

    let result = match rpc_call(&state, "transfer", json!({
        "destinations":[{"address":address,"amount":amount}],
        "account_index":0,
        "priority":1,
        "get_tx_key":false,
        "do_not_relay":true,
        "get_tx_metadata":true
    })).await {
        Ok(value) => value,
        Err(error) => return json_response(StatusCode::BAD_GATEWAY, json!({"ok":false,"error":error})),
    };
    let metadata = match result.get("tx_metadata").and_then(Value::as_str) {
        Some(value) if !value.is_empty() && value.len() <= MAX_TX_METADATA_BYTES => value.to_string(),
        _ => return json_response(StatusCode::BAD_GATEWAY, json!({"ok":false,"error":"Wallet engine did not return safe, bounded transaction metadata. Nothing was relayed."})),
    };
    let fee = match result.get("fee").and_then(atomic_u64) {
        Some(value) => value,
        None => return json_response(StatusCode::BAD_GATEWAY, json!({"ok":false,"error":"Wallet engine did not return a valid fee. Nothing was relayed."})),
    };
    let total = match amount.checked_add(fee) {
        Some(value) => value,
        None => return json_response(StatusCode::BAD_GATEWAY, json!({"ok":false,"error":"Amount plus fee overflowed the supported range. Nothing was relayed."})),
    };
    if total > unlocked {
        return json_response(StatusCode::BAD_REQUEST, json!({"ok":false,"error":"Amount plus network fee exceeds the unlocked balance. Nothing was relayed."}));
    }

    let mut nonce = [0u8; 32];
    OsRng.fill_bytes(&mut nonce);
    let id = hex::encode(nonce);
    let mut pending = match state.pending_transfers.lock() {
        Ok(value) => value,
        Err(_) => return json_response(StatusCode::INTERNAL_SERVER_ERROR, json!({"ok":false,"error":"Transaction staging is unavailable. Nothing was relayed."})),
    };
    expire_pending_transfers(&mut pending);
    if pending.len() >= MAX_PENDING_TRANSFERS {
        return json_response(StatusCode::TOO_MANY_REQUESTS, json!({"ok":false,"error":"A transaction is already prepared. Submit or cancel it, or wait for it to expire before preparing another."}));
    }
    pending.insert(id.clone(), PendingTransfer {
        tx_metadata: metadata,
        address: address.clone(),
        amount_atomic: amount,
        fee_atomic: fee,
        expires_at: Instant::now() + PREPARED_TRANSFER_TTL,
    });
    json_response(StatusCode::OK, json!({
        "ok":true,"id":id,"address":address,
        "amount_atomic":amount.to_string(),"fee_atomic":fee.to_string(),
        "expires_in_seconds":PREPARED_TRANSFER_TTL.as_secs()
    }))
}

async fn cancel_transfer(State(state): State<Arc<AppState>>, headers: HeaderMap, Json(body): Json<Value>) -> Response {
    if let Err(r) = require_session(&state, &headers) { return r; }
    let request: RelayTransferRequest = match serde_json::from_value(body) {
        Ok(x) if x.id.len() == 64 && x.id.bytes().all(|b| b.is_ascii_hexdigit()) => x,
        _ => return json_response(StatusCode::BAD_REQUEST, json!({"ok":false,"error":"Invalid prepared-transaction token."})),
    };
    let mut pending = match state.pending_transfers.lock() {
        Ok(value) => value,
        Err(_) => return json_response(StatusCode::INTERNAL_SERVER_ERROR, json!({"ok":false,"error":"Transaction staging is unavailable."})),
    };
    pending.remove(&request.id);
    json_response(StatusCode::OK, json!({"ok":true}))
}

async fn relay_transfer(State(state): State<Arc<AppState>>, headers: HeaderMap, Json(body): Json<Value>) -> Response {
    if let Err(r) = require_session(&state, &headers) { return r; }
    let request: RelayTransferRequest = match serde_json::from_value(body) {
        Ok(x) if x.id.len() == 64 && x.id.bytes().all(|b| b.is_ascii_hexdigit()) => x,
        _ => return json_response(StatusCode::BAD_REQUEST, json!({"ok":false,"error":"Invalid or missing prepared-transaction token."})),
    };
    if let Err(e) = ensure_connected(&state).await {
        return json_response(StatusCode::BAD_GATEWAY, json!({"ok":false,"error":e}));
    }
    // Consume the capability before attempting relay. A request retry cannot broadcast the same
    // staged transaction twice if the network accepted it but the HTTP response was lost.
    let prepared = {
        let mut pending = match state.pending_transfers.lock() {
            Ok(value) => value,
            Err(_) => return json_response(StatusCode::INTERNAL_SERVER_ERROR, json!({"ok":false,"error":"Transaction staging is unavailable."})),
        };
        expire_pending_transfers(&mut pending);
        pending.remove(&request.id)
    };
    let prepared = match prepared {
        Some(value) => value,
        None => return json_response(StatusCode::GONE, json!({"ok":false,"error":"Prepared transaction expired or was already submitted. Review the transaction history before preparing again."})),
    };
    let result = match rpc_call(&state, "relay_tx", json!({"hex":prepared.tx_metadata})).await {
        Ok(value) => value,
        Err(error) => return json_response(StatusCode::BAD_GATEWAY, json!({"ok":false,"error":"The submission result is uncertain. Check transaction history and the network before trying again.","retry_safe":false,"detail":error})),
    };
    let txid = result.get("tx_hash").and_then(Value::as_str).unwrap_or("");
    json_response(StatusCode::OK, json!({
        "ok":true,"txid":txid,"address":prepared.address,
        "amount_atomic":prepared.amount_atomic.to_string(),"fee_atomic":prepared.fee_atomic.to_string()
    }))
}

async fn call(State(state): State<Arc<AppState>>, headers: HeaderMap, Json(body): Json<Value>) -> Response {
    if let Err(r) = require_session(&state, &headers) { return r; }
    let request: CallRequest = match serde_json::from_value(body) { Ok(x) => x, Err(_) => return json_response(StatusCode::BAD_REQUEST, json!({"ok":false,"error":"Invalid RPC method or parameters."})) };
    // Spending must go through the staged prepare/confirm/relay flow. Do not expose raw metadata
    // or let the WebView bypass the one-time relay capability via generic RPC.
    if matches!(request.method.as_str(), "transfer" | "transfer_split" | "relay_tx" | "sweep_all" | "sweep_single") {
        return json_response(StatusCode::FORBIDDEN, json!({"ok":false,"error":"Spending calls must use the staged Rust transaction endpoints."}));
    }
    if let Err(e) = ensure_connected(&state).await { return json_response(StatusCode::BAD_GATEWAY, json!({"ok":false,"error":e})); }
    match rpc_call(&state, &request.method, request.params).await {
        Ok(result) => json_response(StatusCode::OK, json!({"ok":true,"result":result})),
        Err(e) => json_response(StatusCode::BAD_GATEWAY, json!({"ok":false,"error":e})),
    }
}
async fn network(State(state): State<Arc<AppState>>) -> Json<Value> {
    let value = timeout(Duration::from_secs(7), state.client.post("https://api.nerva.one/daemon/get_info/").json(&json!({})).send()).await;
    let result = match value {
        Ok(Ok(resp)) if resp.status().is_success() => {
            match resp.json::<Value>().await {
                Ok(v) => {
                    let source = v.get("result").unwrap_or(&v);
                    let mut out = Map::new();
                    for key in ["height", "target_height", "difficulty", "outgoing_connections_count", "incoming_connections_count", "status", "version"] {
                        if let Some(val) = source.get(key) { out.insert(key.to_string(), val.clone()); }
                    }
                    out.insert("available".into(), Value::Bool(!out.is_empty())); Value::Object(out)
                },
                _ => json!({"available":false,"message":"Network status unavailable."}),
            }
        },
        _ => json!({"available":false,"message":"Network status unavailable. The wallet may still sync through its daemon."}),
    };
    Json(json!({"ok":true,"network":result}))
}
#[derive(serde::Deserialize)]
struct QrQuery { text: String }
async fn qr(Query(q): Query<QrQuery>) -> Response {
    if q.text.is_empty() || q.text.len() > 256 { return json_response(StatusCode::BAD_REQUEST, json!({"ok":false,"error":"Invalid QR content."})); }
    match qrcode::QrCode::new(q.text.as_bytes()) {
        Ok(code) => {
            let svg = code.render::<qrcode::render::svg::Color>().min_dimensions(210, 210).build();
            let mut r = (StatusCode::OK, [(header::CONTENT_TYPE, "image/svg+xml; charset=utf-8")], svg).into_response(); security_headers(r.headers_mut()); r
        },
        Err(_) => json_response(StatusCode::BAD_REQUEST, json!({"ok":false,"error":"Could not encode QR content."})),
    }
}
// ---------------------------------------------------------------------------
// Automatic wallet management. The wallet-file password is a random value held
// by the Android Keystore and passed in by the host; the WebView never sees it.
// ---------------------------------------------------------------------------

fn wallet_exists(state: &AppState) -> bool {
    state.wallet_dir.join(format!("{WALLET_NAME}.keys")).is_file()
}

fn wallet_error(status: StatusCode, message: impl Into<String>) -> Response {
    json_response(status, json!({"ok":false,"error":message.into()}))
}

/// Runs a wallet lifecycle call. Some engine builds answer these with a body that is not
/// strict JSON; that case is returned as Ok(Some(note)) and the caller verifies the real
/// outcome with get_address instead of trusting the reply body.
async fn rpc_lifecycle(state: &AppState, method: &str, params: Value) -> Result<Option<String>, String> {
    match rpc_call(state, method, params).await {
        Ok(_) => Ok(None),
        Err(e) if e.starts_with(BAD_REPLY) => Ok(Some(e)),
        Err(e) => Err(e),
    }
}

async fn wallet_address(state: &AppState) -> Option<String> {
    let v = rpc_call(state, "get_address", json!({"account_index":0})).await.ok()?;
    v.get("address").and_then(Value::as_str).map(str::to_string)
}

async fn fetch_seed(state: &AppState) -> Option<String> {
    let v = rpc_call(state, "query_key", json!({"key_type":"mnemonic"})).await.ok()?;
    v.get("key").and_then(Value::as_str).map(str::to_string).filter(|s| !s.is_empty())
}

async fn close_current_wallet(state: &AppState) {
    state.clear_pending_transfers();
    let _ = timeout(Duration::from_secs(30), rpc_call(state, "store", json!({}))).await;
    let _ = timeout(Duration::from_secs(30), rpc_call(state, "close_wallet", json!({}))).await;
}

fn matches_wallet_file(name: &str, base: &str) -> bool {
    name == base || (name.starts_with(base) && name.as_bytes().get(base.len()) == Some(&b'.'))
}

/// Moves wallet files out of the way (never deletes funds-bearing files).
fn archive_wallet_files(dir: &Path, base: &str) -> Result<(), String> {
    let stamp = SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0);
    let entries = std::fs::read_dir(dir).map_err(|e| format!("Cannot read the wallet directory: {e}"))?;
    for entry in entries.flatten() {
        let name = entry.file_name().to_string_lossy().to_string();
        if matches_wallet_file(&name, base) {
            std::fs::rename(entry.path(), dir.join(format!("old-{stamp}-{name}")))
                .map_err(|e| format!("Cannot move the old wallet file: {e}"))?;
        }
    }
    Ok(())
}

fn rename_wallet_files(dir: &Path, from: &str, to: &str) -> Result<(), String> {
    let entries = std::fs::read_dir(dir).map_err(|e| format!("Cannot read the wallet directory: {e}"))?;
    for entry in entries.flatten() {
        let name = entry.file_name().to_string_lossy().to_string();
        if matches_wallet_file(&name, from) {
            let target = format!("{to}{}", &name[from.len()..]);
            std::fs::rename(entry.path(), dir.join(target)).map_err(|e| format!("Cannot finish wallet setup: {e}"))?;
        }
    }
    Ok(())
}

fn delete_wallet_files(dir: &Path, base: &str) {
    if let Ok(entries) = std::fs::read_dir(dir) {
        for entry in entries.flatten() {
            let name = entry.file_name().to_string_lossy().to_string();
            if matches_wallet_file(&name, base) { let _ = std::fs::remove_file(entry.path()); }
        }
    }
}

/// A previous app process may have been killed while leaving its engine running. Stop it so
/// the new engine can bind the loopback port with this run's credentials.
fn reap_orphan_engine(dir: &Path) {
    let pid_file = dir.join("engine.pid");
    if let Ok(text) = std::fs::read_to_string(&pid_file) {
        if let Ok(pid) = text.trim().parse::<i32>() {
            let cmdline = std::fs::read(format!("/proc/{pid}/cmdline")).unwrap_or_default();
            if pid > 1 && String::from_utf8_lossy(&cmdline).contains("nerva-wallet-rpc") {
                unsafe { libc::kill(pid, libc::SIGKILL); }
                std::thread::sleep(Duration::from_millis(400));
            }
        }
        let _ = std::fs::remove_file(pid_file);
    }
}

async fn wallet_status(State(state): State<Arc<AppState>>, headers: HeaderMap) -> Response {
    if let Err(r) = require_session(&state, &headers) { return r; }
    if let Err(e) = ensure_connected(&state).await { return wallet_error(StatusCode::BAD_GATEWAY, e); }
    if wallet_address(&state).await.is_some() { return json_response(StatusCode::OK, json!({"ok":true,"state":"ready"})); }
    if !wallet_exists(&state) { return json_response(StatusCode::OK, json!({"ok":true,"state":"none"})); }
    let params = json!({"filename":WALLET_NAME,"password":state.wallet_password});
    let note = match rpc_lifecycle(&state, "open_wallet", params).await {
        Ok(n) => n,
        Err(e) => return json_response(StatusCode::OK, json!({"ok":true,"state":"locked","error":e})),
    };
    if wallet_address(&state).await.is_some() {
        json_response(StatusCode::OK, json!({"ok":true,"state":"ready"}))
    } else {
        json_response(StatusCode::OK, json!({"ok":true,"state":"locked","error":note.unwrap_or_else(|| "The wallet could not be opened.".to_string())}))
    }
}

async fn wallet_create(State(state): State<Arc<AppState>>, headers: HeaderMap) -> Response {
    if let Err(r) = require_session(&state, &headers) { return r; }
    if let Err(e) = ensure_connected(&state).await { return wallet_error(StatusCode::BAD_GATEWAY, e); }
    if wallet_exists(&state) { return wallet_error(StatusCode::CONFLICT, "A wallet already exists on this device."); }
    close_current_wallet(&state).await;
    let params = json!({"filename":WALLET_NAME,"password":state.wallet_password,"language":"English"});
    let note = match rpc_lifecycle(&state, "create_wallet", params).await {
        Ok(n) => n,
        Err(e) => return wallet_error(StatusCode::BAD_GATEWAY, e),
    };
    if wallet_address(&state).await.is_none() {
        return wallet_error(StatusCode::BAD_GATEWAY, note.unwrap_or_else(|| "The wallet could not be created.".to_string()));
    }
    let seed = fetch_seed(&state).await;
    json_response(StatusCode::OK, json!({"ok":true,"seed":seed}))
}

#[derive(serde::Deserialize)]
struct ImportRequest { seed: String, #[serde(default)] restore_height: Option<u64> }

async fn wallet_import(State(state): State<Arc<AppState>>, headers: HeaderMap, Json(body): Json<ImportRequest>) -> Response {
    if let Err(r) = require_session(&state, &headers) { return r; }
    let words: Vec<String> = body.seed.split_whitespace().map(|w| w.to_lowercase()).collect();
    if words.len() != 25 {
        return wallet_error(StatusCode::BAD_REQUEST, format!("A Nerva recovery seed has 25 words; you entered {}.", words.len()));
    }
    let seed = words.join(" ");
    if let Err(e) = ensure_connected(&state).await { return wallet_error(StatusCode::BAD_GATEWAY, e); }
    close_current_wallet(&state).await;
    delete_wallet_files(&state.wallet_dir, IMPORT_TMP_NAME);
    // Restore under a temporary name first so a mistyped seed never disturbs an existing wallet.
    let params = json!({"filename":IMPORT_TMP_NAME,"password":state.wallet_password,"seed":seed,
        "restore_height":body.restore_height.unwrap_or(0),"language":"English","seed_offset":""});
    let note = match rpc_lifecycle(&state, "restore_deterministic_wallet", params).await {
        Ok(n) => n,
        Err(e) => return wallet_error(StatusCode::BAD_REQUEST, e),
    };
    if wallet_address(&state).await.is_none() {
        return wallet_error(StatusCode::BAD_GATEWAY, note.unwrap_or_else(|| "The wallet could not be restored. Check the 25 words.".to_string()));
    }
    close_current_wallet(&state).await;
    if let Err(e) = archive_wallet_files(&state.wallet_dir, WALLET_NAME) { return wallet_error(StatusCode::INTERNAL_SERVER_ERROR, e); }
    if let Err(e) = rename_wallet_files(&state.wallet_dir, IMPORT_TMP_NAME, WALLET_NAME) { return wallet_error(StatusCode::INTERNAL_SERVER_ERROR, e); }
    let open = json!({"filename":WALLET_NAME,"password":state.wallet_password});
    let note = match rpc_lifecycle(&state, "open_wallet", open).await {
        Ok(n) => n,
        Err(e) => return wallet_error(StatusCode::BAD_GATEWAY, e),
    };
    if wallet_address(&state).await.is_none() {
        return wallet_error(StatusCode::BAD_GATEWAY, note.unwrap_or_else(|| "The restored wallet could not be opened.".to_string()));
    }
    json_response(StatusCode::OK, json!({"ok":true}))
}

async fn wallet_seed(State(state): State<Arc<AppState>>, headers: HeaderMap) -> Response {
    if let Err(r) = require_session(&state, &headers) { return r; }
    if let Err(e) = ensure_connected(&state).await { return wallet_error(StatusCode::BAD_GATEWAY, e); }
    match fetch_seed(&state).await {
        Some(seed) => json_response(StatusCode::OK, json!({"ok":true,"seed":seed})),
        None => wallet_error(StatusCode::BAD_GATEWAY, "The wallet engine did not return a recovery seed."),
    }
}

async fn wallet_remove(State(state): State<Arc<AppState>>, headers: HeaderMap) -> Response {
    if let Err(r) = require_session(&state, &headers) { return r; }
    if let Err(e) = ensure_connected(&state).await { return wallet_error(StatusCode::BAD_GATEWAY, e); }
    close_current_wallet(&state).await;
    match archive_wallet_files(&state.wallet_dir, WALLET_NAME) {
        Ok(()) => json_response(StatusCode::OK, json!({"ok":true})),
        Err(e) => wallet_error(StatusCode::INTERNAL_SERVER_ERROR, e),
    }
}

async fn diagnostics(State(state): State<Arc<AppState>>, headers: HeaderMap) -> Response {
    if let Err(r) = require_session(&state, &headers) { return r; }
    let running = state.child.lock().ok().map(|mut g| g.as_mut().map(|c| matches!(c.try_wait(), Ok(None))).unwrap_or(false)).unwrap_or(false);
    let log = std::fs::read(state.wallet_dir.join("engine.log")).unwrap_or_default();
    let tail = &log[log.len().saturating_sub(3000)..];
    let daemon = state.daemon.read().map(|d| d.clone()).unwrap_or_default();
    json_response(StatusCode::OK, json!({
        "ok":true,"engine_running":running,"connected":state.connected.load(Ordering::SeqCst),
        "wallet_file":wallet_exists(&state),"daemon":daemon,
        "version":state.rpc_version.read().ok().and_then(|v| v.clone()),
        "log":String::from_utf8_lossy(tail).to_string()
    }))
}

async fn daemon_get(State(state): State<Arc<AppState>>) -> Json<Value> {
    Json(json!({"ok":true,"address":state.daemon.read().map(|d| d.clone()).unwrap_or_else(|_| DEFAULT_DAEMON.to_string())}))
}
async fn daemon_set(State(state): State<Arc<AppState>>, headers: HeaderMap, Json(body): Json<Value>) -> Response {
    if let Err(r) = require_session(&state, &headers) { return r; }
    let address = body.get("address").and_then(Value::as_str).unwrap_or("").trim().to_string();
    if let Err(e) = validate_daemon(&address) { return json_response(StatusCode::BAD_REQUEST, json!({"ok":false,"error":e})); }
    match state.restart_engine(address.clone()).await {
        Ok(()) => json_response(StatusCode::OK, json!({"ok":true,"address":address,"message":"Daemon changed. Reconnect to the wallet engine."})),
        Err(e) => json_response(StatusCode::BAD_GATEWAY, json!({"ok":false,"error":e})),
    }
}
async fn serve(state: Arc<AppState>, listener: StdTcpListener, mut stop_rx: watch::Receiver<bool>) -> Result<(), String> {
    listener.set_nonblocking(true).map_err(|e| e.to_string())?;
    let listener = TcpListener::from_std(listener).map_err(|e| e.to_string())?;
    let app = Router::new()
        .route("/api/status", get(status))
        .route("/api/network", get(network))
        .route("/api/qr", get(qr))
        .route("/api/daemon", get(daemon_get).post(daemon_set))
        .route("/api/connect", post(connect))
        .route("/api/disconnect", post(disconnect))
        .route("/api/call", post(call))
        .route("/api/transaction/prepare", post(prepare_transfer))
        .route("/api/transaction/relay", post(relay_transfer))
        .route("/api/transaction/cancel", post(cancel_transfer))
        .route("/api/wallet/status", post(wallet_status))
        .route("/api/wallet/create", post(wallet_create))
        .route("/api/wallet/import", post(wallet_import))
        .route("/api/wallet/seed", post(wallet_seed))
        .route("/api/wallet/remove", post(wallet_remove))
        .route("/api/diagnostics", post(diagnostics))
        .layer(DefaultBodyLimit::max(MAX_BODY))
        .layer(CorsLayer::new()
            .allow_origin(HeaderValue::from_static("https://appassets.androidplatform.net"))
            .allow_methods([axum::http::Method::GET, axum::http::Method::POST])
            .allow_headers([header::CONTENT_TYPE, axum::http::HeaderName::from_static("x-nerva-session")]))
        .route_layer(middleware::from_fn(host_guard))
        .layer(middleware::from_fn(security_headers_layer))
        .with_state(state);
    axum::serve(listener, app).with_graceful_shutdown(async move { let _ = stop_rx.changed().await; }).await.map_err(|e| e.to_string())
}

fn start_server(binary: PathBuf, wallet_dir: PathBuf, daemon: String, session_token: String, wallet_password: String) -> Result<(), String> {
    validate_daemon(&daemon)?;
    if session_token.len() < 64 || !session_token.bytes().all(|b| b.is_ascii_hexdigit()) {
        return Err("Invalid session token supplied by Android host".into());
    }
    if wallet_password.len() < 32 || !wallet_password.bytes().all(|b| b.is_ascii_hexdigit()) {
        return Err("Invalid wallet password supplied by Android host".into());
    }
    if STARTED.swap(true, Ordering::SeqCst) { return Ok(()); }
    reap_orphan_engine(&wallet_dir);
    let listener = match StdTcpListener::bind(("127.0.0.1", UI_PORT)) {
        Ok(x) => x,
        Err(e) => { STARTED.store(false, Ordering::SeqCst); return Err(format!("Could not bind local wallet service: {e}")); }
    };
    let selected_daemon = std::fs::read_to_string(wallet_dir.join("daemon-address.txt"))
        .ok().map(|v| v.trim().to_string()).filter(|v| validate_daemon(v).is_ok()).unwrap_or(daemon);
    let state = Arc::new(AppState::new(binary, wallet_dir, selected_daemon, session_token, wallet_password));
    if let Err(e) = state.start_engine() { STARTED.store(false, Ordering::SeqCst); return Err(e); }
    let (tx, rx) = watch::channel(false);
    let _ = SHUTDOWN.set(tx);
    if APP.set(state.clone()).is_err() { state.stop_engine(); STARTED.store(false, Ordering::SeqCst); return Err("Wallet service was already initialised in this process.".into()); }
    thread::spawn(move || {
        let result = tokio::runtime::Builder::new_multi_thread().enable_all().build()
            .map_err(|e| e.to_string())
            .and_then(|rt| rt.block_on(serve(state.clone(), listener, rx)));
        if let Err(e) = result { eprintln!("Nerva local service stopped: {e}"); }
        state.stop_engine();
        STARTED.store(false, Ordering::SeqCst);
    });
    Ok(())
}

#[no_mangle]
pub extern "system" fn Java_com_nervasimple_MainActivity_startNativeServer(
    mut env: jni::JNIEnv<'_>,
    _this: jni::objects::JObject<'_>,
    binary_path: jni::objects::JString<'_>,
    wallet_dir: jni::objects::JString<'_>,
    daemon: jni::objects::JString<'_>,
    session_token: jni::objects::JString<'_>,
    wallet_password: jni::objects::JString<'_>,
) -> jni::sys::jint {
    let get = |env: &mut jni::JNIEnv<'_>, s: jni::objects::JString<'_>| -> Result<String, String> {
        env.get_string(&s).map(|x| x.into()).map_err(|e| e.to_string())
    };
    let binary = match get(&mut env, binary_path) { Ok(v) => v, Err(_) => return -1 };
    let wallet = match get(&mut env, wallet_dir) { Ok(v) => v, Err(_) => return -1 };
    let daemon = match get(&mut env, daemon) { Ok(v) => v, Err(_) => return -1 };
    let token = match get(&mut env, session_token) { Ok(v) => v, Err(_) => return -1 };
    let password = match get(&mut env, wallet_password) { Ok(v) => v, Err(_) => return -1 };
    match start_server(PathBuf::from(binary), PathBuf::from(wallet), daemon, token, password) {
        Ok(()) => 0,
        Err(_) => -2,
    }
}

#[no_mangle]
pub extern "system" fn Java_com_nervasimple_MainActivity_stopNativeServer(
    _env: jni::JNIEnv<'_>,
    _this: jni::objects::JObject<'_>,
) {
    if let Some(tx) = SHUTDOWN.get() { let _ = tx.send(true); }
    if let Some(state) = APP.get() { state.stop_engine(); }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn allows_only_safe_wallet_methods() {
        assert!(allowed_method("transfer"));
        assert!(allowed_method("relay_tx"));
        assert!(!allowed_method("start_mining"));
        assert!(!allowed_method("stop_mining"));
        assert!(!allowed_method("save_bc"));
    }
    #[test]
    fn daemon_validation_rejects_injection() {
        assert!(validate_daemon("node.nerva.one:17566").is_ok());
        assert!(validate_daemon("127.0.0.1:17566").is_ok());
        assert!(validate_daemon("https://node.nerva.one:17566").is_err());
        assert!(validate_daemon("node.nerva.one:17566 --rpc-login bad").is_err());
        assert!(validate_daemon("node.nerva.one:0").is_err());
    }
    #[test]
    fn digest_challenge_parses_quoted_qop() {
        let fields = digest_fields("Digest realm=\"nerva\", nonce=\"abc\", qop=\"auth,auth-int\", algorithm=MD5").unwrap();
        assert_eq!(fields.get("realm").unwrap(), "nerva");
        assert_eq!(fields.get("nonce").unwrap(), "abc");
        assert_eq!(fields.get("qop").unwrap(), "auth,auth-int");
    }
    #[test]
    fn digest_response_matches_rfc_2617_example() {
        let ha1 = md5_hex("Mufasa:testrealm@host.com:Circle Of Life");
        let ha2 = md5_hex("GET:/dir/index.html");
        let response = md5_hex(&format!("{}:{}:{}:{}:auth:{}", ha1, "dcd98b7102dd2f0e8b11d0f600bfb0c093", "00000001", "0a4f113b", ha2));
        assert_eq!(response, "6629fae49393a05397450978507c4ef1");
    }
    #[test]
    fn session_comparison_detects_mismatch() {
        assert!(constant_time_equal(b"abcdef", b"abcdef"));
        assert!(!constant_time_equal(b"abcdef", b"abcdeg"));
        assert!(!constant_time_equal(b"abc", b"abcd"));
    }
    #[test]
    fn transfer_amount_parser_accepts_exact_atomic_units_only() {
        assert_eq!(parse_positive_atomic_amount("1").unwrap(), 1);
        assert_eq!(parse_positive_atomic_amount("1000000000000").unwrap(), 1_000_000_000_000);
        assert!(parse_positive_atomic_amount("0").is_err());
        assert!(parse_positive_atomic_amount("-1").is_err());
        assert!(parse_positive_atomic_amount("1.5").is_err());
        assert!(parse_positive_atomic_amount("18446744073709551616").is_err());
    }
    #[test]
    fn atomic_value_parser_accepts_rpc_number_or_string() {
        assert_eq!(atomic_u64(&json!(123)), Some(123));
        assert_eq!(atomic_u64(&json!("123")), Some(123));
        assert_eq!(atomic_u64(&json!("not-an-amount")), None);
        assert_eq!(atomic_u64(&json!(-1)), None);
    }

    #[test]
    fn strings_atomic_amounts_become_rpc_integers() {
        let mut p = json!({"destinations":[{"address":"x","amount":"1230000000000"}]});
        normalise_transfer_params(&mut p).unwrap();
        assert_eq!(p["destinations"][0]["amount"].as_u64().unwrap(), 1230000000000);
    }
    #[test]
    fn lenient_reply_parsing() {
        assert!(parse_rpc_body(br#"{"result":{}}"#).is_some());
        assert!(parse_rpc_body(b"\xEF\xBB\xBF{\"result\":{}}\n\0").is_some());
        assert!(parse_rpc_body(b"").is_none());
        assert!(parse_rpc_body(b"<html>nope</html>").is_none());
        assert_eq!(body_preview(b""), "empty");
    }
    #[test]
    fn wallet_file_matching() {
        assert!(matches_wallet_file("nerva_wallet", "nerva_wallet"));
        assert!(matches_wallet_file("nerva_wallet.keys", "nerva_wallet"));
        assert!(!matches_wallet_file("nerva_wallet2.keys", "nerva_wallet"));
        assert!(!matches_wallet_file("old-1-nerva_wallet.keys", "nerva_wallet"));
    }
}
