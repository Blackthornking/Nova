# Build and engine status — Phase 2

## Android app

- Android UI, Rust JNI/local API, checked Gradle wrapper, build scripts and Android CI are included.
- Real wallet operations still run through the official SHA-256-pinned Nerva `nerva-wallet-rpc` ARM64 engine.
- No APK was built in this environment: Android SDK/NDK, a running Gradle environment and Rust/Cargo were not available here.
- No live wallet creation/restore/send round-trip was run in this environment.

## Rust engine migration

The experimental `rust-engine/` workspace now includes:

- Address, subaddress and account-key derivation helpers; exact atomic amount and varint handling; mnemonic encode/decode.
- Argon2id/ChaCha20-Poly1305 encrypted Rust-format wallet storage and seed-based restore (not legacy `.keys` compatible).
- Transaction-prefix and selected `tx_extra` parsing, including key-image input extraction.
- RingCT base decoding, compact/legacy receiver-side amount recovery and output commitment matching.
- Parallel owned-output matching, persistent scan journal, transaction/owned-output tracking, automatic relevant-transaction history metadata, key-image spend matching when a valid key image is supplied, and reorg rollback.
- Tests authored for primitives, storage, parsing and a synthetic scanner-to-history path; CI workflows present. Static checks pass, but Rust unit tests have not run here.

## Important remaining release blockers

- Rust tests and clippy have not been compiled/executed here because Cargo/rustc are absent. Static checks cannot prove Rust compilation or consensus correctness.
- RingCT proof and signature verification, key-image generation, canonical block/hash validation, lock/maturity rules, full transaction construction/signing/serialization/relay and legacy `.keys` import are not implemented. Current Nerva docs identify mainnet as hard-fork 13; type-6/7 parse support in the C++ source is not evidence that CLSAG/Bulletproof+ is active on mainnet. Verify fork activation before using those formats.
- The Rust scanner is not the Android app's source of truth yet. The official Nerva engine remains responsible for live mainnet balance/history and all real spending operations.
- No performance improvement is claimed. Build CI, C++ differential vectors, a security audit, and Android ARM64 test-wallet end-to-end tests must pass first.

Do not replace the official engine or use this Rust migration alone to store/spend mainnet funds until those release gates pass.
