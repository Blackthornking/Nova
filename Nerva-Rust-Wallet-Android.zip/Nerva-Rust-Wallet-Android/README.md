# Nerva Simple Wallet — Rust + Android source project

A minimal Android wallet project with the Home, Send, Receive, History and Settings screens. The local HTTP/API service is written in Rust and exported to Android through JNI. The web UI is served only on `127.0.0.1:8765`. The wallet engine is the **official Nerva `nerva-wallet-rpc` Android ARM64 release**, not a reimplementation of Nerva cryptography.

> **Build status:** This is a full source/build project, **not a verified working APK yet**. The environment where this archive was assembled has no Rust/Cargo, Gradle, Android SDK/NDK or Android device, so the Rust library was not compiled here and no live transaction round-trip could be performed. Static source and JavaScript checks pass; this is not proof that send/restore work end-to-end. Do not deposit significant funds until an Android ARM64 build has passed the full release checklist.

## Features

- Create a wallet, display its mnemonic for an offline backup, open an existing wallet, or restore from a 25-word seed.
- View wallet balance and unlocked balance, receive address/QR, and transaction history.
- Send XNV through Nerva's official transaction preparation/signing path, review the fee and address, then explicitly confirm broadcast.
- Automatically starts the local wallet-RPC process; RPC is bound only to `127.0.0.1:18082` and protected with a random per-run HTTP Digest username/password generated in memory.
- Starts with the default remote daemon `node.nerva.one:17566`. The Settings screen can change the daemon; the daemon receives blockchain queries, not wallet seeds or private spend keys.
- Uses atomic-unit strings in JavaScript-facing responses to avoid precision loss, an RPC method allowlist, a per-session token, local Host/Origin checks, and bounded request/response sizes.
- No miner controls, no cloud seed backup, and no remote wallet-RPC URL support.

## Build an Android APK

### Requirements

- Android Studio with **Android SDK Platform 35**, Android Build Tools, and Android NDK (Side by side).
- Java 17.
- Rust via rustup/Cargo, plus `cargo-ndk` (the build script installs it if missing).
- Bash, `curl` or `wget`, `unzip`, `tar`, and `sha256sum` (or `shasum`). On Windows, use the included `android/gradlew.bat`; `scripts/build_rust_android.sh` still requires a compatible Bash environment such as WSL2.
- Network access for the checksum-pinned Gradle 8.9 distribution, Gradle dependencies, Rust crates and the official Nerva release asset.

### 1. Open the project

Open the `android/` directory in Android Studio. If Android Studio offers to install required SDK components, install them.

### 2. Build

From the project root, run the included wrapper:

```bash
./android/gradlew :app:assembleDebug
```

On Windows, use `android\gradlew.bat :app:assembleDebug`. The wrapper downloads Gradle 8.9 and verifies its official SHA-256 before use. The Gradle `preBuild` task then downloads and verifies the pinned Nerva engine, cross-compiles the Rust JNI library, and packages the APK.

Alternatively, use the included GitHub Actions workflow (`.github/workflows/android-apk.yml`) to build on an Android-enabled runner. It publishes the debug APK as a workflow artifact. A generated debug APK is for testing, not production distribution.

The resulting APK should be at:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

For a one-command Android Studio build, the Gradle `preBuild` task calls the two preparation scripts automatically. The scripts are idempotent once the verified engine and Rust library exist.

### 3. Install on an ARM64 Android device

Enable Android Developer options and USB debugging, connect the device, then run:

```bash
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

The app copies the engine and its shared libraries to app-private storage, sets the wallet RPC executable permission, launches it through Android's `/system/bin/linker64`, and serves the local UI. No storage permission is requested; wallet files stay in the app's private directory. Keep your recovery seed offline. Uninstalling an app can remove its private wallet files—back up the recovery seed before reinstalling or changing devices.

## Official engine provenance

`scripts/prepare_android_engine.sh` downloads the Nerva project's `v0.3.0.0` Android ARM v8 release archive and checks its pinned SHA-256 before extraction:

- Release: <https://github.com/nerva-project/nerva/releases/tag/v0.3.0.0>
- Asset: `nerva-android-armv8-v0.3.0.0.tar.bz2`
- SHA-256: `905716a117a1575c67925b929b2f2c15cafac0ff94394b4c00610448e522e401`

The `v0.3.0.0` release is the Nerva hard-fork-13 release. If a new mandatory Nerva release supersedes it, update the version, download URL and hash only after checking the signed upstream release hashes and confirming that the replacement Android archive contains `nerva-wallet-rpc`.

## Architecture

```text
Android WebView (HTML/JS/CSS bundled in APK, loaded via WebViewAssetLoader)
  └── fetch http://127.0.0.1:8765 (Rust/Axum JNI service; API only)
        ├── Session-checked, allowlisted local API
        └── HTTP Digest-authenticated JSON-RPC proxy
              └── nerva-wallet-rpc (official Nerva engine)
                    └── node.nerva.one:17566 (default blockchain daemon)
```

The local API intentionally does **not** serve the HTML/JavaScript containing the per-run session token. The token-bearing UI is loaded from APK assets through Android's asset loader, and the API is protected by a random session token, restrictive CORS/Origin checks, Host checks, and loopback binding.

The local API listens on loopback only. The wallet RPC server also listens on loopback only, with a generated password held in process memory. The seed, wallet file and signing operations remain inside the official wallet engine and app-private storage. A remote daemon can observe the device IP and timing of blockchain requests; using your own trusted daemon reduces that dependency.

## Checks and limitations

Run the source-level checks:

```bash
python3 scripts/static_verify.py
```

Run Rust unit tests after Rust/Cargo is installed:

```bash
cargo test
```

The Rust unit tests cover the RPC method allowlist, daemon-address validation, Digest challenge parsing, and exact integer transfer-amount normalization. The UI's send flow uses Nerva `transfer` with `do_not_relay` and requests pending transaction metadata, shows amount/destination/fee, and calls `relay_tx` only after explicit confirmation. A true end-to-end verification still requires a native build, app launch on Android ARM64, and a dedicated test wallet / test transaction.

No fast-scan speedup is claimed in this project. `experimental/Nerva-FastScan-Engine.patch` is research-only; it is deliberately **not** applied to the signed upstream engine because the patch was not compiled and independently validated against the current release.

## Directory map

- `android/` — Android application and Gradle config
- `rust/src/lib.rs` — Rust API server, RPC Digest client, local engine process host, and JNI entry points
- `web/` — Simple wallet screens and JavaScript frontend
- `scripts/prepare_android_engine.sh` — pinned release download + SHA-256 verification
- `scripts/build_rust_android.sh` — ARM64 Rust JNI build
- `experimental/` — unverified scan-engine research patch

## Security release checklist

Before distributing this wallet or using it for significant funds, test all of the following on a physical ARM64 Android device: fresh wallet creation, seed displayed and backed up, full close/reopen, restore from seed with correct restore height, balance and incoming transfer detection, send a small test payment, verify fee/txid, verify confirmed transfer history, change daemon, interrupt/restart scan, and confirm no seed/password appears in logs. Perform a security review and build a signed release APK with a protected signing key. Do not use demo data as proof that a real transaction works.

## Experimental Rust engine migration (Phase 2)

The `rust-engine/` workspace now includes address/subaddress and account primitives, English mnemonic handling, a new encrypted Rust wallet format, bounded transaction-prefix/extra parsing, RingCT base decoding and receiver-side amount recovery with commitment checks, parallel owned-output matching, key-image input extraction, and persistent reorg-aware wallet scan records. Unit tests are authored and CI is configured, but Cargo is not installed in the assembly environment, so those tests have not been executed here.

**This remains an incomplete migration, not a standalone fund-safe wallet.** The Rust code still lacks key-image generation, complete consensus/proof/signature validation, active-fork-compatible transaction signing, decoy/fee selection, transaction construction/serialization/relay, and legacy C++ wallet-file import. Current Nerva documentation says mainnet remains at hard-fork 13; recognizing future RingCT type IDs in a parser does not mean CLSAG/Bulletproof+ is active. The Android app deliberately continues to use the official `nerva-wallet-rpc` binary for all real wallet operations until C++ differential tests and Android end-to-end tests pass. See `rust-engine/README.md`, `rust-engine/MIGRATION-MAP.md`, and `rust-engine/PORT-STATUS.md`.
