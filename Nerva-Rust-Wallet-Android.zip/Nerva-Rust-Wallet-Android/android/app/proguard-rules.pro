# Rust JNI entry points use stable exported symbols. Keep app code simple and debuggable.
