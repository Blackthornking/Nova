(() => {
  'use strict';
  const TOKEN = window.NERVA_SESSION || '';
  const API_BASE = window.NERVA_API_BASE || '';
  const $ = (id) => document.getElementById(id);
  const state = { demo:false, connected:false, walletOpen:false, address:'', balance:'0', unlocked:'0', transfers:[], network:null, rpcUrl:'', rpcUsername:'nerva', modalAction:null, lastRefresh:0, liveError:'', refreshSeconds:12, refreshTimer:null };
  const views = ['wallet','send','activity','receive','settings','setup'];
  const textSafe = (v) => String(v == null ? '' : v);
  const html = (value) => textSafe(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));

  async function api(path, body) {
    const options = { method: body === undefined ? 'GET' : 'POST', headers: { 'Accept':'application/json' } };
    if (body !== undefined) {
      options.headers['Content-Type'] = 'application/json';
      options.headers['X-Nerva-Session'] = TOKEN;
      options.body = JSON.stringify(body);
    }
    let response;
    try { response = await fetch(API_BASE + path, options); }
    catch (_) { throw new Error('Could not reach the local Nerva wallet service. Reopen the wallet app and try again.'); }
    let payload;
    try { payload = await response.json(); } catch (_) { throw new Error('The local service returned an invalid response.'); }
    if (!response.ok || payload.ok === false) throw new Error(payload.error || `Request failed (${response.status}).`);
    return payload;
  }
  async function rpc(method, params = {}) {
    if (!state.connected) throw new Error('Connect to wallet RPC first.');
    const out = await api('/api/call', {method, params});
    return out.result || {};
  }
  function toast(message, kind='') {
    const el = document.createElement('div'); el.className = `toast ${kind}`; el.textContent = message; $('toastRegion').appendChild(el);
    setTimeout(() => el.remove(), 4200);
  }
  function setView(name) {
    views.forEach(v => { $(v+'View').classList.toggle('active', v===name); });
    document.querySelectorAll('[data-view]').forEach(b => b.classList.toggle('active', b.dataset.view===name));
    if (name==='receive') renderReceive();
    if (name==='activity') renderActivity();
    if (name==='settings') renderSettings();
    if (name==='send') { $('sendAvailable').textContent = state.connected && state.walletOpen ? `${xnv(state.unlocked)} XNV` : 'Connect wallet first'; if (!state.connected) toast('Connect wallet RPC in Settings before sending.','error'); else if (!state.walletOpen) showNoWallet(); }
    if (name==='setup' && state.connected) openWalletChooser();
    window.scrollTo({top:0,behavior:'smooth'});
  }
  function xnv(raw, maxDp=6) {
    try {
      let s = BigInt(textSafe(raw || '0'));
      let negative = s < 0n; if (negative) s = -s;
      const whole = s / 1000000000000n; let fraction = (s % 1000000000000n).toString().padStart(12,'0').slice(0,maxDp);
      fraction = fraction.replace(/0+$/,'');
      let result = whole.toLocaleString('en-GB');
      if (fraction) result += '.' + fraction;
      return (negative ? '−' : '') + result;
    } catch (_) { return '0'; }
  }
  function parseXnvToAtomic(value) {
    const s = String(value).trim();
    if (!/^\d+(\.\d{1,12})?$/.test(s)) throw new Error('Enter a valid amount with up to 12 decimal places.');
    const parts = s.split('.');
    const whole = BigInt(parts[0]); const frac = BigInt(((parts[1] || '') + '000000000000').slice(0,12));
    const total = whole * 1000000000000n + frac;
    if (total <= 0n) throw new Error('Amount must be greater than zero.');
    return total.toString();
  }
  function dateString(timestamp) {
    if (!timestamp) return 'Date unavailable';
    let n = Number(timestamp); if (!Number.isFinite(n)) return 'Date unavailable';
    if (n < 100000000000) n *= 1000;
    try { return new Intl.DateTimeFormat('en-GB',{day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}).format(new Date(n)); } catch (_) { return 'Date unavailable'; }
  }
  function setConnection(connected, detail='') {
    state.connected = connected;
    $('connectionDot').classList.toggle('connected', connected);
    $('connectionLabel').textContent = connected ? 'Wallet RPC connected' : 'Not connected';
    $('connectionDetail').textContent = connected ? (detail || 'Local wallet engine ready') : 'Wallet engine offline';
    $('networkLabel').textContent = connected ? 'Wallet engine connected' : 'Public network status';
    if (connected) $('balanceMode').textContent = 'Live wallet balance';
    if ($('settingsConnectionSummary')) renderSettings();
  }
  function renderSettings() {
    const connected = state.connected && !state.demo;
    $('settingsConnectionSummary').textContent = state.demo ? 'Demo mode — no real wallet connected.' : connected ? 'Connected to the local wallet RPC.' : 'Not connected to wallet RPC.';
    $('settingsStatusDot').classList.toggle('connected', connected);
    $('settingsRpcUrl').textContent = connected ? (state.rpcUrl || 'http://127.0.0.1:18082 (private)') : 'Not connected';
    $('settingsRpcVersion').textContent = connected ? ($('connectionDetail').textContent || 'Connected') : 'Not detected';
    $('settingsDisconnectBtn').disabled = !state.connected || state.demo;
    $('refreshInterval').value = String(state.refreshSeconds);
    $('refreshSettingStatus').textContent = `Current interval: ${state.refreshSeconds} seconds`;
    api('/api/daemon').then(x => { const el=$('settingsDaemonAddress'); if(el) el.textContent=x.address || 'Unknown'; }).catch(()=>{});
  }

  function updateBalance() {
    $('balanceValue').textContent = state.connected && state.walletOpen ? xnv(state.balance) : '—';
    $('unlockedValue').innerHTML = state.connected && state.walletOpen ? `${html(xnv(state.unlocked))} <small>XNV</small>` : '— <small>XNV</small>';
    $('balanceMode').textContent = state.demo ? 'Demo data · not real funds' : state.walletOpen ? 'Live wallet balance' : state.connected ? 'Wallet not opened yet' : 'Connect to see live funds';
    $('addressPreview').textContent = state.address || 'Connect or open a wallet to see your address.';
    const available = $('sendAvailable'); if (available) available.textContent = state.connected && state.walletOpen ? `${xnv(state.unlocked)} XNV` : 'Connect wallet first';
    $('copyAddressBtn').disabled = !state.address;
    $('receiveCopyBtn').disabled = !state.address;
    $('addressQr').hidden = !state.address;
    $('qrPlaceholder').hidden = Boolean(state.address);
    if (!state.connected && !state.demo) {
      $('syncLabel').textContent = 'Not syncing'; $('syncFill').style.width='0%';
    }
  }
  function flattenTransfers(t) {
    const out=[]; const seen=new Set();
    if (!t || typeof t!=='object') return out;
    for (const bucket of ['in','out','pending','failed','pool']) {
      for (const x of (Array.isArray(t[bucket]) ? t[bucket] : [])) {
        const id = textSafe(x.txid || x.tx_hash || `${bucket}-${x.timestamp}-${x.amount}-${out.length}`);
        if (seen.has(id)) continue; seen.add(id);
        out.push({...x, _bucket:bucket, _id:id, _direction:bucket==='in' ? 'in' : (bucket==='out' || bucket==='pending' || bucket==='failed' ? 'out' : (x.type==='in'?'in':'out'))});
      }
    }
    out.sort((a,b) => Number(b.timestamp||0)-Number(a.timestamp||0));
    return out;
  }
  function txRow(tx) {
    const incoming = tx._direction === 'in';
    const status = tx._bucket==='pending' ? 'Pending' : tx._bucket==='failed' ? 'Failed' : tx._bucket==='pool' ? 'In pool' : incoming ? 'Received' : 'Sent';
    const amount = xnv(tx.amount || '0');
    const symbol = incoming ? '↓' : '↑';
    const amountString = `${incoming ? '+' : '−'}${amount} XNV`;
    const sub = `${dateString(tx.timestamp)} · ${status}`;
    return `<div class="tx-row"><div class="tx-icon ${incoming?'':'out'}">${symbol}</div><div class="tx-main"><strong>${incoming?'Received XNV':'Sent XNV'}</strong><small>${html(sub)}</small></div><div class="tx-amount ${incoming?'in':'out'}">${html(amountString)}<small>${html(status)}</small></div></div>`;
  }
  function renderActivity() {
    const list = flattenTransfers(state.transfers);
    const empty = '<div class="empty-state"><div class="empty-symbol">↕</div><strong>No transactions to show</strong><p>Once this wallet receives or sends XNV, transfers will appear here.</p></div>';
    $('allList').innerHTML = list.length ? list.map(txRow).join('') : empty;
    $('recentList').innerHTML = list.length ? list.slice(0,5).map(txRow).join('') : '<div class="empty-state"><div class="empty-symbol">↕</div><strong>Your activity will appear here</strong><p>Connect a wallet to see transfers.</p></div>';
    $('activitySub').textContent = list.length ? `${list.length} transfer record${list.length===1?'':'s'} returned by your wallet` : state.walletOpen ? 'No transfers returned by the wallet yet.' : 'Connect a wallet to load history.';
  }
  function renderReceive() {
    $('receiveAddress').textContent = state.address || 'Connect or open a wallet to show your address.';
    $('addressQr').hidden = !state.address;
    $('qrPlaceholder').hidden = Boolean(state.address);
    if (state.address && !state.demo) {
      $('addressQr').src = `${API_BASE}/api/qr?text=${encodeURIComponent(state.address)}&v=${encodeURIComponent(state.address.slice(-8))}`;
    } else if (state.address && state.demo) {
      $('addressQr').hidden = true; $('qrPlaceholder').hidden = false; $('qrPlaceholder').innerHTML = '<span>◈</span><small>Demo address — no payment</small>';
    }
  }
  async function loadWallet() {
    if (!state.connected) return;
    try {
      const [address, balance, transfers, height] = await Promise.all([
        rpc('get_address',{account_index:0}),
        rpc('get_balance',{account_index:0}),
        rpc('get_transfers',{in:true,out:true,pending:true,failed:true,pool:true,account_index:0}),
        rpc('get_height',{})
      ]);
      state.address = address.address || (Array.isArray(address.addresses) && address.addresses[0] ? address.addresses[0].address : '');
      state.balance = balance.balance || '0'; state.unlocked = balance.unlocked_balance || '0'; state.transfers = transfers || {}; state.walletOpen = Boolean(state.address);
      const walletHeight = Number(height.height || height || 0);
      if (walletHeight) { $('syncLabel').textContent = `Wallet scan: ${walletHeight.toLocaleString('en-GB')}`; $('syncFill').style.width='100%'; }
      updateBalance(); renderActivity(); renderReceive();
      state.lastRefresh=Date.now(); state.liveError='';
      return true;
    } catch (e) {
      const msg = e.message || '';
      if (/no wallet|wallet.*open|open wallet/i.test(msg)) { state.walletOpen=false; state.address=''; updateBalance(); showNoWallet(); }
      else { state.liveError=msg; $('syncLabel').textContent='Scan status unavailable'; toast(msg,'error'); }
      return false;
    }
  }
  async function loadNetwork() {
    try {
      const out = await api('/api/network'); state.network = out.network;
      const n = out.network || {};
      if (n.available && (n.height || n.target_height)) {
        const current = Number(n.height || 0); const target = Number(n.target_height || current);
        $('networkHeight').textContent = `Height ${(current).toLocaleString('en-GB')}`;
        if (!state.connected) $('networkLabel').textContent='Nerva network online';
        if (state.connected && state.walletOpen && current>0) {
          // Wallet height indicates scan position but may differ from daemon's target while sync is underway.
          const walletTxt = $('syncLabel').textContent;
          const match = walletTxt.match(/(\d[\d,]*)/);
          if (match) {
            const wh = Number(match[1].replace(/,/g,'')); const pct = Math.max(0,Math.min(100,Math.floor((wh/target)*100)));
            $('syncFill').style.width = pct+'%'; $('syncLabel').textContent = pct>=99 ? 'Wallet scan near network tip' : `Wallet scan · ${pct}% of height`;
          }
        }
      } else { $('networkLabel').textContent = 'Network status unavailable'; $('networkHeight').textContent=''; }
    } catch (_) { $('networkLabel').textContent='Network status unavailable'; }
  }
  async function refreshAll(showNotice=false) {
    if (!state.connected || !state.walletOpen) { await loadNetwork(); return; }
    const old = $('refreshBtn').textContent; $('refreshBtn').textContent='…';
    try {
      // The wallet engine auto-refreshes. refresh requests an immediate scan, then re-read balance/history.
      if (showNotice) await rpc('refresh',{});
      await loadWallet(); await loadNetwork();
      if (showNotice) toast('Wallet refreshed.','success');
    } catch(e) { toast(e.message,'error'); }
    finally { $('refreshBtn').textContent=old; }
  }
  function modal(title, eyebrow, body, footer) {
    $('modalTitle').textContent=title; $('modalEyebrow').textContent=eyebrow || 'NERVA SIMPLE';
    $('modalBody').innerHTML=body; $('modalFooter').innerHTML=footer || '';
    $('modalBackdrop').hidden=false; document.body.style.overflow='hidden';
    $('closeModal').focus();
  }
  function closeModal() { $('modalBackdrop').hidden=true; document.body.style.overflow=''; state.modalAction=null; }
  function field(id,label,placeholder='',type='text',hint='') {
    return `<div class="field"><label for="${id}">${html(label)}</label><input id="${id}" type="${type}" placeholder="${html(placeholder)}" autocomplete="${type==='password'?'new-password':'off'}">${hint?`<small>${html(hint)}</small>`:''}</div>`;
  }
  function settingsModal() {
    modal('Connect wallet engine','LOCAL CONNECTION',
      `<p class="muted" style="margin:0 0 18px;font-size:12px">The app starts the official Nerva wallet engine on this device. This connection stays on loopback; the wallet engine connects to the selected Nerva daemon.</p>
       <div class="inline-notice">No remote wallet-RPC server is accepted. Your wallet file, seed, and signing keys remain in the app-private directory.</div>
       <div id="connectError" class="inline-notice warning" hidden></div>`,
      `<button class="btn btn-secondary" id="cancelModal">Cancel</button><button class="btn btn-primary" id="connectSubmit">Connect securely →</button>`);
    $('cancelModal').onclick=closeModal; $('connectSubmit').onclick=connectSubmit;
  }
  async function connectSubmit() {
    const btn=$('connectSubmit'); btn.disabled=true; btn.textContent='Connecting…';
    try {
      const result=await api('/api/connect',{});
      state.rpcUrl='http://127.0.0.1:18082'; state.rpcUsername='nerva';
      setConnection(true, result.version ? `Nerva RPC ${result.version}` : 'Local wallet engine ready'); closeModal(); toast('Connected to the local Nerva wallet engine.','success');
      await loadWallet(); await loadNetwork(); renderSettings(); setView('wallet');
    } catch(e) {
      $('connectError').hidden=false; $('connectError').textContent=e.message; toast(e.message,'error');
    } finally { btn.disabled=false; btn.textContent='Connect securely →'; }
  }
  async function daemonSettingsModal() {
    let current='node.nerva.one:17566';
    try { current=(await api('/api/daemon')).address || current; } catch (_) {}
    modal('Change Nerva daemon','NETWORK SETTINGS',
      `<p class="muted" style="margin:0 0 14px;font-size:12px">The daemon provides blockchain data; it never receives your wallet seed or private spend key. A remote daemon can observe your network address and query timing.</p>
       ${field('daemonAddress','Daemon host:port','node.nerva.one:17566')}
       <div class="inline-notice">Enter a hostname or IPv4 address and port only. The wallet engine will restart using this daemon; reconnect afterwards.</div>
       <div id="daemonError" class="inline-notice warning" hidden></div>`,
      `<button class="btn btn-secondary" id="cancelDaemon">Cancel</button><button class="btn btn-primary" id="saveDaemon">Save & restart</button>`);
    $('daemonAddress').value=current;
    $('cancelDaemon').onclick=closeModal;
    $('saveDaemon').onclick=async()=>{
      const btn=$('saveDaemon'); btn.disabled=true; btn.textContent='Restarting…';
      try {
        const result=await api('/api/daemon',{address:$('daemonAddress').value.trim()});
        state.connected=false;state.walletOpen=false;state.address='';state.balance='0';state.unlocked='0';state.transfers=[];
        setConnection(false);updateBalance();renderActivity();renderSettings();closeModal();toast(result.message || 'Daemon changed. Reconnect the wallet engine.','success');
      } catch(e) { $('daemonError').hidden=false;$('daemonError').textContent=e.message; }
      finally { btn.disabled=false;btn.textContent='Save & restart'; }
    };
  }
  function showNoWallet() {
    modal('Choose a wallet','WALLET SETUP',
      `<p class="muted" style="margin:0 0 18px;font-size:12px">The wallet RPC is connected, but no open wallet was found. Create a new wallet, open an existing file, or restore your 25-word seed.</p>
       <div class="option-card" style="margin-bottom:10px"><span class="option-no">01</span><div><strong>Create wallet</strong><p>Make a fresh wallet and recovery seed.</p></div><button class="option-action" id="modalCreate">＋</button></div>
       <div class="option-card" style="margin-bottom:10px"><span class="option-no">02</span><div><strong>Open wallet</strong><p>Open an existing wallet file.</p></div><button class="option-action" id="modalOpen">→</button></div>
       <div class="option-card"><span class="option-no">03</span><div><strong>Restore from seed</strong><p>Recover a wallet from its mnemonic.</p></div><button class="option-action" id="modalRestore">↺</button></div>`,
       `<button class="btn btn-secondary" id="disconnectNow">Disconnect</button>`);
    $('modalCreate').onclick=()=>createWalletModal(); $('modalOpen').onclick=()=>openWalletModal(); $('modalRestore').onclick=()=>restoreWalletModal();
    $('disconnectNow').onclick=disconnect;
  }
  function createWalletModal() {
    modal('Create wallet','NEW NERVA WALLET',
      `<p class="muted" style="font-size:11px;margin:0 0 17px">A wallet file will be created by Nerva's wallet engine. Use a unique filename and a strong password.</p>
       ${field('newWalletName','Wallet name','MyNervaWallet')}${field('newWalletPassword','Wallet password','At least 12 characters','password')}${field('newWalletPassword2','Confirm password','Repeat password','password')}
       <label class="check-row"><input id="ackSeed" type="checkbox"><span>I understand that I must back up the 25-word recovery seed and never share it.</span></label>
       <div id="createError" class="inline-notice warning" hidden></div>`,
      `<button class="btn btn-secondary" id="cancelCreate">Cancel</button><button class="btn btn-primary" id="createSubmit">Create wallet</button>`);
    $('cancelCreate').onclick=showNoWallet; $('createSubmit').onclick=createSubmit;
  }
  async function createSubmit() {
    const name=$('newWalletName').value.trim(); const pass=$('newWalletPassword').value; const pass2=$('newWalletPassword2').value;
    if (!/^[a-zA-Z0-9_-]{1,64}$/.test(name)) return showFormError('createError','Use 1–64 letters, numbers, underscores or hyphens for the wallet name.');
    if (pass.length<10) return showFormError('createError','Use a wallet password of at least 10 characters.');
    if (pass!==pass2) return showFormError('createError','The passwords do not match.');
    if (!$('ackSeed').checked) return showFormError('createError','Confirm the recovery-seed backup warning before creating.');
    const btn=$('createSubmit');btn.disabled=true;btn.textContent='Creating…';
    try {
      await rpc('create_wallet',{filename:name,password:pass,language:'English'});
      closeModal(); toast('Wallet created. Retrieve and back up your recovery seed now.','success');
      await loadWallet(); await showSeedModal(pass);
    } catch(e) { showFormError('createError',e.message); }
    finally { if ($('createSubmit')) {btn.disabled=false;btn.textContent='Create wallet';} }
  }
  async function showSeedModal(password) {
    let seed=''; let fail='';
    try { const result=await rpc('query_key',{key_type:'mnemonic'}); seed=result.key || result.mnemonic || ''; }
    catch(e) { fail=e.message; }
    if (seed) {
      modal('Back up your recovery seed','CRITICAL WALLET BACKUP',
        `<p class="seed-warning">Anyone with these words can spend all funds in this wallet. Do not screenshot, email, or paste them into a website. Write them down offline.</p><div class="seed-box" id="seedWords">${html(seed)}</div><label class="check-row" style="margin-top:15px"><input type="checkbox" id="seedCopied"><span>I have written the words down and stored them in a secure offline location.</span></label><div id="seedWarn" class="inline-notice warning" hidden>Confirm your backup before continuing.</div>`,
        `<button class="btn btn-secondary" id="copySeedBtn">Copy seed</button><button class="btn btn-primary" id="seedDoneBtn">I backed it up</button>`);
      $('copySeedBtn').onclick=async()=>{try{await navigator.clipboard.writeText(seed);toast('Seed copied. Clear the clipboard after writing it down.','success');}catch(_){toast('Clipboard access failed. Select the words and copy manually.','error');}};
      $('seedDoneBtn').onclick=()=>{if(!$('seedCopied').checked){$('seedWarn').hidden=false;return;}closeModal();loadWallet();};
    } else {
      modal('Wallet created','RECOVERY SEED REQUIRED',
        `<div class="inline-notice warning">The wallet was created, but Nerva Simple Wallet could not retrieve the mnemonic through this wallet RPC version. Your wallet is not safe to use until you have independently backed up its 25-word seed.</div><p style="font-size:11px;line-height:1.7;color:var(--muted)">Use the Nerva CLI wallet or NervaOne wallet's key/seed view to reveal and securely record the mnemonic. Do not deposit funds until this is done.${fail?`<br><br>RPC response: ${html(fail)}`:''}</p>`,
        `<button class="btn btn-primary" id="seedManualDone">I understand</button>`);
      $('seedManualDone').onclick=()=>{closeModal();loadWallet();};
    }
  }
  function openWalletModal() {
    modal('Open existing wallet','OPEN WALLET FILE',
      `<p class="muted" style="font-size:11px;margin:0 0 17px">Enter the exact wallet filename as managed by the wallet RPC's wallet directory. Do not include the file extension.</p>${field('openWalletName','Wallet name','MyNervaWallet')}${field('openWalletPassword','Wallet password','Wallet file password','password')}<div id="openError" class="inline-notice warning" hidden></div>`,
      `<button class="btn btn-secondary" id="cancelOpen">Cancel</button><button class="btn btn-primary" id="openSubmit">Open wallet</button>`);
    $('cancelOpen').onclick=showNoWallet; $('openSubmit').onclick=openSubmit;
  }
  async function openSubmit() {
    const filename=$('openWalletName').value.trim(), password=$('openWalletPassword').value;
    if(!filename || !password) return showFormError('openError','Enter the wallet filename and wallet password.');
    const btn=$('openSubmit');btn.disabled=true;btn.textContent='Opening…';
    try { await rpc('open_wallet',{filename,password});closeModal();setConnection(true);toast('Wallet opened.','success');await loadWallet();await loadNetwork(); }
    catch(e){showFormError('openError',e.message);}
    finally{if($('openSubmit')){btn.disabled=false;btn.textContent='Open wallet';}}
  }
  function restoreWalletModal() {
    modal('Restore from recovery seed','RECOVER WALLET',
      `<p class="muted" style="font-size:11px;margin:0 0 17px">Your 25-word seed stays in this local app's memory only while the restore request runs. Use a height no later than your first incoming payment.</p>${field('restoreName','Wallet name','RestoredNervaWallet')}
       <div class="field"><label for="restoreSeed">25-word recovery seed</label><textarea id="restoreSeed" placeholder="Enter your 25 recovery words"></textarea><small>Do not paste your seed into chat, notes apps, or websites.</small></div>
       ${field('restorePassword','New wallet password','At least 10 characters','password')}
       ${field('restoreHeight','Restore height (optional)','0','number','Use 0 if you are not sure. A later height can make earlier transactions disappear from your balance/history.')}
       <label class="check-row"><input id="restoreSeedAck" type="checkbox"><span>I entered my seed into this local wallet app and understand anyone with the seed can spend the funds.</span></label><div id="restoreError" class="inline-notice warning" hidden></div>`,
      `<button class="btn btn-secondary" id="cancelRestore">Cancel</button><button class="btn btn-primary" id="restoreSubmit">Restore wallet</button>`);
    $('restoreHeight').value='0';$('cancelRestore').onclick=showNoWallet;$('restoreSubmit').onclick=restoreSubmit;
  }
  async function restoreSubmit() {
    const filename=$('restoreName').value.trim(), seed=$('restoreSeed').value.trim().replace(/\s+/g,' '), password=$('restorePassword').value, heightText=$('restoreHeight').value.trim()||'0';
    if(!/^[a-zA-Z0-9_-]{1,64}$/.test(filename))return showFormError('restoreError','Use 1–64 letters, numbers, underscores or hyphens for the wallet name.');
    if(seed.split(' ').length!==25)return showFormError('restoreError','A Nerva mnemonic seed should contain 25 words. Check for missing or extra words.');
    if(password.length<10)return showFormError('restoreError','Use a wallet password of at least 10 characters.');
    if(!/^\d+$/.test(heightText))return showFormError('restoreError','Restore height must be a whole block number.');
    if(!$('restoreSeedAck').checked)return showFormError('restoreError','Confirm the seed safety warning before restoring.');
    const btn=$('restoreSubmit');btn.disabled=true;btn.textContent='Restoring…';
    try { await rpc('restore_wallet_from_seed',{filename,password,seed,restore_height:Number(heightText),language:'English',seed_offset:''});
      // Clear the form's visible copy promptly.
      $('restoreSeed').value=''; closeModal();setConnection(true);toast('Restore started. Wallet scanning can take time for older wallets.','success');await loadWallet();await loadNetwork();
    } catch(e){showFormError('restoreError',e.message);}
    finally{if($('restoreSubmit')){btn.disabled=false;btn.textContent='Restore wallet';}}
  }
  function showFormError(id,message){const el=$(id);el.hidden=false;el.textContent=message;}
  async function sendModal() {
    if (state.demo) { demoSendModal(); return; }
    if (!state.connected) { settingsModal(); return; }
    if (!state.walletOpen) { showNoWallet(); return; }
    modal('Send XNV','OUTGOING TRANSFER',
      `<p class="muted" style="font-size:11px;margin:0 0 16px">Check the destination and amount carefully. Nerva transactions cannot normally be reversed.</p>
       ${field('sendAddress','Recipient address','Paste a Nerva address')}${field('sendAmount','Amount (XNV)','0.00','text','Available balance: '+xnv(state.unlocked)+' XNV')}
       <div class="field"><label for="sendFee">Network fee</label><input id="sendFee" disabled value="Calculated by Nerva before broadcast"><small>Fee selection is handled by the protocol/wallet engine.</small></div>
       <label class="check-row"><input id="sendConfirm" type="checkbox"><span>I have checked the recipient address and the amount.</span></label><div id="sendError" class="inline-notice warning" hidden></div>`,
      `<button class="btn btn-secondary" id="cancelSend">Cancel</button><button class="btn btn-primary" id="reviewSend">Review transfer →</button>`);
    $('cancelSend').onclick=closeModal;$('reviewSend').onclick=reviewSend;
  }
  async function reviewSend() {
    const address=$('sendAddress').value.trim(), amount=$('sendAmount').value.trim();
    if(!address)return showFormError('sendError','Enter the recipient address.');
    let atomic;try{atomic=parseXnvToAtomic(amount);}catch(e){return showFormError('sendError',e.message);}
    if(!$('sendConfirm').checked)return showFormError('sendError','Confirm the recipient and amount.');
    const btn=$('reviewSend');btn.disabled=true;btn.textContent='Checking address…';
    try {
      // Check formats and decimal precision locally with the Rust core first. Keep the
      // upstream wallet-RPC validation as a second check before preparing any transaction.
      const rustAddress=await api('/api/validate-address',{address});
      if(!rustAddress.valid) throw new Error(rustAddress.message || 'Rust Nerva address validation failed.');
      const rustAmount=await api('/api/amount/parse',{amount});
      if(rustAmount.atomic_units!==atomic) throw new Error('Amount precision mismatch; review the entered amount.');
      const valid=await rpc('validate_address',{address});
      const isValid=valid.valid===true || valid.good===true || valid.integrated===true;
      if(!isValid) throw new Error('Nerva did not confirm this address as valid. Check it carefully.');
      btn.textContent='Preparing transaction…';
      // Prepare and sign without broadcasting; request serialized pending-tx metadata
      // so relay_tx can broadcast only after the final user confirmation.
      const prepared=await rpc('transfer',{destinations:[{address,amount:atomic}],account_index:0,priority:1,get_tx_key:false,do_not_relay:true,get_tx_metadata:true});
      const txBlob=prepared.tx_metadata || ''; // relay_tx expects Nerva's serialized pending-tx metadata, not raw tx bytes.
      if(!txBlob) throw new Error('This Nerva wallet RPC build did not return the transaction metadata needed for safe relay. Nothing was broadcast. Update the wallet RPC or use the official wallet to send.');
      const fee=prepared.fee || '0';
      modal('Confirm transfer','FINAL CHECK',
        `<div class="summary-row"><span>To</span><strong>${html(address)}</strong></div><div class="summary-row"><span>Amount</span><strong>${html(xnv(atomic,12))} XNV</strong></div><div class="summary-row"><span>Network fee</span><strong>${html(xnv(fee,12))} XNV</strong></div><div class="summary-row"><span>Total from balance</span><strong>${html(xnv((BigInt(atomic)+BigInt(fee)).toString(),12))} XNV</strong></div><div class="inline-notice warning">The transaction is prepared but has not been broadcast. Confirm only if the address, amount and fee are correct.</div><label class="check-row"><input id="finalConfirm" type="checkbox"><span>I understand that this transaction cannot be cancelled after broadcast.</span></label><div id="finalError" class="inline-notice warning" hidden></div>`,
        `<button class="btn btn-secondary" id="discardPrepared">Discard</button><button class="btn btn-primary" id="sendFinal">Broadcast transaction →</button>`);
      btn.disabled=false;btn.textContent='Review transfer →';
      $('discardPrepared').onclick=()=>{closeModal();toast('Prepared transaction discarded. Nothing was broadcast.');};
      $('sendFinal').onclick=async()=>{
        if(!$('finalConfirm').checked){showFormError('finalError','Please confirm the final warning.');return;}
        const finalBtn=$('sendFinal');finalBtn.disabled=true;finalBtn.textContent='Broadcasting…';
        try {
          const result=await rpc('relay_tx',{hex:txBlob});
          closeModal();toast(`Transfer broadcast. Tx: ${String(result.tx_hash||prepared.tx_hash||'hash returned by wallet').slice(0,22)}…`,'success');await loadWallet();await loadNetwork();
        } catch(e){showFormError('finalError',e.message);finalBtn.disabled=false;finalBtn.textContent='Broadcast transaction →';}
      };
    } catch(e) {showFormError('sendError',e.message);btn.disabled=false;btn.textContent='Review transfer →';}
  }
  function demoSendModal() {
    modal('Demo send','DEMO MODE · NO REAL FUNDS',`${field('demoTo','Recipient address','Example Nerva address')}${field('demoAmount','Amount (XNV)','1.00')}<div class="inline-notice warning">Demo mode never connects to Nerva and cannot send real funds.</div>`, `<button class="btn btn-secondary" id="demoCancel">Cancel</button><button class="btn btn-primary" id="demoSend">Preview demo only</button>`);
    $('demoCancel').onclick=closeModal;$('demoSend').onclick=()=>{closeModal();toast('Demo only: nothing was signed or broadcast.','');};
  }
  async function openWalletChooser() { if (!state.connected) {settingsModal(); return;} if(!state.walletOpen)showNoWallet();else closeModal(); }
  function enterDemo() {
    state.demo=true;state.connected=true;state.walletOpen=true;state.rpcUrl='';state.rpcUsername='nerva';state.address='NV-demo-address-not-valid-for-payments';state.balance='127482000000000';state.unlocked='98320000000000';state.transfers={in:[{txid:'demo-in-1',amount:'24000000000000',timestamp:1792537200},{txid:'demo-in-2',amount:'6500000000000',timestamp:1792364400}],out:[{txid:'demo-out-1',amount:'12000000000000',timestamp:1792184400,fee:'1000000000'}]};
    setConnection(true,'Demo view only');$('connectionLabel').textContent='Demo mode';$('connectionDetail').textContent='No RPC · no real funds';$('networkLabel').textContent='Demo mode';$('networkHeight').textContent='';$('syncLabel').textContent='Sample scan · demo';$('syncFill').style.width='72%';updateBalance();renderActivity();renderReceive();$('balanceMode').textContent='Demo data · not real funds';toast('Demo mode: balances and transfers are fictional.','');
  }
  async function disconnect() { try { await api('/api/disconnect',{}); } catch(_) {} state.demo=false;state.connected=false;state.walletOpen=false;state.rpcUrl='';state.rpcUsername='nerva';state.address='';state.balance='0';state.unlocked='0';state.transfers=[];setConnection(false);updateBalance();renderActivity();renderSettings();closeModal();toast('Disconnected.');setView('setup'); }
  async function copyAddress() {
    if(!state.address)return;
    if(state.demo){toast('Demo address is fictional and must not be used for payments.','error');return;}
    try{await navigator.clipboard.writeText(state.address);toast('Nerva address copied.','success');}catch(_){
      modal('Copy your address','RECEIVE XNV',`<div class="address-full">${html(state.address)}</div>`, `<button class="btn btn-primary" id="copyManualDone">Close</button>`);$('copyManualDone').onclick=closeModal;
    }
  }
  async function setupStart() {
    document.querySelectorAll('[data-view]').forEach(el=>el.addEventListener('click',()=>setView(el.dataset.view)));
    $('openSettings').onclick=()=>setView('settings');$('openSettingsTop').onclick=()=>setView('settings');$('closeModal').onclick=closeModal;
    $('modalBackdrop').addEventListener('click',e=>{if(e.target===$('modalBackdrop'))closeModal();});
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('modalBackdrop').hidden)closeModal();});
    $('sendBtn').onclick=()=>setView('send');$('receiveBtn').onclick=()=>setView('receive');$('copyAddressBtn').onclick=copyAddress;$('receiveCopyBtn').onclick=copyAddress;$('refreshBtn').onclick=()=>refreshAll(true);
    $('reviewSend').onclick=reviewSend;
    $('clearSend').onclick=()=>{ $('sendAddress').value=''; $('sendAmount').value=''; $('sendConfirm').checked=false; $('sendError').hidden=true; };
    $('settingsConnectBtn').onclick=settingsModal;
    $('settingsDisconnectBtn').onclick=disconnect;
    $('daemonConfigBtn').onclick=daemonSettingsModal;
    $('settingsCreateBtn').onclick=()=>state.connected?createWalletModal():settingsModal();
    $('settingsOpenBtn').onclick=()=>state.connected?openWalletModal():settingsModal();
    $('settingsRestoreBtn').onclick=()=>state.connected?restoreWalletModal():settingsModal();
    $('applyRefreshSetting').onclick=()=>{ const v=Number($('refreshInterval').value); if(![5,12,30,60].includes(v))return; state.refreshSeconds=v; startPolling(); renderSettings(); toast(`Interface refresh set to ${v} seconds.`,'success'); };
    $('setupConnectBtn').onclick=settingsModal;$('setupCreateBtn').onclick=()=>state.connected?createWalletModal():settingsModal();$('setupOpenBtn').onclick=()=>state.connected?openWalletModal():settingsModal();$('setupRestoreBtn').onclick=()=>state.connected?restoreWalletModal():settingsModal();$('demoBtn').onclick=()=>{enterDemo();setView('wallet');};
    // Render a usable first screen immediately; public network status must not block startup.
    setView('setup');updateBalance();$('balanceMode').textContent='Connect to see live funds';
    try { const s=await api('/api/status'); if(s.connected){state.rpcUrl=s.url||'http://127.0.0.1:18082';state.rpcUsername='nerva';setConnection(true,s.version?`Nerva RPC ${s.version}`:'Local wallet engine ready');await loadWallet();setView('wallet');} } catch(_) {}
    loadNetwork();
    renderSettings();
    startPolling();
  }
  function startPolling() {
    if (state.refreshTimer) clearInterval(state.refreshTimer);
    state.refreshTimer = setInterval(async()=>{if(state.demo)return;if(state.connected&&state.walletOpen){await loadWallet();}await loadNetwork();}, state.refreshSeconds * 1000);
  }
  setupStart();
})();
