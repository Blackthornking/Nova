package com.nervasimple

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import java.security.SecureRandom
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.text.InputType
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var splash: View? = null
    @Volatile private var sessionToken: String = ""

    private external fun startNativeServer(binaryPath: String, walletDir: String, daemon: String, sessionToken: String): Int
    private external fun stopNativeServer()

    companion object {
        init { System.loadLibrary("nerva_rust") }
        private const val LOCAL_URL = "http://127.0.0.1:8765/"
        private const val DEFAULT_DAEMON = "node.nerva.one:17566"
        @Volatile private var processSessionToken: String? = null

        @Synchronized private fun sessionTokenForProcess(): String {
            val current = processSessionToken
            if (current != null) return current
            val random = ByteArray(32).also { SecureRandom().nextBytes(it) }
            return random.joinToString("") { "%02x".format(it) }.also { processSessionToken = it }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16, 14, 32)
        window.navigationBarColor = android.graphics.Color.rgb(16, 14, 32)
        showLoading("Starting Nerva wallet engine…")
        Thread {
            try {
                val engineDir = File(filesDir, "engine")
                copyAssetTree("engine", engineDir)
                val binary = File(engineDir, "nerva-wallet-rpc")
                if (!binary.isFile || binary.length() < 1_000_000L) {
                    runOnUiThread { showFatal("The verified Nerva Android engine is missing. Rebuild the project with network access so the Gradle preparation task can download it.") }
                    return@Thread
                }
                binary.setReadable(true, true)
                binary.setExecutable(true, true)
                val walletDir = File(filesDir, "wallets")
                walletDir.mkdirs()
                val prefs = getSharedPreferences("nerva_wallet_settings", MODE_PRIVATE)
                val daemon = prefs.getString("daemon", DEFAULT_DAEMON) ?: DEFAULT_DAEMON
                sessionToken = sessionTokenForProcess()
                val result = startNativeServer(binary.absolutePath, walletDir.absolutePath, daemon, sessionToken)
                if (result != 0) {
                    runOnUiThread { showFatal("The Rust wallet service could not start (code $result). Check that the Android ARM64 engine was extracted correctly and that port 8765 is available.") }
                    return@Thread
                }
                runOnUiThread { showWallet() }
            } catch (e: Throwable) {
                runOnUiThread { showFatal("Wallet startup failed: ${e.message ?: e.javaClass.simpleName}") }
            }
        }.start()
    }

    private fun showLoading(message: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
            setBackgroundColor(android.graphics.Color.rgb(16, 14, 32))
            gravity = android.view.Gravity.CENTER
        }
        val title = TextView(this).apply {
            text = "NERVA SIMPLE WALLET"
            textSize = 22f
            setTextColor(android.graphics.Color.rgb(117, 201, 216))
            gravity = android.view.Gravity.CENTER
        }
        val progress = ProgressBar(this).apply { isIndeterminate = true }
        val sub = TextView(this).apply {
            text = message
            textSize = 14f
            setTextColor(android.graphics.Color.WHITE)
            gravity = android.view.Gravity.CENTER
            setPadding(0, 28, 0, 0)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(progress, LinearLayout.LayoutParams(-2, -2).apply { topMargin = 30 })
        root.addView(sub, LinearLayout.LayoutParams(-1, -2))
        splash = root
        setContentView(root)
    }

    private fun showFatal(message: String) {
        showLoading("Could not start wallet")
        val root = splash as? LinearLayout ?: return
        (root.getChildAt(1) as? ProgressBar)?.visibility = View.GONE
        val detail = TextView(this).apply {
            text = message + "\n\nNo wallet has been created or modified by this startup failure."
            textSize = 14f
            setTextColor(android.graphics.Color.WHITE)
            gravity = android.view.Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        root.addView(detail, LinearLayout.LayoutParams(-1, -2))
        val close = android.widget.Button(this).apply { text = "Close"; setOnClickListener { finish() } }
        root.addView(close, LinearLayout.LayoutParams(-1, -2))
    }

    private fun showWallet() {
        webView = WebView(this)
        webView.setBackgroundColor(android.graphics.Color.rgb(16, 14, 32))
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
        }
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest) =
                assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.scheme == "https" && uri.host == "appassets.androidplatform.net") return false
                if (uri.scheme == "https" && request.isForMainFrame) {
                    try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) { }
                }
                // Never navigate the document to the local RPC API. It is only a fetch target.
                return true
            }
        }
        setContentView(webView)
        val html = assets.open("www/index.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
            .replace("__SESSION_TOKEN__", sessionToken)
            .replace("__API_BASE__", "http://127.0.0.1:8765")
        webView.loadDataWithBaseURL("https://appassets.androidplatform.net/", html, "text/html", "UTF-8", null)
    }

    private fun copyAssetTree(assetPath: String, destination: File) {
        val children = assets.list(assetPath) ?: emptyArray()
        if (children.isNotEmpty()) {
            destination.mkdirs()
            children.filterNot { it == ".gitkeep" }.forEach { child ->
                copyAssetTree("$assetPath/$child", File(destination, child))
            }
        } else {
            destination.parentFile?.mkdirs()
            assets.open(assetPath).use { input -> FileOutputStream(destination).use { output -> input.copyTo(output) } }
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
