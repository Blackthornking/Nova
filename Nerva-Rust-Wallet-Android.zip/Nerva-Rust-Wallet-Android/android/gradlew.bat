@echo off
setlocal EnableExtensions
set "VERSION=8.9"
set "SHA256=d725d707bfabd4dfdc958c624003b3c80accc03f7037b5122c4b1d0ef15cecab"
if not defined GRADLE_USER_HOME set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "BASE=%GRADLE_USER_HOME%\nerva-bootstrap"
set "ZIP=%BASE%\gradle-%VERSION%-bin.zip"
set "DIST=%BASE%\gradle-%VERSION%"
if not exist "%BASE%" mkdir "%BASE%"
if not exist "%ZIP%" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%ZIP%'"
  if errorlevel 1 exit /b 2
)
for /f %%H in ('powershell -NoProfile -Command "(Get-FileHash -Algorithm SHA256 '%ZIP%').Hash.ToLower()"') do set "ACTUAL=%%H"
if /I not "%ACTUAL%"=="%SHA256%" (
  del /q "%ZIP%" >nul 2>nul
  echo Gradle distribution checksum mismatch; refusing to execute it. 1>&2
  exit /b 3
)
if not exist "%DIST%\bin\gradle.bat" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP%' '%BASE%'"
  if errorlevel 1 exit /b 2
)
call "%DIST%\bin\gradle.bat" -p "%~dp0" %*
exit /b %ERRORLEVEL%
