# Fast-scan engine changes (experimental branch)

This change set improves the existing Nerva wallet scanner without changing consensus, serialized transactions, address formats, or network protocol. It is suitable for benchmarking and review, not yet a release claim.

## Implemented in `src/wallet/wallet2.cpp`

### 1. Use the configured scan concurrency

The wallet scan semaphore previously used `max(1, configured_concurrency / 2)`. It now allows up to the configured worker count. Historical wallet scanning is CPU-heavy (elliptic-curve derivation and output ownership checks); limiting it to half the available workers unnecessarily caps parallel scanning on CPU-bound systems. The existing global concurrency setting remains the cap, so deployments can continue to tune it.

**Risk / benchmark requirement:** higher concurrency can increase CPU and memory contention on low-memory systems or when the wallet is sharing a machine with other workloads. Benchmark at 1, 2, 4, and the default worker cap before choosing release defaults. This patch does not claim a measured end-to-end speedup.

### 2. Build additional output-key derivations once per transaction

In `process_parsed_blocks`'s `geniod` scanner, the old code allocated and populated a `std::vector<crypto::key_derivation>` for every output, then cleared it after the first primary-key check. The new code builds that vector once per transaction and passes it only to the same first primary-key check. Later primary-key checks still receive an empty list, preserving the existing lookup semantics. Transactions without primary public keys skip this no-op scan work.

The work for copying additional derivations changes from O(outputs × additional-key-count) to O(additional-key-count) per transaction, and per-output vector allocations are eliminated.

### 3. Avoid concurrent writes to the software device's mode field

`check_acc_out_precomp` runs in parallel. The software device's derivation routines do not read its `mode`, so repeatedly setting `TRANSACTION_PARSE` from each worker was redundant and wrote the same non-atomic shared field concurrently. Software-device scans now skip that write; hardware devices still set parse mode under the existing device lock.

## VScan protocol research remains experimental

The existing `cryptonote_basic/vscan.*` files contain tag/index primitives only. They are **not wired into transaction serialization, consensus validation, block commitments, daemon RPC, or wallet scanning**. Enabling tag-only filtering before a consensus-enforced sender format would risk missing funds. Those changes require a separately reviewed hard fork and are not part of these backwards-compatible optimisations.

## Test status in this environment

- Scanner source invariants checked: concurrency limiter uses the configured maximum; additional-key derivations are constructed outside the output loop; the first-primary/secondary-key lookup behavior is retained; software mode is not written from parallel scanner tasks.
- Full CMake configuration attempted, but stopped before compiling Nerva because the uploaded source archive omits `external/miniupnp/miniupnpc` and the `external/unbound` CMake project, and the environment lacks Boost link libraries (`filesystem`, `thread`, `date_time`, `chrono`, `serialization`, `program_options`).
- Consequently, no C++ build, native unit test, live-wallet scan, or performance benchmark could be completed here. Do not treat static checks as a substitute for those tests.

## Required benchmark before release

Build baseline and patched revisions with the same compiler/flags, then use copies of the same wallet and same local daemon/database. Record time to the same scan height, peak RSS, CPU utilization, and recovered transfer count. Repeat in alternating baseline/patched order to reduce filesystem cache bias. Test normal software wallets, watch-only wallets, subaddresses, additional tx public keys, chain reorganisations, and hardware-wallet mode. Compare balances and transfer IDs exactly, not approximately.
