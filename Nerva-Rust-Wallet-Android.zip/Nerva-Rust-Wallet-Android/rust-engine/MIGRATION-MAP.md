# Upstream-to-Rust migration map

Paths in the first column refer to the included Nerva C++ reference snapshot. This table records current implementation boundaries; it is not a claim of full parity.

| Upstream C++ area | Rust destination | Current state |
|---|---|---|
| `src/cryptonote_config.h` | `crates/nerva-core/src/lib.rs` | Mainnet prefixes/decimal-place constants ported; still needs compiled differential vectors |
| `src/common/base58.cpp` | `crates/nerva-core/src/base58.rs` | Block Base58 round trips implemented; parity tests authored |
| `src/cryptonote_basic/cryptonote_format_utils.cpp` | `crates/nerva-core/src/address.rs` | Address checksum/prefix parsing and subaddress public keys implemented; parity tests required |
| `src/crypto/crypto.cpp` | `crates/nerva-core/src/crypto.rs` | Keccak, key derivation, output-key derivation and subaddress primitives implemented; no key-image hash-to-point yet |
| `src/mnemonics/electrum-words.cpp` | `crates/nerva-core/src/mnemonic.rs` | 12/24/25 word encoding/decoding and restore path authored; compare across real upstream seed vectors |
| `src/cryptonote_basic/transaction.cpp`, `cryptonote_format_utils.cpp` | `crates/nerva-core/src/tx_prefix.rs` | Bounded prefix parser for v1/v2, outputs, generation/key inputs and key images; signatures, block parser and tx hash preimages remain incomplete |
| `src/cryptonote_basic/tx_extra.h` | `crates/nerva-core/src/tx_extra.rs` | Public/additional tx keys, nonce, padding and selected known fields parsed; malformed/unknown fields fail closed |
| `src/ringct/rctOps.cpp`, `src/ringct/rctSigs.cpp` | `crates/nerva-core/src/ringct.rs` | RingCT base parser, legacy/compact ECDH amount recovery and Pedersen output commitment matching implemented; not a RingCT proof/signature verifier |
| `src/wallet/wallet2.cpp` output matching | `crates/nerva-core/src/scanner.rs` | Parallel matching and selected output amount recovery implemented; needs canonical-block input and differential output parity |
| `src/wallet/wallet2.cpp` persistence | `crates/nerva-wallet/src/storage.rs` | New Argon2id/ChaCha20-Poly1305 wallet format and seed restore; **not** legacy `.keys` compatible |
| `src/wallet/wallet2.cpp` scan state/reorgs | `crates/nerva-wallet/src/scan_journal.rs`, `tracking.rs` | Atomic persistence of scan metadata, spend matching from supplied key images, chain-window rollback; no key-image generation yet |
| `src/ringct/*`, `src/crypto/crypto.cpp`, `cryptonote_tx_utils.cpp` | Not implemented | Critical gap: hash-to-point/key images, decoys/fees, active-fork RingCT proof/signature generation, transaction signing/serialization; type IDs present in source are not proof of mainnet activation |
| `src/wallet/wallet_rpc_server.cpp` | Android app + `rust/src/lib.rs` | App still uses official `nerva-wallet-rpc` for all real wallet operations; Rust local API is not a replacement signing engine |

## Next phases

1. Compile and fix all Rust workspace errors, warnings and test failures.
2. Export C++ reference vectors for addresses, seed restore, key derivation, RingCT ECDH and owned-output scanning; require parity.
3. Implement Nerva hash-to-point and key-image generation, then validate spent-output detection against wallet2.
4. Implement complete transaction and block serialization/hash preimages, unlock rules, proof/signature verification, and robust scan recovery.
5. Implement spend selection, dynamic fees, decoy selection, the RingCT/proof/signature formats actually active at each Nerva hard fork, signed transaction serialization and relay; validate every transaction with the upstream testnet daemon.
6. Fuzz parsers, audit secret handling, implement legacy wallet-file migration, and run dual-engine shadow scans and Android ARM64 end-to-end tests.
7. Only after all release gates pass, consider replacing the official C++ engine in the UI.

Never bypass the tests. An incomplete scan can hide a deposit; an incorrect signer can make funds irrecoverable.
