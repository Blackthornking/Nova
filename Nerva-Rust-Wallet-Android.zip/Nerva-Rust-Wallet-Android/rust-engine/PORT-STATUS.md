# Rust engine port status — Phase 2

## Implemented in this source tree

- Nerva mainnet standard, integrated and subaddress encoding/decoding, CryptoNote block Base58, Keccak checksums, and spend/view public key derivation.
- Exact XNV 12-decimal amount formatting/parsing and canonical varint encoding.
- English CryptoNote mnemonic encode/decode for the supported 12/24/25-word forms, deterministic account key derivation and seed-based restore into the **new Rust wallet format**.
- An Argon2id + ChaCha20-Poly1305 encrypted Rust wallet container, authenticated metadata, key consistency checks, atomic writes and owner-only Unix permissions. This container is **not** compatible with upstream `.keys` files.
- Bounded transaction-prefix parsing with transparent outputs, generation/key inputs, relative offsets and key images; bounded transaction-extra parsing including additional transaction public keys.
- RingCT base parsing for Nerva's current type identifiers, receiver-side ECDH amount recovery (legacy and compact encodings), output commitment matching, and a full serialized-transaction scanner that combines output ownership with amount recovery.
- Rayon parallel output matching with transaction-key derivation reuse.
- Persistent reorg-aware scan journal and wallet scan records, amount/balance summaries, supplied-key-image spend matching, automatic history recording for transactions with owned outputs/known spent outputs, and reorg rollback of outputs, history and spend marks.
- Unit tests authored for these modules and CI workflows for Rust workspace tests and Android packaging.

## Still not a complete or fund-safe replacement

- No complete consensus validation: range-proof/signature verification for Nerva's active transaction formats, transaction hash/prehash reconstruction, unlock/maturity checks and block/chain validation are not implemented. Current official Nerva material identifies hard-fork 13 as active; parser support for future CLSAG/Bulletproof+ type IDs is not confirmation of activation.
- No verified CryptoNote hash-to-point/key-image generation or complete deterministic-output private-key recovery; the tracker only recognises spends once valid owned-output key images have been provided.
- No Rust transaction construction, fee/decoy selection, active-fork RingCT proof/signature generation, transaction serialization or relay implementation.
- No import/export compatibility for upstream C++ wallet files, password-change/migration workflow or secure mnemonic presentation UI.
- No end-to-end dual-engine parity tests or valid-mainnet/testnet transaction round-trip.
- The Android UI continues to use the official, checksum-pinned `nerva-wallet-rpc` for real create/restore/balance/transfer/sign/broadcast operations. The Rust parser/scanner and storage are not yet the mainnet engine.

## Build/test status

The implementation source and tests were added, but `cargo`, `rustc`, Android SDK/NDK and the Gradle runtime are not installed in this environment. Therefore Rust tests, `clippy`, and the APK have **not** been built or executed here. The code must be compiled and tested by `.github/workflows/rust-engine.yml`; failures or compatibility mismatches must be fixed before this can be considered usable.

## Required release gate

Do not switch the Android app to the Rust spending path or use this as a standalone mainnet wallet until the workspace compiles, differential C++ vectors match, fuzzing and review are completed, active-fork RingCT/signature and key-image compatibility is verified, and Android ARM64 end-to-end send/receive/restore tests pass. This is a protocol-security requirement, not a UI polish item.
