# Nerva Rust Wallet Engine — Phase 2 implementation

This workspace now contains more than UI scaffolding: it has Rust code for Nerva address/account primitives, seed handling, encrypted account storage, bounded transaction and `tx_extra` parsing, receiver-side RingCT amount recovery with output commitment checks, parallel output matching, and persistent wallet scan/reorg tracking.

**It is still an experimental port, not a full replacement for Nerva `wallet2`.** In particular, no current Rust code creates and signs mainnet transactions. The Android wallet continues to use the official, SHA-256-pinned Nerva `nerva-wallet-rpc` binary for actual wallet creation/restoration, balance/history, transaction construction/signing and broadcast.

## What the Rust workspace contains

### `nerva-core`

- Mainnet address prefixes and Base58/checksum encoding for standard, integrated and subaddresses.
- Exact XNV atomic amounts, CryptoNote varints, Keccak and key derivation.
- English 12/24/25-word seed encode/decode and deterministic account restore.
- Bounded transaction-prefix and tx-extra parsers; key inputs preserve key images for later spend matching.
- RingCT base parsing (Nerva type IDs 0–7), old and compact ECDH amount recovery, and output commitment matching.
- A full transaction output scanner that identifies owned keys in parallel and recovers amounts only after output commitment matching.

### `nerva-wallet-engine`

- A new encrypted Rust wallet container (Argon2id + ChaCha20-Poly1305), authenticated data, atomic save, private-file permissions, and seed-based restore. **The format is new and does not import upstream `.keys` files.**
- Reorg-aware persistent scan journal.
- Persisted incoming-output/transaction records, balance summaries, supplied-key-image spend matching, and reorg cleanup.

## Critical missing pieces

The Rust workspace does **not** yet verify RingCT range proofs or Bulletproof+, CLSAG/MLSAG signatures, consensus/block validity, key-image hash-to-point generation, transaction hashes/preimages, decoy/fee selection, transaction construction/signing/serialization, or relay. Its incoming tracking can only mark outputs spent when a valid key image is available; it does not generate one from an output's secret key. It also has not been proven compatible with real Nerva wallet files or transaction vectors. Nerva's published docs identify hard-fork 13 as current; this parser recognizes extra RingCT type IDs present in the C++ codebase but does not assert that newer CLSAG/Bulletproof+ formats are active on mainnet.

A receiver-side amount commitment match does not prove that a complete transaction is valid. The caller must verify canonical chain inclusion and consensus before trusting scanned balances. **Do not use the experimental Rust scanner as the sole source of truth for mainnet funds.**

## Build and test

With stable Rust/Cargo installed:

```sh
cargo fmt --all
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
```

The assembly environment did not contain `cargo` or `rustc`, so these commands have **not** been executed here. The automated workflow `.github/workflows/rust-engine.yml` runs them on pushes and pull requests touching this directory. An APK build requires Android SDK/NDK and Gradle and has not been run here either.

## Performance target (not a measured result)

The scanner reuses each transaction-key derivation and parallelises candidate output matching with Rayon. No speedup claim is made: benchmark only after output/amount parity with upstream C++ is exact on identical block ranges, wallet seeds and hardware.
