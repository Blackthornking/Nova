# English mnemonic word list attribution

`english.txt` is extracted from `src/mnemonics/english.h` in the supplied Nerva Project source snapshot. That source header carries the Nerva Project / Monero Project copyright notices and BSD 3-Clause license. The upstream source archive is retained at `../reference/nerva-upstream-cpp-ce936d0f.zip`. Consult the included source `LICENSE` and upstream notices for redistribution terms.
