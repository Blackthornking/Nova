//! Nerva primary account-key derivation helpers.
//!
//! The default Nerva account derives its view secret by Keccak-256 hashing the spend secret
//! and reducing that hash modulo the Ed25519 scalar order, matching upstream `account_base::generate`.
use crate::{address::{Address, AddressError}, crypto::{hash_to_scalar, public_key_from_secret, CryptoError, SecretKey}};
use thiserror::Error;

#[derive(Debug, PartialEq, Eq, Error)]
pub enum AccountError {
    #[error("spend secret key is invalid")]
    InvalidSpendSecret,
    #[error("view secret key is invalid")]
    InvalidViewSecret,
    #[error("account key derivation failed: {0}")]
    Address(#[from] AddressError),
    #[error("cryptographic key error: {0}")]
    Crypto(#[from] CryptoError),
}

/// Holds a spend/view key pair and their canonical primary address. SecretKey redacts Debug
/// output and wipes its scalar on drop.
pub struct AccountKeys {
    spend_secret: SecretKey,
    view_secret: SecretKey,
    address: Address,
}

impl AccountKeys {
    /// Restore a conventional Nerva wallet from its 32-byte spend secret scalar.
    pub fn from_spend_secret(spend_secret: SecretKey) -> Result<Self, AccountError> {
        let view_bytes = hash_to_scalar(spend_secret.as_bytes()).to_bytes();
        let view_secret = SecretKey::from_bytes(view_bytes).map_err(|_| AccountError::InvalidViewSecret)?;
        Self::from_secret_keys(spend_secret, view_secret)
    }

    /// Import an account with independently supplied spend and view secrets.
    pub fn from_secret_keys(spend_secret: SecretKey, view_secret: SecretKey) -> Result<Self, AccountError> {
        let address = Address::from_secret_keys(&spend_secret, &view_secret);
        Ok(Self { spend_secret, view_secret, address })
    }

    pub fn address(&self) -> &Address { &self.address }
    pub fn spend_secret(&self) -> &SecretKey { &self.spend_secret }
    pub fn view_secret(&self) -> &SecretKey { &self.view_secret }
    pub fn spend_public_key(&self) -> [u8; 32] { public_key_from_secret(&self.spend_secret) }
    pub fn view_public_key(&self) -> [u8; 32] { public_key_from_secret(&self.view_secret) }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn sk(n: u8) -> SecretKey { let mut b=[0u8;32]; b[0]=n; SecretKey::from_bytes(b).unwrap() }

    #[test]
    fn conventional_wallet_derives_stable_view_key_from_spend_key() {
        let a=AccountKeys::from_spend_secret(sk(17)).unwrap();
        let b=AccountKeys::from_spend_secret(sk(17)).unwrap();
        assert_eq!(a.view_public_key(),b.view_public_key());
        assert_eq!(a.address(),b.address());
        assert_eq!(a.address().spend_public_key,a.spend_public_key());
        assert_eq!(a.address().view_public_key,a.view_public_key());
    }

    #[test]
    fn imported_independent_keys_are_preserved() {
        let account=AccountKeys::from_secret_keys(sk(7),sk(11)).unwrap();
        assert_eq!(account.spend_public_key(),account.address().spend_public_key);
        assert_eq!(account.view_public_key(),account.address().view_public_key);
    }
}
