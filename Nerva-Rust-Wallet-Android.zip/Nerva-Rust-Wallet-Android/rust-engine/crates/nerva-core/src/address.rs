//! Nerva mainnet CryptoNote address encoding and checksum verification.
use thiserror::Error;
use crate::{base58, consensus, crypto::{decode_public_key, derive_subaddress_public_keys, keccak256, public_key_from_secret, CryptoError, SecretKey}, varint};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AddressKind { Standard, Integrated, Subaddress }

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Address {
    pub kind: AddressKind,
    pub prefix: u64,
    pub spend_public_key: [u8; 32],
    pub view_public_key: [u8; 32],
    pub payment_id: Option<[u8; 8]>,
}

#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum AddressError {
    #[error("invalid CryptoNote Base58: {0}")]
    Base58(#[from] base58::Base58Error),
    #[error("address prefix varint is invalid")]
    Prefix,
    #[error("unknown Nerva address prefix")]
    UnknownPrefix,
    #[error("address payload has the wrong length")]
    PayloadLength,
    #[error("address checksum mismatch")]
    Checksum,
    #[error("invalid public key in address")]
    PublicKey,
    #[error("integrated addresses require an 8-byte payment ID")]
    PaymentId,
    #[error("provided secret keys do not match the primary address")]
    SecretKeyMismatch,
    #[error("address key derivation failed: {0}")]
    Crypto(String),
}

impl From<CryptoError> for AddressError {
    fn from(e: CryptoError) -> Self { Self::Crypto(e.to_string()) }
}

impl Address {
    /// Construct the primary address from canonical spend/view secret scalars.
    pub fn from_secret_keys(spend_secret: &SecretKey, view_secret: &SecretKey) -> Self {
        Self {
            kind: AddressKind::Standard,
            prefix: consensus::PUBLIC_ADDRESS_PREFIX,
            spend_public_key: public_key_from_secret(spend_secret),
            view_public_key: public_key_from_secret(view_secret),
            payment_id: None,
        }
    }

    /// Derive a Nerva subaddress. The primary address and supplied secret keys must match.
    pub fn derive_subaddress(base: &Address, spend_secret: &SecretKey, view_secret: &SecretKey, major: u32, minor: u32) -> Result<Self, AddressError> {
        if base.kind != AddressKind::Standard || base.prefix != consensus::PUBLIC_ADDRESS_PREFIX ||
           base.spend_public_key != public_key_from_secret(spend_secret) ||
           base.view_public_key != public_key_from_secret(view_secret) {
            return Err(AddressError::SecretKeyMismatch);
        }
        if major == 0 && minor == 0 { return Ok(base.clone()); }
        let (spend_public_key, view_public_key) = derive_subaddress_public_keys(spend_secret, view_secret, major, minor)?;
        Ok(Self { kind: AddressKind::Subaddress, prefix: consensus::SUBADDRESS_PREFIX, spend_public_key, view_public_key, payment_id: None })
    }

    pub fn decode(text: &str) -> Result<Self, AddressError> {
        if text.len() > 256 { return Err(AddressError::PayloadLength); }
        let raw = base58::decode(text)?;
        if raw.len() < 1 + 64 + 4 { return Err(AddressError::PayloadLength); }
        let (prefix, prefix_len) = varint::decode(&raw).map_err(|_| AddressError::Prefix)?;
        let kind = match prefix {
            consensus::PUBLIC_ADDRESS_PREFIX => AddressKind::Standard,
            consensus::INTEGRATED_ADDRESS_PREFIX => AddressKind::Integrated,
            consensus::SUBADDRESS_PREFIX => AddressKind::Subaddress,
            _ => return Err(AddressError::UnknownPrefix),
        };
        let payload_len = match kind { AddressKind::Integrated => 64 + 8, _ => 64 };
        if raw.len() != prefix_len + payload_len + 4 { return Err(AddressError::PayloadLength); }
        let checksum_start = raw.len() - 4;
        if keccak256(&raw[..checksum_start])[..4] != raw[checksum_start..] { return Err(AddressError::Checksum); }
        let mut spend = [0u8; 32];
        let mut view = [0u8; 32];
        spend.copy_from_slice(&raw[prefix_len..prefix_len + 32]);
        view.copy_from_slice(&raw[prefix_len + 32..prefix_len + 64]);
        decode_public_key(&spend).map_err(|_| AddressError::PublicKey)?;
        decode_public_key(&view).map_err(|_| AddressError::PublicKey)?;
        let payment_id = if kind == AddressKind::Integrated {
            let mut id = [0u8; 8]; id.copy_from_slice(&raw[prefix_len + 64..prefix_len + 72]); Some(id)
        } else { None };
        Ok(Self { kind, prefix, spend_public_key: spend, view_public_key: view, payment_id })
    }

    pub fn encode(&self) -> Result<String, AddressError> {
        let expected_prefix = match self.kind {
            AddressKind::Standard => consensus::PUBLIC_ADDRESS_PREFIX,
            AddressKind::Integrated => consensus::INTEGRATED_ADDRESS_PREFIX,
            AddressKind::Subaddress => consensus::SUBADDRESS_PREFIX,
        };
        if self.prefix != expected_prefix { return Err(AddressError::UnknownPrefix); }
        decode_public_key(&self.spend_public_key).map_err(|_| AddressError::PublicKey)?;
        decode_public_key(&self.view_public_key).map_err(|_| AddressError::PublicKey)?;
        if (self.kind == AddressKind::Integrated) != self.payment_id.is_some() { return Err(AddressError::PaymentId); }
        let mut raw = varint::encode(self.prefix);
        raw.extend_from_slice(&self.spend_public_key);
        raw.extend_from_slice(&self.view_public_key);
        if let Some(pid) = self.payment_id { raw.extend_from_slice(&pid); }
        let checksum = keccak256(&raw);
        raw.extend_from_slice(&checksum[..4]);
        Ok(base58::encode(&raw))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::crypto::{public_key_from_secret, SecretKey};
    fn sk(n:u8)->SecretKey { let mut b=[0u8;32]; b[0]=n; SecretKey::from_bytes(b).unwrap() }

    #[test]
    fn address_roundtrips_all_supported_prefix_classes() {
        let spend=public_key_from_secret(&sk(7));
        let view=public_key_from_secret(&sk(11));
        for (kind,prefix,pid) in [
            (AddressKind::Standard, consensus::PUBLIC_ADDRESS_PREFIX, None),
            (AddressKind::Subaddress, consensus::SUBADDRESS_PREFIX, None),
            (AddressKind::Integrated, consensus::INTEGRATED_ADDRESS_PREFIX, Some([0x42;8])),
        ] {
            let a=Address{kind,prefix,spend_public_key:spend,view_public_key:view,payment_id:pid};
            let encoded=a.encode().unwrap();
            assert_eq!(Address::decode(&encoded).unwrap(),a);
        }
    }

    #[test]
    fn derives_subaddress_from_primary_secrets() {
        let spend=sk(7); let view=sk(11);
        let primary=Address::from_secret_keys(&spend,&view);
        let sub=Address::derive_subaddress(&primary,&spend,&view,2,9).unwrap();
        assert_eq!(sub.kind,AddressKind::Subaddress);
        assert_eq!(Address::decode(&sub.encode().unwrap()).unwrap(),sub);
        assert_eq!(Address::derive_subaddress(&primary,&spend,&view,0,0).unwrap(),primary);
        assert_eq!(Address::derive_subaddress(&primary,&sk(8),&view,2,9),Err(AddressError::SecretKeyMismatch));
    }

    #[test]
    fn checksum_mutation_is_rejected() {
        let a=Address{kind:AddressKind::Standard,prefix:consensus::PUBLIC_ADDRESS_PREFIX,spend_public_key:public_key_from_secret(&sk(7)),view_public_key:public_key_from_secret(&sk(11)),payment_id:None};
        let mut encoded=a.encode().unwrap().into_bytes();
        let idx = encoded.len() / 2;
        encoded[idx]=if encoded[idx]==b'1' { b'2' } else { b'1' };
        let encoded=String::from_utf8(encoded).unwrap();
        assert!(Address::decode(&encoded).is_err());
    }
}
