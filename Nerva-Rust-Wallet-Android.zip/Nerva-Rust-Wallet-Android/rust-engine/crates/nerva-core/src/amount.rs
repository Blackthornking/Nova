//! Exact XNV amount arithmetic. Floating-point amounts are deliberately not exposed.
use crate::consensus::ATOMIC_UNITS_PER_XNV;
use thiserror::Error;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
pub struct Amount(u64);

#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum AmountError {
    #[error("amount is empty")]
    Empty,
    #[error("amount must be a positive decimal number")]
    Invalid,
    #[error("amount has more than 12 decimal places")]
    TooPrecise,
    #[error("amount overflows the supported range")]
    Overflow,
    #[error("amount must be greater than zero")]
    Zero,
}

impl Amount {
    pub const ZERO: Self = Self(0);
    pub const fn from_atomic(atomic: u64) -> Self { Self(atomic) }
    pub const fn atomic(self) -> u64 { self.0 }

    pub fn parse_xnv(input: &str) -> Result<Self, AmountError> {
        let text = input.trim();
        if text.is_empty() { return Err(AmountError::Empty); }
        if text.starts_with('-') || text.starts_with('+') || text.contains('e') || text.contains('E') {
            return Err(AmountError::Invalid);
        }
        let mut split = text.split('.');
        let whole = split.next().ok_or(AmountError::Invalid)?;
        let frac = split.next().unwrap_or("");
        if split.next().is_some() || whole.is_empty() || !whole.bytes().all(|b| b.is_ascii_digit()) || !frac.bytes().all(|b| b.is_ascii_digit()) {
            return Err(AmountError::Invalid);
        }
        if frac.len() > 12 { return Err(AmountError::TooPrecise); }
        let whole: u64 = whole.parse().map_err(|_| AmountError::Overflow)?;
        let whole_atomic = whole.checked_mul(ATOMIC_UNITS_PER_XNV).ok_or(AmountError::Overflow)?;
        let mut fractional = frac.to_owned();
        while fractional.len() < 12 { fractional.push('0'); }
        let frac_atomic: u64 = if fractional.is_empty() { 0 } else { fractional.parse().map_err(|_| AmountError::Overflow)? };
        let atomic = whole_atomic.checked_add(frac_atomic).ok_or(AmountError::Overflow)?;
        if atomic == 0 { return Err(AmountError::Zero); }
        Ok(Self(atomic))
    }

    /// Format with exactly 12 decimals so no value is hidden by trimming.
    pub fn format_xnv(self) -> String {
        format!("{}.{:012}", self.0 / ATOMIC_UNITS_PER_XNV, self.0 % ATOMIC_UNITS_PER_XNV)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn precise_amount_parsing_and_formatting() {
        assert_eq!(Amount::parse_xnv("1.000000000001").unwrap().atomic(), 1_000_000_000_001);
        assert_eq!(Amount::from_atomic(42).format_xnv(), "0.000000000042");
    }
    #[test]
    fn rejects_invalid_precision_and_zero() {
        assert_eq!(Amount::parse_xnv("0"), Err(AmountError::Zero));
        assert_eq!(Amount::parse_xnv("1.0000000000001"), Err(AmountError::TooPrecise));
        assert_eq!(Amount::parse_xnv("1e-4"), Err(AmountError::Invalid));
        assert_eq!(Amount::parse_xnv("-2"), Err(AmountError::Invalid));
    }
}
