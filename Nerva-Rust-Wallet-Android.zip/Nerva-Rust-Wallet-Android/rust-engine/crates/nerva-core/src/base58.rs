//! CryptoNote block Base58 (not Bitcoin's variable-length Base58Check).
use thiserror::Error;

const ALPHABET: &[u8; 58] = b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";

#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum Base58Error {
    #[error("invalid Base58 character")]
    InvalidCharacter,
    #[error("invalid encoded block length")]
    InvalidLength,
    #[error("Base58 block overflows its decoded size")]
    Overflow,
}

fn encoded_len(decoded_len: usize) -> Option<usize> {
    match decoded_len { 0 => Some(0), 1 => Some(2), 2 => Some(3), 3 => Some(5), 4 => Some(6), 5 => Some(7), 6 => Some(9), 7 => Some(10), 8 => Some(11), _ => None }
}
fn decoded_len(encoded_len: usize) -> Option<usize> {
    match encoded_len { 0 => Some(0), 2 => Some(1), 3 => Some(2), 5 => Some(3), 6 => Some(4), 7 => Some(5), 9 => Some(6), 10 => Some(7), 11 => Some(8), _ => None }
}

pub fn encode(data: &[u8]) -> String {
    let mut out = String::with_capacity(data.len() * 2);
    for chunk in data.chunks(8) {
        let mut number = 0u64;
        for &b in chunk { number = (number << 8) | b as u64; }
        let width = encoded_len(chunk.len()).expect("chunks are 1..=8 bytes");
        let mut block = vec![b'1'; width];
        for pos in (0..width).rev() {
            block[pos] = ALPHABET[(number % 58) as usize];
            number /= 58;
        }
        out.push_str(std::str::from_utf8(&block).expect("Base58 alphabet is ASCII"));
    }
    out
}

pub fn decode(text: &str) -> Result<Vec<u8>, Base58Error> {
    if text.is_empty() { return Ok(Vec::new()); }
    let bytes = text.as_bytes();
    let full = bytes.len() / 11;
    let rem = bytes.len() % 11;
    let last_size = if rem == 0 { 0 } else { decoded_len(rem).ok_or(Base58Error::InvalidLength)? };
    let mut out = Vec::with_capacity(full * 8 + last_size);
    for (i, chunk) in bytes.chunks(11).enumerate() {
        let expected = if i < full { 8 } else { last_size };
        if expected == 0 { continue; }
        let mut number = 0u64;
        for &c in chunk {
            let digit = ALPHABET.iter().position(|&a| a == c).ok_or(Base58Error::InvalidCharacter)? as u64;
            number = number.checked_mul(58).and_then(|n| n.checked_add(digit)).ok_or(Base58Error::Overflow)?;
        }
        let max = if expected == 8 { u64::MAX } else { (1u64 << (expected * 8)) - 1 };
        if number > max { return Err(Base58Error::Overflow); }
        let encoded = number.to_be_bytes();
        out.extend_from_slice(&encoded[8 - expected..]);
    }
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn crypto_note_base58_roundtrips_all_block_sizes() {
        for len in 1..100 {
            let bytes: Vec<u8> = (0..len).map(|i| (i * 31 + len) as u8).collect();
            assert_eq!(decode(&encode(&bytes)).unwrap(), bytes);
        }
    }
    #[test]
    fn rejects_bad_alphabet_and_remainders() {
        assert_eq!(decode(""), Ok(Vec::new()));
        assert_eq!(decode("0"), Err(Base58Error::InvalidLength));
        assert_eq!(decode("00"), Err(Base58Error::InvalidCharacter));
    }
}
