//! CryptoNote key derivation primitives for standard addresses and subaddresses.
//!
//! The related RingCT decoder lives in `ringct.rs`; CryptoNote key-image generation, complete
//! transaction signing and legacy wallet-file compatibility remain unported.
use curve25519_dalek::{
    constants::ED25519_BASEPOINT_POINT,
    edwards::{CompressedEdwardsY, EdwardsPoint},
    scalar::Scalar,
    traits::IsIdentity,
};
use tiny_keccak::{Hasher, Keccak};
use zeroize::{Zeroize, ZeroizeOnDrop};
use thiserror::Error;
use crate::varint;

#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum CryptoError {
    #[error("invalid/non-canonical secret scalar")]
    InvalidSecret,
    #[error("invalid or non-prime-order Edwards public key")]
    InvalidPublicKey,
    #[error("derivation failed")]
    DerivationFailed,
}

#[derive(Zeroize, ZeroizeOnDrop)]
pub struct SecretKey([u8; 32]);
impl SecretKey {
    pub fn from_bytes(bytes: [u8; 32]) -> Result<Self, CryptoError> {
        let scalar = Scalar::from_canonical_bytes(bytes).into_option().ok_or(CryptoError::InvalidSecret)?;
        if scalar == Scalar::ZERO { return Err(CryptoError::InvalidSecret); }
        Ok(Self(bytes))
    }
    /// Reduce an arbitrary 32-byte seed representation modulo the scalar order, matching Nerva's
    /// `generate_keys(..., recover=true)` behavior for a recovery seed. Zero is rejected.
    pub fn from_bytes_mod_order(bytes: [u8; 32]) -> Result<Self, CryptoError> {
        let scalar = Scalar::from_bytes_mod_order(bytes);
        if scalar == Scalar::ZERO { return Err(CryptoError::InvalidSecret); }
        Ok(Self(scalar.to_bytes()))
    }
    pub fn as_bytes(&self) -> &[u8; 32] { &self.0 }
    fn scalar(&self) -> Scalar { Scalar::from_canonical_bytes(self.0).into_option().expect("constructed as canonical scalar") }
}
impl std::fmt::Debug for SecretKey {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result { f.write_str("SecretKey([REDACTED])") }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct KeyDerivation(pub [u8; 32]);

pub fn keccak256(input: &[u8]) -> [u8; 32] {
    let mut hash = [0u8; 32];
    let mut hasher = Keccak::v256();
    hasher.update(input);
    hasher.finalize(&mut hash);
    hash
}

pub fn hash_to_scalar(input: &[u8]) -> Scalar {
    Scalar::from_bytes_mod_order(keccak256(input))
}

pub fn decode_public_key(bytes: &[u8; 32]) -> Result<EdwardsPoint, CryptoError> {
    let point = CompressedEdwardsY(*bytes).decompress().ok_or(CryptoError::InvalidPublicKey)?;
    if !point.is_torsion_free() { return Err(CryptoError::InvalidPublicKey); }
    Ok(point)
}

pub fn public_key_from_secret(secret: &SecretKey) -> [u8; 32] {
    (&ED25519_BASEPOINT_POINT * &secret.scalar()).compress().to_bytes()
}

/// Multiply an encoded public key by a private scalar (used by subaddress tx-key handling).
pub fn multiply_public_key(public_key: &[u8; 32], secret: &SecretKey) -> Result<[u8; 32], CryptoError> {
    let point = decode_public_key(public_key)?;
    Ok((&point * &secret.scalar()).compress().to_bytes())
}

/// Calculate Nerva/CryptoNote subaddress spend and view public keys from the primary secrets.
/// The SubAddr domain separator includes the terminating NUL byte as in the upstream C++ code.
pub fn derive_subaddress_public_keys(
    spend_secret: &SecretKey,
    view_secret: &SecretKey,
    major_index: u32,
    minor_index: u32,
) -> Result<([u8; 32], [u8; 32]), CryptoError> {
    if major_index == 0 && minor_index == 0 {
        return Ok((public_key_from_secret(spend_secret), public_key_from_secret(view_secret)));
    }
    let mut input = Vec::with_capacity(8 + 32 + 4 + 4);
    input.extend_from_slice(b"SubAddr\0");
    input.extend_from_slice(view_secret.as_bytes());
    input.extend_from_slice(&major_index.to_le_bytes());
    input.extend_from_slice(&minor_index.to_le_bytes());
    let m = hash_to_scalar(&input);
    let spend_scalar = spend_secret.scalar();
    let view_scalar = view_secret.scalar();
    let primary_spend = &ED25519_BASEPOINT_POINT * &spend_scalar;
    let offset_point = &ED25519_BASEPOINT_POINT * &m;
    let d = &primary_spend + &offset_point;
    let c = &d * &view_scalar;
    Ok((d.compress().to_bytes(), c.compress().to_bytes()))
}

/// CryptoNote generate_key_derivation: cofactor * (tx_public_key * view_secret_key).
pub fn generate_key_derivation(tx_public_key: &[u8; 32], view_secret: &SecretKey) -> Result<KeyDerivation, CryptoError> {
    let point = decode_public_key(tx_public_key)?;
    let view_scalar = view_secret.scalar();
    let shared = (&point * &view_scalar).mul_by_cofactor();
    if shared.is_identity() { return Err(CryptoError::DerivationFailed); }
    Ok(KeyDerivation(shared.compress().to_bytes()))
}

fn output_scalar(derivation: &KeyDerivation, output_index: u64) -> Scalar {
    let mut input = Vec::with_capacity(42);
    input.extend_from_slice(&derivation.0);
    input.extend_from_slice(&varint::encode(output_index));
    hash_to_scalar(&input)
}

/// Derive the per-output scalar used by CryptoNote RingCT ECDH amount decoding.
/// This value is not a spend secret; callers must still verify the output commitment.
pub fn derivation_scalar_bytes(derivation: &KeyDerivation, output_index: u64) -> [u8; 32] {
    output_scalar(derivation, output_index).to_bytes()
}

/// Derive the one-time public output key for any supported CryptoNote address spend key.
pub fn derive_public_key(derivation: &KeyDerivation, output_index: u64, spend_public_key: &[u8; 32]) -> Result<[u8; 32], CryptoError> {
    let spend = decode_public_key(spend_public_key)?;
    Ok(derive_public_key_from_point(derivation, output_index, &spend))
}

pub(crate) fn derive_public_key_from_point(derivation: &KeyDerivation, output_index: u64, spend: &EdwardsPoint) -> [u8; 32] {
    let offset = output_scalar(derivation, output_index);
    let offset_point = &ED25519_BASEPOINT_POINT * &offset;
    (spend + &offset_point).compress().to_bytes()
}

/// Derive the one-time private key; only call with the spend key for an owned output.
pub fn derive_secret_key(derivation: &KeyDerivation, output_index: u64, spend_secret: &SecretKey) -> [u8; 32] {
    (spend_secret.scalar() + output_scalar(derivation, output_index)).to_bytes()
}

#[cfg(test)]
mod tests {
    use super::*;
    fn sk(n: u8) -> SecretKey { let mut b = [0u8; 32]; b[0] = n; SecretKey::from_bytes(b).unwrap() }

    #[test]
    fn keccak256_is_keccak_not_sha3() {
        assert_eq!(hexless(keccak256(b"")), "c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470");
    }
    fn hexless(bytes: [u8;32]) -> String { bytes.iter().map(|b| format!("{b:02x}")).collect() }

    #[test]
    fn subaddress_keys_are_deterministic_and_distinct() {
        let spend = sk(7);
        let view = sk(11);
        let primary = derive_subaddress_public_keys(&spend, &view, 0, 0).unwrap();
        assert_eq!(primary, (public_key_from_secret(&spend), public_key_from_secret(&view)));
        let a = derive_subaddress_public_keys(&spend, &view, 1, 2).unwrap();
        let b = derive_subaddress_public_keys(&spend, &view, 1, 2).unwrap();
        let c = derive_subaddress_public_keys(&spend, &view, 1, 3).unwrap();
        assert_eq!(a, b);
        assert_ne!(a, c);
        assert_ne!(a.0, primary.0);
    }

    #[test]
    fn key_derivation_matches_sender_and_receiver_construction() {
        let view = sk(11);
        let spend = sk(7);
        let tx_secret = sk(5);
        let spend_pub = public_key_from_secret(&spend);
        let tx_pub = public_key_from_secret(&tx_secret);
        let receiver_derivation = generate_key_derivation(&tx_pub, &view).unwrap();
        // Sender-side derivation uses the recipient's public view key and tx secret.
        // Constructing the view public key then deriving the same shared point verifies symmetry.
        let view_pub = public_key_from_secret(&view);
        let sender_derivation = generate_key_derivation(&view_pub, &tx_secret).unwrap();
        assert_eq!(receiver_derivation, sender_derivation);
        let out_pub = derive_public_key(&receiver_derivation, 3, &spend_pub).unwrap();
        let one_time_secret = derive_secret_key(&receiver_derivation, 3, &spend);
        let one_time_secret = SecretKey::from_bytes(one_time_secret).unwrap();
        assert_eq!(public_key_from_secret(&one_time_secret), out_pub);
    }
}
