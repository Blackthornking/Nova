//! Nerva Rust engine migration: consensus constants and carefully isolated CryptoNote primitives.
//!
//! Rust migration layer for Nerva CryptoNote primitives. It parses canonical transaction prefixes,
//! decodes selected RingCT amount formats with commitment checks, and scans owned outputs, but it
//! is not yet a replacement for wallet2: range-proof/signature validation, key images/spent-output
//! detection, transaction construction/signing and legacy wallet-file import remain unported.

pub mod account;
pub mod address;
pub mod amount;
pub mod base58;
pub mod crypto;
pub mod mnemonic;
pub mod ringct;
pub mod scanner;
pub mod tx_extra;
pub mod tx_prefix;
pub mod varint;

pub mod consensus {
    /// Nerva uses 10^12 atomic units per XNV (CRYPTONOTE_DISPLAY_DECIMAL_POINT).
    pub const DECIMAL_PLACES: u32 = 12;
    pub const ATOMIC_UNITS_PER_XNV: u64 = 1_000_000_000_000;
    /// Mainnet prefixes copied from the upstream Nerva source's cryptonote_config.h.
    pub const PUBLIC_ADDRESS_PREFIX: u64 = 0x3800;
    pub const INTEGRATED_ADDRESS_PREFIX: u64 = 0x7081;
    pub const SUBADDRESS_PREFIX: u64 = 0x1080;
}
