//! Parallel CryptoNote address output scanner with per-transaction-key derivation reuse.
//!
//! Callers must decode the canonical Nerva transaction format first and provide the correct
//! tx-public-key slot per output. Unknown/malformed keys fail closed instead of being skipped.
use rayon::prelude::*;
use thiserror::Error;
use crate::{
    address::{Address, AddressKind},
    crypto::{decode_public_key, derive_public_key_from_point, generate_key_derivation, multiply_public_key, public_key_from_secret, CryptoError, KeyDerivation, SecretKey},
    tx_extra::TxExtraError,
    tx_prefix::{OutputTarget, ParsedTxPrefix},
};

#[derive(Debug, Clone, Copy)]
pub struct ScanOutput {
    pub output_index: u64,
    /// Index into `transaction_public_keys`. Nerva's additional tx public keys must be mapped
    /// by the upstream transaction-extra parser before invoking this scanner.
    pub tx_public_key_slot: usize,
    pub output_public_key: [u8; 32],
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OwnedOutput { pub output_index: u64, pub tx_public_key_slot: usize }

/// An output found in a canonical transaction prefix whose amount was transparently available
/// or whose RingCT amount was recovered and matched to the output commitment.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OwnedOutputAmount {
    pub output_index: u64,
    pub tx_public_key_slot: usize,
    pub amount: u64,
    pub ringct_type: crate::ringct::RingCtType,
}

#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum ScanError {
    #[error("provided view secret key does not match the address")]
    ViewKeyMismatch,
    #[error("output references missing transaction public key slot {0}")]
    MissingPublicKeySlot(usize),
    #[error("CryptoNote derivation error: {0}")]
    Crypto(String),
}

#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum TransactionScanError {
    #[error("transaction extra could not be parsed: {0}")]
    Extra(#[from] TxExtraError),
    #[error("transaction scanner failed: {0}")]
    Scan(#[from] ScanError),
    #[error("transaction decoding failed: {0}")]
    Transaction(#[from] crate::ringct::TransactionError),
    #[error("RingCT amount could not be verified: {0}")]
    RingCt(#[from] crate::ringct::RingCtError),
    #[error("scanned output index is outside the parsed transaction")]
    OutputIndex,
}
impl From<CryptoError> for ScanError { fn from(e: CryptoError) -> Self { Self::Crypto(e.to_string()) } }

pub struct AddressScanner { spend_point: curve25519_dalek::edwards::EdwardsPoint, view_secret: SecretKey }
/// Backwards-compatible name retained for callers that only scan the primary address.
pub type PrimaryAddressScanner = AddressScanner;

impl AddressScanner {
    pub fn new(address: &Address, view_secret: SecretKey) -> Result<Self, ScanError> {
        // For subaddresses, the tx-extra parser must map the corresponding tx public key slot.
        // The derivation equation is the same; the subaddress has its own spend public key D.
        let derived_view = match address.kind {
            AddressKind::Standard | AddressKind::Integrated => public_key_from_secret(&view_secret),
            AddressKind::Subaddress => multiply_public_key(&address.spend_public_key, &view_secret)?,
        };
        if derived_view != address.view_public_key { return Err(ScanError::ViewKeyMismatch); }
        Ok(Self { spend_point: decode_public_key(&address.spend_public_key)?, view_secret })
    }

    /// Parse a full serialized transaction, match owned outputs, recover their RingCT amounts,
    /// and verify each recovered amount/mask against the serialized Pedersen commitment.
    /// Range-proof and transaction-signature verification, key-image spend detection, and block
    /// consensus validation remain separate release gates.
    pub fn scan_transaction(&self, blob: &[u8]) -> Result<Vec<OwnedOutputAmount>, TransactionScanError> {
        let tx = crate::ringct::parse_transaction(blob)?;
        self.scan_parsed_transaction(&tx)
    }

    /// Scan an already decoded transaction so wallet orchestration can reuse its parsed key images
    /// and transaction-extra fields without decoding the same blob twice.
    pub fn scan_parsed_transaction(&self, tx: &crate::ringct::ParsedTransaction) -> Result<Vec<OwnedOutputAmount>, TransactionScanError> {
        let owned = self.scan_transaction_prefix(&tx.prefix)?;
        if owned.is_empty() { return Ok(Vec::new()); }
        let tx_keys = tx.prefix.parsed_extra()?.tx_public_keys_for_outputs(tx.prefix.outputs.len())?;
        let mut found = Vec::with_capacity(owned.len());
        for output in owned {
            let index = usize::try_from(output.output_index).map_err(|_| TransactionScanError::OutputIndex)?;
            let parsed_output = tx.prefix.outputs.get(index).ok_or(TransactionScanError::OutputIndex)?;
            let tx_public_key = tx_keys.get(output.tx_public_key_slot).ok_or(ScanError::MissingPublicKeySlot(output.tx_public_key_slot))?;
            let derivation = generate_key_derivation(tx_public_key, &self.view_secret).map_err(ScanError::from)?;
            let scalar = crate::crypto::derivation_scalar_bytes(&derivation, output.output_index);
            let amount = tx.ringct.recover_amount(index, parsed_output.amount, &scalar)?;
            found.push(OwnedOutputAmount {
                output_index: output.output_index,
                tx_public_key_slot: output.tx_public_key_slot,
                amount,
                ringct_type: tx.ringct.rct_type,
            });
        }
        Ok(found)
    }

    /// Parse a decoded transaction prefix's tx-extra and scan each standard `to_key` output.
    pub fn scan_transaction_prefix(&self, prefix: &ParsedTxPrefix) -> Result<Vec<OwnedOutput>, TransactionScanError> {
        let extra = prefix.parsed_extra()?;
        let primary = extra.primary_public_keys();
        let additional = extra.additional_public_keys();
        if !prefix.outputs.is_empty() && primary.is_empty() {
            return Err(TxExtraError::MissingPublicKey.into());
        }
        if !additional.is_empty() && additional.len() != prefix.outputs.len() {
            return Err(TxExtraError::AdditionalKeyCountMismatch.into());
        }
        if additional.is_empty() && primary.len() > 1 && primary.len() != prefix.outputs.len() {
            return Err(TxExtraError::PrimaryKeyCountMismatch.into());
        }
        let tx_keys: Vec<[u8; 32]> = if !additional.is_empty() { additional }
            else if primary.len() == prefix.outputs.len() && primary.len() > 1 { primary }
            else { primary.into_iter().take(1).collect() };
        if tx_keys.is_empty() { return Ok(Vec::new()); }
        let mut candidates = Vec::new();
        for (index, output) in prefix.outputs.iter().enumerate() {
            if let OutputTarget::ToKey(public_key) = &output.target {
                candidates.push(ScanOutput {
                    output_index: index as u64,
                    tx_public_key_slot: if tx_keys.len() == prefix.outputs.len() && tx_keys.len() > 1 { index } else { 0 },
                    output_public_key: *public_key,
                });
            }
        }
        Ok(self.scan(&tx_keys, &candidates)?)
    }

    /// Scan outputs with Rayon. Derivations are computed once per unique tx public key slot,
    /// avoiding repeated curve scalar multiplication for every output in the same transaction.
    pub fn scan(&self, transaction_public_keys: &[[u8;32]], outputs: &[ScanOutput]) -> Result<Vec<OwnedOutput>, ScanError> {
        if outputs.is_empty() { return Ok(Vec::new()); }
        for output in outputs {
            if output.tx_public_key_slot >= transaction_public_keys.len() { return Err(ScanError::MissingPublicKeySlot(output.tx_public_key_slot)); }
        }
        let mut slots: Vec<usize> = outputs.iter().map(|o| o.tx_public_key_slot).collect();
        slots.sort_unstable(); slots.dedup();
        let computed: Vec<(usize, Result<KeyDerivation, CryptoError>)> = slots.par_iter().map(|&slot| (slot, generate_key_derivation(&transaction_public_keys[slot], &self.view_secret))).collect();
        let mut derivations = vec![None; transaction_public_keys.len()];
        for (slot, derivation) in computed { derivations[slot] = Some(derivation.map_err(ScanError::from)?); }
        let matched: Vec<Result<Option<OwnedOutput>, ScanError>> = outputs.par_iter().map(|out| {
            let derivation = derivations[out.tx_public_key_slot].as_ref().expect("all referenced slots precomputed");
            let expected = derive_public_key_from_point(derivation, out.output_index, &self.spend_point);
            Ok((expected == out.output_public_key).then_some(OwnedOutput{ output_index:out.output_index, tx_public_key_slot:out.tx_public_key_slot }))
        }).collect();
        let mut owned = Vec::new();
        for item in matched { if let Some(output) = item? { owned.push(output); } }
        owned.sort_by_key(|o| (o.tx_public_key_slot, o.output_index));
        Ok(owned)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{address::{Address, AddressKind}, consensus, crypto::{derive_public_key, generate_key_derivation, public_key_from_secret, SecretKey}};
    fn sk(n:u8)->SecretKey { let mut b=[0u8;32]; b[0]=n; SecretKey::from_bytes(b).unwrap() }

    #[test]
    fn finds_owned_output_and_skips_non_owned_output() {
        let spend=sk(7); let view=sk(11); let tx_secret=sk(13); let unrelated_secret=sk(17);
        let address=Address{kind:AddressKind::Standard,prefix:consensus::PUBLIC_ADDRESS_PREFIX,spend_public_key:public_key_from_secret(&spend),view_public_key:public_key_from_secret(&view),payment_id:None};
        let tx_pub=public_key_from_secret(&tx_secret);
        let derivation=generate_key_derivation(&tx_pub,&view).unwrap();
        let owned_key=derive_public_key(&derivation,2,&address.spend_public_key).unwrap();
        let unrelated_key=public_key_from_secret(&unrelated_secret);
        let scanner=AddressScanner::new(&address,view).unwrap();
        let found=scanner.scan(&[tx_pub],&[
            ScanOutput{output_index:0,tx_public_key_slot:0,output_public_key:unrelated_key},
            ScanOutput{output_index:2,tx_public_key_slot:0,output_public_key:owned_key},
        ]).unwrap();
        assert_eq!(found,vec![OwnedOutput{output_index:2,tx_public_key_slot:0}]);
    }

    #[test]
    fn scans_subaddress_when_correct_tx_public_key_slot_is_provided() {
        let spend=sk(7); let view=sk(11); let tx_secret=sk(13);
        let primary=Address::from_secret_keys(&spend,&view);
        let sub=Address::derive_subaddress(&primary,&spend,&view,1,4).unwrap();
        let tx_pub=crate::crypto::multiply_public_key(&sub.spend_public_key,&tx_secret).unwrap();
        let derivation=generate_key_derivation(&tx_pub,&view).unwrap();
        let output_key=derive_public_key(&derivation,5,&sub.spend_public_key).unwrap();
        assert_eq!(sub.kind,AddressKind::Subaddress);
        let scanner=AddressScanner::new(&sub,view).unwrap();
        let found=scanner.scan(&[tx_pub],&[ScanOutput{output_index:5,tx_public_key_slot:0,output_public_key:output_key}]).unwrap();
        assert_eq!(found,vec![OwnedOutput{output_index:5,tx_public_key_slot:0}]);
    }

    #[test]
    fn rejects_view_secret_that_does_not_match_address() {
        let spend=sk(7); let view=sk(11); let wrong=sk(12);
        let address=Address::from_secret_keys(&spend,&view);
        assert_eq!(AddressScanner::new(&address,wrong).err(),Some(ScanError::ViewKeyMismatch));
    }

    #[test]
    fn scans_outputs_from_canonical_transaction_prefix_and_extra() {
        use crate::{tx_prefix::{parse_transaction_prefix, OutputTarget}, varint};
        let spend=sk(7); let view=sk(11); let tx_secret=sk(13);
        let address=Address::from_secret_keys(&spend,&view);
        let tx_pub=public_key_from_secret(&tx_secret);
        let derivation=generate_key_derivation(&tx_pub,&view).unwrap();
        let owned_key=derive_public_key(&derivation,1,&address.spend_public_key).unwrap();
        let mut blob=Vec::new();
        blob.extend(varint::encode(2)); blob.extend(varint::encode(0));
        blob.extend(varint::encode(1)); blob.push(0xff); blob.extend(varint::encode(100));
        blob.extend(varint::encode(2));
        blob.extend(varint::encode(0)); blob.push(2); blob.extend_from_slice(&[0x77;32]);
        blob.extend(varint::encode(0)); blob.push(2); blob.extend_from_slice(&owned_key);
        let mut extra=vec![1]; extra.extend_from_slice(&tx_pub);
        blob.extend(varint::encode(extra.len() as u64)); blob.extend(extra);
        // Two suffix bytes stand in for opaque version-2 RingCT bytes.
        blob.extend_from_slice(&[0xaa,0xbb]);
        let parsed=parse_transaction_prefix(&blob).unwrap();
        assert_eq!(parsed.outputs[0].target,OutputTarget::ToKey([0x77;32]));
        let scanner=AddressScanner::new(&address,view).unwrap();
        assert_eq!(scanner.scan_transaction_prefix(&parsed).unwrap(),vec![OwnedOutput{output_index:1,tx_public_key_slot:0}]);
    }

    #[test]
    fn scans_full_transparent_transaction_and_returns_amount() {
        use crate::{tx_prefix::parse_transaction_prefix, varint};
        let spend=sk(7); let view=sk(11); let tx_secret=sk(13);
        let address=Address::from_secret_keys(&spend,&view);
        let tx_pub=public_key_from_secret(&tx_secret);
        let derivation=generate_key_derivation(&tx_pub,&view).unwrap();
        let owned_key=derive_public_key(&derivation,1,&address.spend_public_key).unwrap();
        let mut blob=Vec::new();
        blob.extend(varint::encode(2)); blob.extend(varint::encode(0));
        blob.extend(varint::encode(1)); blob.push(0xff); blob.extend(varint::encode(100));
        blob.extend(varint::encode(2));
        blob.extend(varint::encode(0)); blob.push(2); blob.extend_from_slice(&[0x77;32]);
        blob.extend(varint::encode(42)); blob.push(2); blob.extend_from_slice(&owned_key);
        let mut extra=vec![1]; extra.extend_from_slice(&tx_pub);
        blob.extend(varint::encode(extra.len() as u64)); blob.extend(extra);
        // Nerva RCTTypeNull: transparent output amounts, followed by an opaque legacy-signature byte.
        blob.push(0); blob.push(0xaa);
        let prefix=parse_transaction_prefix(&blob).unwrap();
        assert_eq!(prefix.outputs[1].amount,42);
        let scanner=AddressScanner::new(&address,view).unwrap();
        assert_eq!(scanner.scan_transaction(&blob).unwrap(),vec![OwnedOutputAmount {
            output_index:1, tx_public_key_slot:0, amount:42, ringct_type:crate::ringct::RingCtType::Null,
        }]);
    }

    #[test]
    fn missing_public_key_slot_fails_closed() {
        let spend=sk(7); let view=sk(11);
        let address=Address{kind:AddressKind::Standard,prefix:consensus::PUBLIC_ADDRESS_PREFIX,spend_public_key:public_key_from_secret(&spend),view_public_key:public_key_from_secret(&view),payment_id:None};
        let scanner=AddressScanner::new(&address,view).unwrap();
        assert_eq!(scanner.scan(&[],&[ScanOutput{output_index:0,tx_public_key_slot:0,output_public_key:[0;32]}]),Err(ScanError::MissingPublicKeySlot(0)));
    }
}
