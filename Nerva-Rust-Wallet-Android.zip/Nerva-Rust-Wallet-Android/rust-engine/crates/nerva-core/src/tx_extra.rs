//! Bounded parser for Nerva/CryptoNote transaction-extra fields.
//!
//! Wire tags and field encoding follow Nerva's `src/cryptonote_basic/tx_extra.h`.
//! Unknown tags, malformed lengths and truncated keys fail closed.
use thiserror::Error;
use crate::varint;

pub const MAX_TX_EXTRA_BYTES: usize = 1_048_576;
const MAX_NONCE_BYTES: usize = 255;
const MAX_ADDITIONAL_KEYS: usize = 16_384;
const TAG_PADDING: u8 = 0x00;
const TAG_PUBLIC_KEY: u8 = 0x01;
const TAG_NONCE: u8 = 0x02;
const TAG_MERGE_MINING: u8 = 0x03;
const TAG_ADDITIONAL_KEYS: u8 = 0x04;
const TAG_MINERGATE: u8 = 0xde;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TxExtraField {
    Padding { bytes: usize },
    PublicKey([u8; 32]),
    Nonce(Vec<u8>),
    MergeMining(Vec<u8>),
    AdditionalPublicKeys(Vec<[u8; 32]>),
    MinerGate(Vec<u8>),
}

#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum TxExtraError {
    #[error("transaction extra exceeds the configured limit")]
    TooLarge,
    #[error("transaction extra is truncated at byte {0}")]
    Truncated(usize),
    #[error("transaction extra contains a non-canonical or invalid varint at byte {0}")]
    InvalidVarint(usize),
    #[error("transaction extra contains unknown tag 0x{tag:02x} at byte {offset}")]
    UnknownTag { tag: u8, offset: usize },
    #[error("transaction extra padding exceeds Nerva's 255-byte limit")]
    PaddingTooLong,
    #[error("transaction extra nonce exceeds 255 bytes")]
    NonceTooLong,
    #[error("transaction extra has too many additional public keys")]
    TooManyKeys,
    #[error("transaction extra length arithmetic overflow")]
    LengthOverflow,
    #[error("transaction does not contain a transaction public key")]
    MissingPublicKey,
    #[error("additional transaction public key count does not match transaction output count")]
    AdditionalKeyCountMismatch,
    #[error("multiple primary transaction public keys do not map unambiguously to the transaction outputs")]
    PrimaryKeyCountMismatch,
}

#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct ParsedTxExtra {
    pub fields: Vec<TxExtraField>,
}

impl ParsedTxExtra {
    pub fn parse(data: &[u8]) -> Result<Self, TxExtraError> {
        if data.len() > MAX_TX_EXTRA_BYTES { return Err(TxExtraError::TooLarge); }
        let mut pos = 0usize;
        let mut fields = Vec::new();
        while pos < data.len() {
            let tag_offset = pos;
            let tag = data[pos];
            pos += 1;
            match tag {
                TAG_PADDING => {
                    let mut count = 1usize;
                    while pos < data.len() && data[pos] == 0 && count < 256 {
                        count += 1;
                        pos += 1;
                    }
                    if count > 255 { return Err(TxExtraError::PaddingTooLong); }
                    fields.push(TxExtraField::Padding { bytes: count });
                }
                TAG_PUBLIC_KEY => {
                    let bytes = take(data, &mut pos, 32)?;
                    let mut key = [0u8; 32]; key.copy_from_slice(bytes);
                    fields.push(TxExtraField::PublicKey(key));
                }
                TAG_NONCE => {
                    let bytes = read_sized(data, &mut pos, MAX_NONCE_BYTES)?;
                    fields.push(TxExtraField::Nonce(bytes.to_vec()));
                }
                TAG_MERGE_MINING => {
                    let bytes = read_sized(data, &mut pos, MAX_TX_EXTRA_BYTES)?;
                    fields.push(TxExtraField::MergeMining(bytes.to_vec()));
                }
                TAG_ADDITIONAL_KEYS => {
                    let count = read_varint(data, &mut pos)?;
                    let count = usize::try_from(count).map_err(|_| TxExtraError::LengthOverflow)?;
                    if count > MAX_ADDITIONAL_KEYS { return Err(TxExtraError::TooManyKeys); }
                    let bytes_len = count.checked_mul(32).ok_or(TxExtraError::LengthOverflow)?;
                    let bytes = take(data, &mut pos, bytes_len)?;
                    let mut keys = Vec::with_capacity(count);
                    for chunk in bytes.chunks_exact(32) {
                        let mut key = [0u8; 32]; key.copy_from_slice(chunk); keys.push(key);
                    }
                    fields.push(TxExtraField::AdditionalPublicKeys(keys));
                }
                TAG_MINERGATE => {
                    let bytes = read_sized(data, &mut pos, MAX_TX_EXTRA_BYTES)?;
                    fields.push(TxExtraField::MinerGate(bytes.to_vec()));
                }
                _ => return Err(TxExtraError::UnknownTag { tag, offset: tag_offset }),
            }
        }
        Ok(Self { fields })
    }

    /// Return every tag-0x01 tx public key in field order. Nerva's reference helper
    /// supports repeated public-key fields; callers must not silently discard them.
    pub fn primary_public_keys(&self) -> Vec<[u8; 32]> {
        self.fields.iter().filter_map(|f| match f { TxExtraField::PublicKey(k) => Some(*k), _ => None }).collect()
    }

    /// Return the first additional-public-key field, matching the reference wallet's
    /// usual lookup behavior. A missing field is represented by an empty vector.
    pub fn additional_public_keys(&self) -> Vec<[u8; 32]> {
        self.fields.iter().find_map(|f| match f { TxExtraField::AdditionalPublicKeys(keys) => Some(keys.clone()), _ => None }).unwrap_or_default()
    }

    pub fn tx_public_keys_for_outputs(&self, output_count: usize) -> Result<Vec<[u8; 32]>, TxExtraError> {
        let primary = self.primary_public_keys();
        if primary.is_empty() {
            return if output_count == 0 { Ok(Vec::new()) } else { Err(TxExtraError::MissingPublicKey) };
        }
        let additional = self.additional_public_keys();
        if !additional.is_empty() {
            if additional.len() != output_count { return Err(TxExtraError::AdditionalKeyCountMismatch); }
            return Ok(additional);
        }
        if primary.len() > 1 && primary.len() != output_count { return Err(TxExtraError::PrimaryKeyCountMismatch); }
        if primary.len() == output_count && primary.len() > 1 { Ok(primary) }
        else { Ok(primary.into_iter().take(1).collect()) }
    }
}

fn take<'a>(data: &'a [u8], pos: &mut usize, len: usize) -> Result<&'a [u8], TxExtraError> {
    let end = pos.checked_add(len).ok_or(TxExtraError::LengthOverflow)?;
    if end > data.len() { return Err(TxExtraError::Truncated(*pos)); }
    let slice = &data[*pos..end]; *pos = end; Ok(slice)
}
fn read_varint(data: &[u8], pos: &mut usize) -> Result<u64, TxExtraError> {
    let start = *pos;
    let (value, used) = varint::decode(&data[start..]).map_err(|_| TxExtraError::InvalidVarint(start))?;
    *pos = (*pos).checked_add(used).ok_or(TxExtraError::LengthOverflow)?;
    Ok(value)
}
fn read_sized<'a>(data: &'a [u8], pos: &mut usize, limit: usize) -> Result<&'a [u8], TxExtraError> {
    let len = usize::try_from(read_varint(data, pos)?).map_err(|_| TxExtraError::LengthOverflow)?;
    if len > limit {
        return if limit == MAX_NONCE_BYTES { Err(TxExtraError::NonceTooLong) } else { Err(TxExtraError::TooLarge) };
    }
    take(data, pos, len)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::varint;

    fn sized(tag: u8, bytes: &[u8]) -> Vec<u8> { let mut v = vec![tag]; v.extend(varint::encode(bytes.len() as u64)); v.extend_from_slice(bytes); v }

    #[test]
    fn parses_public_key_nonce_additional_keys_and_padding() {
        let primary = [0x11; 32]; let additional = [[0x22; 32], [0x33; 32]];
        let mut raw = vec![TAG_PUBLIC_KEY]; raw.extend_from_slice(&primary);
        raw.extend(sized(TAG_NONCE, &[1, 2, 3]));
        raw.push(TAG_ADDITIONAL_KEYS); raw.extend(varint::encode(2));
        raw.extend_from_slice(&additional[0]); raw.extend_from_slice(&additional[1]);
        raw.extend_from_slice(&[0, 0, 0]);
        let parsed = ParsedTxExtra::parse(&raw).unwrap();
        assert_eq!(parsed.primary_public_keys(), vec![primary]);
        assert_eq!(parsed.additional_public_keys(), additional);
        assert_eq!(parsed.tx_public_keys_for_outputs(2).unwrap(), additional);
    }

    #[test]
    fn malformed_extra_fails_closed() {
        assert!(matches!(ParsedTxExtra::parse(&[TAG_PUBLIC_KEY, 1, 2]), Err(TxExtraError::Truncated(_))));
        assert!(matches!(ParsedTxExtra::parse(&[0x7f]), Err(TxExtraError::UnknownTag { .. })));
        assert_eq!(ParsedTxExtra::parse(&[TAG_ADDITIONAL_KEYS, 2, 1]), Err(TxExtraError::Truncated(2)));
        assert_eq!(ParsedTxExtra::parse(&[0; 256]), Err(TxExtraError::PaddingTooLong));
    }

    #[test]
    fn missing_or_mismatched_key_material_is_rejected() {
        assert_eq!(ParsedTxExtra::parse(&[]).unwrap().tx_public_keys_for_outputs(0), Ok(Vec::new()));
        let mut raw = vec![TAG_PUBLIC_KEY]; raw.extend_from_slice(&[1; 32]);
        raw.push(TAG_ADDITIONAL_KEYS); raw.extend(varint::encode(1)); raw.extend_from_slice(&[2; 32]);
        assert_eq!(ParsedTxExtra::parse(&raw).unwrap().tx_public_keys_for_outputs(2), Err(TxExtraError::AdditionalKeyCountMismatch));
    }
}
