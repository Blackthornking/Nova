//! Bounded decoder for the canonical Nerva transaction-prefix serialization.
//!
//! It reads through `extra` and intentionally leaves RingCT/signature suffix bytes unparsed.
//! RingCT decoding is handled by `ringct`; prefix parsing exposes key images for spend detection.
use thiserror::Error;
use crate::{tx_extra::{ParsedTxExtra, TxExtraError}, varint};

pub const MAX_TRANSACTION_BYTES: usize = 16 * 1024 * 1024;
const MAX_COLLECTION_ITEMS: usize = 100_000;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum OutputTarget {
    ToKey([u8; 32]),
    Script,
    ScriptHash([u8; 32]),
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TxOutput { pub amount: u64, pub target: OutputTarget }

/// Transaction input metadata exposed by the prefix parser. Script-era input bodies are skipped
/// safely; modern key inputs preserve relative offsets and the key image for spend detection.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TxInput {
    Generation { height: u64 },
    ToKey { amount: u64, relative_offsets: Vec<u64>, key_image: [u8; 32] },
    LegacyScript { tag: u8 },
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ParsedTxPrefix {
    pub version: u64,
    pub unlock_time: u64,
    pub input_count: usize,
    pub inputs: Vec<TxInput>,
    pub outputs: Vec<TxOutput>,
    pub extra: Vec<u8>,
    pub prefix_bytes: usize,
}
impl ParsedTxPrefix {
    pub fn parsed_extra(&self) -> Result<ParsedTxExtra, TxExtraError> { ParsedTxExtra::parse(&self.extra) }
}
#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum TxPrefixError {
    #[error("transaction blob exceeds the configured limit")]
    TooLarge,
    #[error("transaction prefix is truncated at byte {0}")]
    Truncated(usize),
    #[error("transaction prefix has an invalid varint at byte {0}")]
    InvalidVarint(usize),
    #[error("unsupported transaction version {0}")]
    UnsupportedVersion(u64),
    #[error("unknown input target tag 0x{tag:02x} at byte {offset}")]
    UnknownInputTag { tag: u8, offset: usize },
    #[error("unknown output target tag 0x{tag:02x} at byte {offset}")]
    UnknownOutputTag { tag: u8, offset: usize },
    #[error("transaction collection exceeds safe limits")]
    CollectionTooLarge,
    #[error("transaction length arithmetic overflow")]
    LengthOverflow,
}

pub fn parse_transaction_prefix(blob: &[u8]) -> Result<ParsedTxPrefix, TxPrefixError> {
    if blob.len() > MAX_TRANSACTION_BYTES { return Err(TxPrefixError::TooLarge); }
    let mut r = Reader { bytes: blob, pos: 0 };
    let version = r.varint()?;
    // Nerva's transaction_prefix serialization accepts versions 1..=TRANSACTION_VERSION_V2.
    if version != 1 && version != 2 { return Err(TxPrefixError::UnsupportedVersion(version)); }
    let unlock_time = r.varint()?;
    let input_count = r.count()?;
    let mut inputs = Vec::with_capacity(input_count);
    for _ in 0..input_count { inputs.push(r.read_input()?); }
    let output_count = r.count()?;
    let mut outputs = Vec::with_capacity(output_count);
    for _ in 0..output_count {
        let amount = r.varint()?;
        let target_offset = r.pos;
        let tag = r.byte()?;
        let target = match tag {
            0 => { r.skip_key_vector()?; r.skip_byte_vector()?; OutputTarget::Script }
            1 => { let mut hash = [0u8; 32]; hash.copy_from_slice(r.take(32)?); OutputTarget::ScriptHash(hash) }
            2 => { let mut key = [0u8; 32]; key.copy_from_slice(r.take(32)?); OutputTarget::ToKey(key) }
            _ => return Err(TxPrefixError::UnknownOutputTag { tag, offset: target_offset }),
        };
        outputs.push(TxOutput { amount, target });
    }
    let extra = r.read_byte_vector()?.to_vec();
    Ok(ParsedTxPrefix { version, unlock_time, input_count, inputs, outputs, extra, prefix_bytes: r.pos })
}

struct Reader<'a> { bytes: &'a [u8], pos: usize }
impl<'a> Reader<'a> {
    fn byte(&mut self) -> Result<u8, TxPrefixError> { Ok(self.take(1)?[0]) }
    fn take(&mut self, len: usize) -> Result<&'a [u8], TxPrefixError> {
        let end = self.pos.checked_add(len).ok_or(TxPrefixError::LengthOverflow)?;
        if end > self.bytes.len() { return Err(TxPrefixError::Truncated(self.pos)); }
        let out = &self.bytes[self.pos..end]; self.pos = end; Ok(out)
    }
    fn varint(&mut self) -> Result<u64, TxPrefixError> {
        let start = self.pos;
        let (v, n) = varint::decode(&self.bytes[start..]).map_err(|_| TxPrefixError::InvalidVarint(start))?;
        self.pos = self.pos.checked_add(n).ok_or(TxPrefixError::LengthOverflow)?;
        Ok(v)
    }
    fn count(&mut self) -> Result<usize, TxPrefixError> {
        let count = usize::try_from(self.varint()?).map_err(|_| TxPrefixError::CollectionTooLarge)?;
        if count > MAX_COLLECTION_ITEMS { Err(TxPrefixError::CollectionTooLarge) } else { Ok(count) }
    }
    fn skip_byte_vector(&mut self) -> Result<(), TxPrefixError> { let n = self.count()?; self.take(n)?; Ok(()) }
    fn read_byte_vector(&mut self) -> Result<&'a [u8], TxPrefixError> {
        let n = usize::try_from(self.varint()?).map_err(|_| TxPrefixError::CollectionTooLarge)?;
        if n > crate::tx_extra::MAX_TX_EXTRA_BYTES { return Err(TxPrefixError::CollectionTooLarge); }
        self.take(n)
    }
    fn skip_key_vector(&mut self) -> Result<(), TxPrefixError> {
        let n = self.count()?; let bytes = n.checked_mul(32).ok_or(TxPrefixError::LengthOverflow)?; self.take(bytes)?; Ok(())
    }
    fn read_input(&mut self) -> Result<TxInput, TxPrefixError> {
        let tag_offset = self.pos;
        let tag = self.byte()?;
        match tag {
            0xff => Ok(TxInput::Generation { height: self.varint()? }),
            0x00 => {
                // Historical script input. The parser does not validate script semantics, but
                // it consumes the exact serialized body with bounded vectors.
                self.take(32)?; self.varint()?; self.skip_byte_vector()?;
                Ok(TxInput::LegacyScript { tag })
            }
            0x01 => {
                self.take(32)?; self.varint()?; self.skip_key_vector()?; self.skip_byte_vector()?; self.skip_byte_vector()?;
                Ok(TxInput::LegacyScript { tag })
            }
            0x02 => {
                let amount = self.varint()?;
                let count = self.count()?;
                let mut relative_offsets = Vec::with_capacity(count);
                for _ in 0..count { relative_offsets.push(self.varint()?); }
                let mut key_image = [0u8; 32]; key_image.copy_from_slice(self.take(32)?);
                Ok(TxInput::ToKey { amount, relative_offsets, key_image })
            }
            _ => Err(TxPrefixError::UnknownInputTag { tag, offset: tag_offset }),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{tx_extra::ParsedTxExtra, varint};

    fn v(n: u64, out: &mut Vec<u8>) { out.extend(varint::encode(n)); }
    fn simple_tx() -> Vec<u8> {
        let mut b=Vec::new(); v(2,&mut b); v(0,&mut b); // version, unlock time
        v(1,&mut b); b.push(0xff); v(123,&mut b); // one generation input
        v(2,&mut b); // two outputs
        v(0,&mut b); b.push(2); b.extend_from_slice(&[0x21;32]);
        v(0,&mut b); b.push(2); b.extend_from_slice(&[0x22;32]);
        let mut extra=vec![1]; extra.extend_from_slice(&[0x44;32]); v(extra.len() as u64,&mut b); b.extend(extra);
        b.extend_from_slice(&[0xaa,0xbb]); // trailing RingCT/signature data deliberately ignored
        b
    }
    #[test]
    fn parses_prefix_and_stops_before_ringct_suffix() {
        let raw=simple_tx(); let p=parse_transaction_prefix(&raw).unwrap();
        assert_eq!(p.version,2); assert_eq!(p.input_count,1); assert_eq!(p.outputs.len(),2);
        assert_eq!(p.inputs, vec![TxInput::Generation { height: 123 }]);
        assert_eq!(p.prefix_bytes,raw.len()-2);
        assert_eq!(p.outputs[0].target,OutputTarget::ToKey([0x21;32]));
        assert_eq!(p.parsed_extra().unwrap().primary_public_keys(),vec![[0x44;32]]);
    }
    #[test]
    fn parses_key_images_for_spend_detection() {
        let mut b=Vec::new(); v(2,&mut b); v(0,&mut b);
        v(1,&mut b); b.push(2); v(0,&mut b); // key input amount
        v(2,&mut b); v(4,&mut b); v(3,&mut b); // two relative offsets
        b.extend_from_slice(&[0x91;32]); // key image
        v(0,&mut b); // outputs
        v(0,&mut b); // extra
        b.extend_from_slice(&[7;4]); // opaque RingCT/signature bytes
        let parsed=parse_transaction_prefix(&b).unwrap();
        assert_eq!(parsed.inputs, vec![TxInput::ToKey { amount: 0, relative_offsets: vec![4,3], key_image: [0x91;32] }]);
    }

    #[test]
    fn rejects_truncation_unknown_tags_and_version() {
        assert!(matches!(parse_transaction_prefix(&[2]),Err(TxPrefixError::InvalidVarint(1)) | Err(TxPrefixError::Truncated(_))));
        let mut bad=simple_tx(); bad[0]=3; assert_eq!(parse_transaction_prefix(&bad),Err(TxPrefixError::UnsupportedVersion(3)));
        let mut bad=simple_tx(); // replace first output target tag
        bad[7]=0x77; assert!(matches!(parse_transaction_prefix(&bad), Err(TxPrefixError::UnknownOutputTag { .. })));
    }
    #[test]
    fn prefix_parser_does_not_claim_to_decrypt_ringct_amounts() {
        assert!(matches!(&parse_transaction_prefix(&simple_tx()).unwrap().outputs[0].target,OutputTarget::ToKey(_)));
        let _ = ParsedTxExtra::parse(&[1].into_iter().chain([0x44;32]).collect::<Vec<_>>()).unwrap();
    }
}
