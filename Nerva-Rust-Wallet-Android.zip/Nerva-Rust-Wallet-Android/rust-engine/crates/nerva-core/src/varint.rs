//! CryptoNote's unsigned LEB128-style varint encoding.
use thiserror::Error;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Error)]
pub enum VarintError {
    #[error("truncated varint")]
    Truncated,
    #[error("varint exceeds u64")]
    Overflow,
    #[error("non-canonical varint")]
    NonCanonical,
}

pub fn encode(mut value: u64) -> Vec<u8> {
    let mut out = Vec::with_capacity(10);
    while value >= 0x80 {
        out.push((value as u8) | 0x80);
        value >>= 7;
    }
    out.push(value as u8);
    out
}

/// Decode one varint and return (value, bytes consumed). Rejects overflow and overlong forms.
pub fn decode(input: &[u8]) -> Result<(u64, usize), VarintError> {
    let mut value = 0u64;
    for (i, &byte) in input.iter().take(10).enumerate() {
        let part = (byte & 0x7f) as u64;
        let shift = (i * 7) as u32;
        if shift == 63 && part > 1 {
            return Err(VarintError::Overflow);
        }
        value |= part.checked_shl(shift).ok_or(VarintError::Overflow)?;
        if byte & 0x80 == 0 {
            if i > 0 && part == 0 {
                return Err(VarintError::NonCanonical);
            }
            return Ok((value, i + 1));
        }
    }
    if input.len() < 10 {
        Err(VarintError::Truncated)
    } else {
        Err(VarintError::Overflow)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrips_crypto_note_varints() {
        for n in [0, 1, 127, 128, 255, 16_384, u32::MAX as u64, u64::MAX] {
            let enc = encode(n);
            assert_eq!(decode(&enc), Ok((n, enc.len())));
        }
    }

    #[test]
    fn rejects_overflow_and_noncanonical_forms() {
        assert_eq!(decode(&[0x80]), Err(VarintError::Truncated));
        assert_eq!(decode(&[0x80, 0x00]), Err(VarintError::NonCanonical));
        assert_eq!(decode(&[0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x02]), Err(VarintError::Overflow));
    }
}
