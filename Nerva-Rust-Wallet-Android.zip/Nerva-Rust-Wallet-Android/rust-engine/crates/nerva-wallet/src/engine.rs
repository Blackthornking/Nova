//! High-level Rust wallet scan orchestration.
//!
//! This facade binds encrypted account storage, the core transaction scanner and persistent scan
//! state together. It deliberately does not broadcast or sign transactions. Before calling
//! `scan_transaction_metadata`, the caller must independently validate that the transaction is in
//! the indicated canonical block and that the block chain is authenticated; this module does not
//! verify block inclusion, range proofs or transaction signatures.
use crate::{
    scan_journal::{BlockRef, ReconcileReport},
    storage::{StorageError, UnlockedWallet, WalletFile},
    tracking::{BalanceSummary, Direction, OutputId, TrackingError, TransactionRecord, WalletScanState},
    EnginePhase,
};
use nerva_core::{
    account::AccountKeys,
    address::{Address, AddressError},
    crypto::{hash_to_scalar, CryptoError, SecretKey},
    mnemonic::encode_seed,
    scanner::{AddressScanner, OwnedOutputAmount, ScanError, TransactionScanError},
};
use std::path::Path;
use thiserror::Error;

#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum WalletEngineError {
    #[error("account key error: {0}")]
    Crypto(#[from] CryptoError),
    #[error("address encoding failed: {0}")]
    Address(#[from] AddressError),
    #[error("scanner setup failed: {0}")]
    ScannerSetup(#[from] ScanError),
    #[error("transaction scan failed: {0}")]
    TransactionScan(#[from] TransactionScanError),
    #[error("wallet scan tracking failed: {0}")]
    Tracking(#[from] TrackingError),
    #[error("wallet storage failed: {0}")]
    Storage(#[from] StorageError),
    #[error("output index cannot fit the persisted wallet format")]
    OutputIndex,
    #[error("scan completion height does not match the current canonical tip")]
    ScanNotAtTip,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ProcessedTransaction {
    pub txid: [u8; 32],
    pub block_height: u64,
    pub received_outputs: Vec<OwnedOutputAmount>,
    pub spent_outputs: Vec<OutputId>,
}

pub struct WalletEngine {
    wallet_name: String,
    restore_height: u64,
    address: Address,
    scanner: AddressScanner,
    spend_secret: Option<SecretKey>,
    seed_compatible: bool,
    scan_state: WalletScanState,
    phase: EnginePhase,
}

impl WalletEngine {
    pub fn from_account(account: AccountKeys, wallet_name: impl Into<String>, restore_height: u64) -> Result<Self, WalletEngineError> {
        // This duplication is short-lived and explicit. The consumed AccountKeys then zeroises its
        // original secret handles as it is dropped; the engine's copies are also zeroised on drop.
        let address = account.address().clone();
        let seed_compatible = hash_to_scalar(account.spend_secret().as_bytes()).to_bytes() == *account.view_secret().as_bytes();
        let view_secret = SecretKey::from_bytes(*account.view_secret().as_bytes())?;
        let spend_secret = SecretKey::from_bytes(*account.spend_secret().as_bytes())?;
        let scanner = AddressScanner::new(&address, view_secret)?;
        Ok(Self {
            wallet_name: wallet_name.into(), restore_height, address, scanner,
            spend_secret: Some(spend_secret), seed_compatible, scan_state: WalletScanState::default(), phase: EnginePhase::Opening,
        })
    }

    pub fn from_unlocked_wallet(wallet: UnlockedWallet, scan_state: WalletScanState) -> Result<Self, WalletEngineError> {
        let (wallet_name, restore_height, address, view_secret, spend_secret) = wallet.into_engine_parts();
        let seed_compatible = spend_secret.as_ref().is_some_and(|spend|
            hash_to_scalar(spend.as_bytes()).to_bytes() == *view_secret.as_bytes());
        let scanner = AddressScanner::new(&address, view_secret)?;
        Ok(Self { wallet_name, restore_height, address, scanner, spend_secret, seed_compatible, scan_state, phase: EnginePhase::Opening })
    }

    pub fn open_wallet(
        wallet_path: impl AsRef<Path>,
        scan_state_path: impl AsRef<Path>,
        password: &[u8],
    ) -> Result<Self, WalletEngineError> {
        let wallet = WalletFile::open_path(wallet_path, password)?;
        let scan_state = WalletScanState::load_or_default(scan_state_path)?;
        Self::from_unlocked_wallet(wallet, scan_state)
    }

    pub fn wallet_name(&self) -> &str { &self.wallet_name }
    pub fn restore_height(&self) -> u64 { self.restore_height }
    pub fn address(&self) -> &Address { &self.address }
    pub fn address_string(&self) -> Result<String, WalletEngineError> { Ok(self.address.encode()?) }
    pub fn is_watch_only(&self) -> bool { self.spend_secret.is_none() }
    pub fn phase(&self) -> &EnginePhase { &self.phase }
    pub fn scan_state(&self) -> &WalletScanState { &self.scan_state }
    pub fn balance_summary(&self) -> Result<BalanceSummary, WalletEngineError> { Ok(self.scan_state.balance_summary()?) }

    /// Return the canonical English recovery phrase only for a spend-capable account. The caller
    /// is responsible for an offline, explicitly-confirmed backup screen and must never log it.
    pub fn recovery_seed(&self) -> Option<String> {
        if !self.seed_compatible { return None; }
        self.spend_secret.as_ref().map(|secret| encode_seed(secret.as_bytes()))
    }

    /// Reconcile the scan checkpoint to a trusted canonical header window. This removes stale
    /// noncanonical records and resets spends whose transaction was removed by a reorg.
    pub fn reconcile_chain(&mut self, canonical: &[BlockRef]) -> Result<ReconcileReport, WalletEngineError> {
        let report = self.scan_state.reconcile_chain(canonical)?;
        if let (Some(first), Some(tip)) = (canonical.first(), canonical.last()) {
            self.phase = EnginePhase::Scanning { height: first.height, target_height: tip.height };
        } else {
            self.phase = EnginePhase::Opening;
        }
        Ok(report)
    }

    /// Scan one transaction that the caller has already associated with a canonical block.
    /// This extracts key images, scans for owned outputs, recovers receiver amounts and checks each
    /// recovered amount against its output commitment. It does NOT verify transaction inclusion,
    /// RingCT proofs or signatures; do not feed untrusted raw transactions into a balance display.
    pub fn scan_transaction_metadata(
        &mut self,
        txid: [u8; 32],
        block: &BlockRef,
        raw_transaction: &[u8],
    ) -> Result<ProcessedTransaction, WalletEngineError> {
        if !self.scan_state.journal().blocks().iter().any(|b| b.height == block.height && b.hash == block.hash) {
            return Err(TrackingError::UnknownBlock.into());
        }
        let parsed = nerva_core::ringct::parse_transaction(raw_transaction)
            .map_err(TransactionScanError::Transaction)?;
        let received_outputs = self.scanner.scan_parsed_transaction(&parsed)?;
        let mut records = Vec::with_capacity(received_outputs.len());
        let mut received_amount = 0u64;
        for output in &received_outputs {
            let output_index = u32::try_from(output.output_index).map_err(|_| WalletEngineError::OutputIndex)?;
            received_amount = received_amount.checked_add(output.amount).ok_or(TrackingError::AmountOverflow)?;
            records.push((OutputId { txid, output_index }, output.amount));
        }
        let matching_spends = self.scan_state.matching_spend_outputs(&txid, &parsed.prefix);
        let mut spent_amount = 0u64;
        for (_, amount) in &matching_spends {
            spent_amount = spent_amount.checked_add(*amount).ok_or(TrackingError::AmountOverflow)?;
        }
        let is_coinbase = parsed.prefix.inputs.iter().any(|input|
            matches!(input, nerva_core::tx_prefix::TxInput::Generation { .. }));
        let relevant = !records.is_empty() || !matching_spends.is_empty();
        if relevant { self.scan_state.can_record_transaction(&txid, block)?; }

        // Validate and insert incoming output records atomically before changing spend flags.
        self.scan_state.record_outputs(&records, block)?;
        let spent_outputs = self.scan_state.apply_spend_inputs(txid, &parsed.prefix);
        if relevant {
            let direction = match (is_coinbase, !records.is_empty(), !spent_outputs.is_empty()) {
                (true, true, _) => Direction::Coinbase,
                (_, true, true) => Direction::SelfTransfer,
                (_, true, false) => Direction::Incoming,
                (_, false, true) => Direction::Outgoing,
                (_, false, false) => unreachable!("relevance was derived from output or spend records"),
            };
            let amount = if matches!(direction, Direction::Outgoing) { spent_amount } else { received_amount };
            self.scan_state.record_transaction(TransactionRecord {
                txid, block_height: block.height, block_hash: block.hash, direction,
                amount, fee: parsed.ringct.fee,
            })?;
        }
        Ok(ProcessedTransaction { txid, block_height: block.height, received_outputs, spent_outputs })
    }

    /// Mark a scan complete only after the caller has processed all transactions through the
    /// current canonical tip. The engine cannot infer completeness from individual transactions.
    pub fn mark_scan_complete(&mut self, height: u64) -> Result<(), WalletEngineError> {
        if self.scan_state.journal().tip().map(|tip| tip.height) != Some(height) {
            return Err(WalletEngineError::ScanNotAtTip);
        }
        self.phase = EnginePhase::Ready { height };
        Ok(())
    }

    pub fn save_scan_state(&self, path: impl AsRef<Path>) -> Result<(), WalletEngineError> {
        self.scan_state.save_atomic(path)?;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nerva_core::crypto::SecretKey;

    fn secret(n: u8) -> SecretKey { let mut bytes=[0u8;32]; bytes[0]=n; SecretKey::from_bytes(bytes).unwrap() }

    #[test]
    fn opens_scan_engine_for_spend_capable_account_and_exports_expected_address() {
        let account=AccountKeys::from_spend_secret(secret(7)).unwrap();
        let expected=account.address().encode().unwrap();
        let engine=WalletEngine::from_account(account,"test",0).unwrap();
        assert_eq!(engine.address_string().unwrap(),expected);
        assert!(!engine.is_watch_only());
        assert_eq!(engine.phase(),&EnginePhase::Opening);
        assert!(engine.recovery_seed().unwrap().split_whitespace().count()==25);
    }

    #[test]
    fn custom_key_wallet_does_not_claim_seed_phrase_restores_the_same_address() {
        let account=AccountKeys::from_secret_keys(secret(7),secret(11)).unwrap();
        let engine=WalletEngine::from_account(account,"custom",0).unwrap();
        assert!(engine.recovery_seed().is_none());
    }

    #[test]
    fn scans_a_transparent_coinbase_output_and_records_reorg_anchored_history() {
        use nerva_core::{
            crypto::{derive_public_key, generate_key_derivation, public_key_from_secret},
            varint,
        };
        let account = AccountKeys::from_spend_secret(secret(7)).unwrap();
        let tx_secret = secret(13);
        let tx_public_key = public_key_from_secret(&tx_secret);
        let derivation = generate_key_derivation(&tx_public_key, account.view_secret()).unwrap();
        let output_key = derive_public_key(&derivation, 0, &account.address().spend_public_key).unwrap();
        let block = BlockRef { height: 10, hash: [0x10; 32], parent_hash: [0; 32] };
        let mut engine = WalletEngine::from_account(account, "integration-test", 0).unwrap();
        engine.reconcile_chain(&[block.clone()]).unwrap();

        // Synthetic v2 coinbase with one transparent output, one primary tx public key,
        // and a null RingCT type. This is a parser/scanner integration fixture, not a
        // consensus-valid block or a broadcastable transaction.
        let mut raw = Vec::new();
        raw.extend(varint::encode(2)); // transaction version
        raw.extend(varint::encode(0)); // unlock time
        raw.extend(varint::encode(1)); raw.push(0xff); raw.extend(varint::encode(block.height));
        raw.extend(varint::encode(1)); // outputs
        raw.extend(varint::encode(50)); raw.push(2); raw.extend_from_slice(&output_key);
        let mut extra = vec![1]; extra.extend_from_slice(&tx_public_key);
        raw.extend(varint::encode(extra.len() as u64)); raw.extend(extra);
        raw.push(0); // RCTTypeNull

        let processed = engine.scan_transaction_metadata([0x77; 32], &block, &raw).unwrap();
        assert_eq!(processed.received_outputs.len(), 1);
        assert_eq!(processed.received_outputs[0].amount, 50);
        assert_eq!(engine.balance_summary().unwrap().unspent, 50);
        let history = engine.scan_state().transactions().next().unwrap();
        assert_eq!(history.txid, [0x77; 32]);
        assert_eq!(history.direction, Direction::Coinbase);
        assert_eq!(history.amount, 50);
    }

    #[test]
    fn refuses_to_mark_scan_complete_before_canonical_tip() {
        let account=AccountKeys::from_spend_secret(secret(7)).unwrap();
        let mut engine=WalletEngine::from_account(account,"test",0).unwrap();
        assert_eq!(engine.mark_scan_complete(0),Err(WalletEngineError::ScanNotAtTip));
    }
}
