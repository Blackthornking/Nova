//! Wallet-engine migration layer.
//!
//! Rust-native wallet storage, scan orchestration and reorg-aware tracking.
//! Key-image generation, complete consensus checks, transaction construction and signing remain unported.

pub mod engine;
pub mod scan_journal;
pub mod storage;
pub mod tracking;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum EnginePhase {
    Closed,
    Opening,
    Scanning { height: u64, target_height: u64 },
    Ready { height: u64 },
    Error { safe_message: String },
}

impl EnginePhase {
    pub fn is_ready(&self) -> bool { matches!(self, Self::Ready { .. }) }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn wallet_phase_is_ready_only_after_scan_completion() {
        assert!(!EnginePhase::Closed.is_ready());
        assert!(!EnginePhase::Scanning { height: 50, target_height: 100 }.is_ready());
        assert!(EnginePhase::Ready { height: 100 }.is_ready());
    }
}
