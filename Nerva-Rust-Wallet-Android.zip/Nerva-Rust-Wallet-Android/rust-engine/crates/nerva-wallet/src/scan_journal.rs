//! Reorg-safe scan cursor bookkeeping independent of any particular disk database.
//!
//! This is metadata only and contains no seed or private key material. Persistence and binding
//! to Nerva's block parser are separate integration tasks.
use serde::{Deserialize, Serialize};
use std::{fs::{self, File, OpenOptions}, io::{Read, Write}, path::{Path, PathBuf}};
use rand::{rngs::OsRng, RngCore};
use thiserror::Error;

const MAX_JOURNAL_BYTES: u64 = 8 * 1024 * 1024;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct BlockRef {
    pub height: u64,
    pub hash: [u8; 32],
    pub parent_hash: [u8; 32],
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ReconcileReport {
    pub common_height: Option<u64>,
    pub rolled_back_blocks: usize,
    pub appended_blocks: usize,
}

#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum JournalError {
    #[error("headers are not in consecutive height order at index {0}")]
    HeightGap(usize),
    #[error("block parent hash does not match previous block at index {0}")]
    ParentMismatch(usize),
    #[error("scan journal file I/O failed: {0}")]
    Io(String),
    #[error("scan journal encoding is invalid: {0}")]
    Encoding(String),
    #[error("scan journal is too large")]
    TooLarge,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ScanJournal { blocks: Vec<BlockRef> }

impl ScanJournal {
    pub fn blocks(&self) -> &[BlockRef] { &self.blocks }
    pub fn tip(&self) -> Option<&BlockRef> { self.blocks.last() }
    pub fn validate(&self) -> Result<(), JournalError> { validate_chain(&self.blocks) }
    pub fn next_height(&self) -> Option<u64> { self.tip().and_then(|b| b.height.checked_add(1)) }

    /// Load a persisted scan journal and reject malformed/non-contiguous header chains.
    pub fn load_from_path(path: impl AsRef<Path>) -> Result<Self, JournalError> {
        let file = File::open(path.as_ref()).map_err(|e| JournalError::Io(e.to_string()))?;
        let metadata = file.metadata().map_err(|e| JournalError::Io(e.to_string()))?;
        if metadata.len() > MAX_JOURNAL_BYTES { return Err(JournalError::TooLarge); }
        let mut bytes = Vec::with_capacity(metadata.len() as usize);
        file.take(MAX_JOURNAL_BYTES + 1).read_to_end(&mut bytes).map_err(|e| JournalError::Io(e.to_string()))?;
        if bytes.len() as u64 > MAX_JOURNAL_BYTES { return Err(JournalError::TooLarge); }
        let journal: ScanJournal = serde_json::from_slice(&bytes).map_err(|e| JournalError::Encoding(e.to_string()))?;
        journal.validate()?;
        Ok(journal)
    }

    /// Persist the contiguous scan journal using a same-directory temp file and atomic rename.
    /// The journal contains block headers only; it never stores private account keys.
    pub fn save_atomic(&self, path: impl AsRef<Path>) -> Result<(), JournalError> {
        self.validate()?;
        let bytes = serde_json::to_vec(self).map_err(|e| JournalError::Encoding(e.to_string()))?;
        if bytes.len() as u64 > MAX_JOURNAL_BYTES { return Err(JournalError::TooLarge); }
        let path = path.as_ref();
        let parent = path.parent().filter(|p| !p.as_os_str().is_empty()).unwrap_or_else(|| Path::new("."));
        fs::create_dir_all(parent).map_err(|e| JournalError::Io(e.to_string()))?;
        let file_name = path.file_name().ok_or_else(|| JournalError::Io("scan journal path has no file name".into()))?.to_string_lossy();
        let mut random = [0u8; 8]; OsRng.fill_bytes(&mut random);
        let suffix = random.iter().map(|b| format!("{b:02x}")).collect::<String>();
        let tmp: PathBuf = parent.join(format!(".{file_name}.{suffix}.tmp"));
        let write_result = (|| -> Result<(), JournalError> {
            let mut options = OpenOptions::new(); options.write(true).create_new(true);
            #[cfg(unix)] { use std::os::unix::fs::OpenOptionsExt; options.mode(0o600); }
            let mut file = options.open(&tmp).map_err(|e| JournalError::Io(e.to_string()))?;
            file.write_all(&bytes).map_err(|e| JournalError::Io(e.to_string()))?;
            file.sync_all().map_err(|e| JournalError::Io(e.to_string()))?;
            fs::rename(&tmp, path).map_err(|e| JournalError::Io(e.to_string()))?;
            if let Ok(dir) = File::open(parent) { let _ = dir.sync_all(); }
            Ok(())
        })();
        if write_result.is_err() { let _ = fs::remove_file(tmp); }
        write_result
    }

    /// Reconcile the stored contiguous header window with a fresh canonical window. Both lists
    /// must cover the same starting height for common-prefix comparison to be meaningful.
    /// A reorg trims all noncanonical scan checkpoints before appending the new branch.
    pub fn reconcile(&mut self, canonical: &[BlockRef]) -> Result<ReconcileReport, JournalError> {
        validate_chain(canonical)?;
        validate_chain(&self.blocks)?;
        if self.blocks.is_empty() {
            self.blocks.extend_from_slice(canonical);
            return Ok(ReconcileReport { common_height: None, rolled_back_blocks: 0, appended_blocks: canonical.len() });
        }
        if canonical.is_empty() {
            let removed = self.blocks.len();
            self.blocks.clear();
            return Ok(ReconcileReport { common_height: None, rolled_back_blocks: removed, appended_blocks: 0 });
        }
        if self.blocks[0].height != canonical[0].height {
            return Err(JournalError::HeightGap(0));
        }
        let common = self.blocks.iter().zip(canonical.iter()).take_while(|(a,b)| a.height == b.height && a.hash == b.hash).count();
        let old_len = self.blocks.len();
        let common_height = common.checked_sub(1).map(|idx| self.blocks[idx].height);
        self.blocks.truncate(common);
        self.blocks.extend_from_slice(&canonical[common..]);
        Ok(ReconcileReport {
            common_height,
            rolled_back_blocks: old_len - common,
            appended_blocks: canonical.len().saturating_sub(common),
        })
    }
}

fn validate_chain(blocks: &[BlockRef]) -> Result<(), JournalError> {
    for i in 1..blocks.len() {
        let expected = blocks[i - 1].height.checked_add(1).ok_or(JournalError::HeightGap(i))?;
        if blocks[i].height != expected { return Err(JournalError::HeightGap(i)); }
        if blocks[i].parent_hash != blocks[i - 1].hash { return Err(JournalError::ParentMismatch(i)); }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    fn b(height:u64, hash:u8, parent:u8)->BlockRef { BlockRef{height,hash:[hash;32],parent_hash:[parent;32]} }
    #[test]
    fn tracks_forward_extension() {
        let mut j=ScanJournal::default();
        j.reconcile(&[b(10,1,0),b(11,2,1)]).unwrap();
        let report=j.reconcile(&[b(10,1,0),b(11,2,1),b(12,3,2)]).unwrap();
        assert_eq!(report.common_height,Some(11));
        assert_eq!(report.rolled_back_blocks,0);
        assert_eq!(report.appended_blocks,1);
        assert_eq!(j.tip().unwrap().height,12);
    }
    #[test]
    fn rolls_back_and_replaces_reorged_suffix() {
        let mut j=ScanJournal::default();
        j.reconcile(&[b(10,1,0),b(11,2,1),b(12,3,2)]).unwrap();
        let report=j.reconcile(&[b(10,1,0),b(11,2,1),b(12,8,2),b(13,9,8)]).unwrap();
        assert_eq!(report.common_height,Some(11));
        assert_eq!(report.rolled_back_blocks,1);
        assert_eq!(report.appended_blocks,2);
        assert_eq!(j.tip().unwrap().hash,[9;32]);
    }
    #[test]
    fn journal_roundtrips_atomically_and_revalidates_on_load() {
        let base=std::env::temp_dir().join(format!("nerva-journal-{}-{}", std::process::id(), std::thread::current().name().unwrap_or("test")));
        let path=base.join("journal.json");
        let mut j=ScanJournal::default();
        j.reconcile(&[b(10,1,0),b(11,2,1),b(12,3,2)]).unwrap();
        j.save_atomic(&path).unwrap();
        let loaded=ScanJournal::load_from_path(&path).unwrap();
        assert_eq!(loaded.blocks(),j.blocks());
        let _=fs::remove_dir_all(&base);
    }

    #[test]
    fn rejects_inconsistent_parent_link() {
        let mut j=ScanJournal::default();
        assert_eq!(j.reconcile(&[b(10,1,0),b(11,2,99)]),Err(JournalError::ParentMismatch(1)));
    }
}
