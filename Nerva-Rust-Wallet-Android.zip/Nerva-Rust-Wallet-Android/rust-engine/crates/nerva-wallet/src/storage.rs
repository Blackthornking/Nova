//! Versioned, authenticated-encryption wallet container for Rust-native account keys.
//!
//! This is a new Rust wallet format; it is not compatible with Nerva's legacy C++ .keys files.
//! A future migration tool must import/export those files through the upstream wallet until parity
//! has been independently verified.
use argon2::{Algorithm, Argon2, Params, Version};
use chacha20poly1305::{aead::{Aead, KeyInit, Payload}, ChaCha20Poly1305, Nonce};
use rand::{rngs::OsRng, RngCore};
use serde::{Deserialize, Serialize};
use std::{fs::{self, File, OpenOptions}, io::{Read, Write}, path::{Path, PathBuf}};
use thiserror::Error;
use zeroize::{Zeroize, ZeroizeOnDrop, Zeroizing};
use nerva_core::{
    account::AccountKeys,
    address::{Address, AddressKind},
    consensus,
    crypto::{decode_public_key, hash_to_scalar, public_key_from_secret, SecretKey},
    mnemonic::{encode_seed, recover_account, MnemonicError},
};

const MAGIC: &[u8; 8] = b"NRVWLT01";
const SALT_LEN: usize = 16;
const NONCE_LEN: usize = 12;
const KEY_LEN: usize = 32;
const HEADER_LEN: usize = 8 + SALT_LEN + NONCE_LEN;
const MAX_WALLET_FILE: usize = 4 * 1024 * 1024;
const ARGON2_MEMORY_KIB: u32 = 65_536;
const ARGON2_ITERATIONS: u32 = 3;
const ARGON2_LANES: u32 = 1;

#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum StorageError {
    #[error("wallet password must contain at least 1 byte")]
    EmptyPassword,
    #[error("wallet file is too short, too large, or has an unknown format")]
    InvalidFile,
    #[error("wallet file is damaged or the password is incorrect")]
    AuthenticationFailed,
    #[error("wallet file JSON is invalid: {0}")]
    Json(String),
    #[error("wallet password key derivation failed")]
    KeyDerivation,
    #[error("wallet secret key is invalid")]
    InvalidSecret,
    #[error("wallet public key does not match its spend secret")]
    SpendKeyMismatch,
    #[error("wallet public key is invalid")]
    InvalidPublicKey,
    #[error("wallet name is invalid")]
    InvalidName,
    #[error("wallet file I/O failed: {0}")]
    Io(String),
    #[error("this wallet is watch-only and has no spend secret")]
    WatchOnly,
    #[error("mnemonic recovery failed: {0}")]
    Mnemonic(String),
    #[error("account conversion failed: {0}")]
    Account(String),
}

#[derive(Serialize, Deserialize, Zeroize, ZeroizeOnDrop)]
struct WalletPayload {
    schema: u32,
    wallet_name: String,
    restore_height: u64,
    spend_public_key: [u8; 32],
    spend_secret: Option<[u8; 32]>,
    view_secret: [u8; 32],
}

/// An opened account. Key material is represented by SecretKey, whose Drop implementation wipes
/// the scalar. Debug does not expose either key.
pub struct UnlockedWallet {
    wallet_name: String,
    restore_height: u64,
    spend_public_key: [u8; 32],
    spend_secret: Option<SecretKey>,
    view_secret: SecretKey,
}
impl UnlockedWallet {
    pub fn wallet_name(&self) -> &str { &self.wallet_name }
    pub fn restore_height(&self) -> u64 { self.restore_height }
    pub fn is_watch_only(&self) -> bool { self.spend_secret.is_none() }
    pub fn spend_secret(&self) -> Option<&SecretKey> { self.spend_secret.as_ref() }
    pub fn view_secret(&self) -> &SecretKey { &self.view_secret }
    pub fn spend_public_key(&self) -> [u8; 32] { self.spend_public_key }

    /// Return an English Nerva recovery phrase for a spend-capable wallet. The caller must only
    /// display it over a trusted, offline backup flow and must never log or send it to a daemon.
    pub fn recovery_seed(&self) -> Option<String> {
        let spend = self.spend_secret.as_ref()?;
        // The standard mnemonic encodes the spend scalar and restore derives the view scalar from
        // it. Imported custom-key accounts must not be offered a phrase that would restore another
        // address, so only expose the phrase when the account is seed-compatible.
        (hash_to_scalar(spend.as_bytes()).to_bytes() == *self.view_secret.as_bytes())
            .then(|| encode_seed(spend.as_bytes()))
    }

    /// Consume this unlocked wallet into the Rust-native account model. Watch-only accounts must
    /// stay watch-only and cannot be converted into an AccountKeys value.
    pub fn into_account_keys(self) -> Result<AccountKeys, StorageError> {
        let spend = self.spend_secret.ok_or(StorageError::WatchOnly)?;
        AccountKeys::from_secret_keys(spend, self.view_secret).map_err(|e| StorageError::Account(e.to_string()))
    }

    pub fn primary_address(&self) -> Address {
        Address {
            kind: AddressKind::Standard,
            prefix: consensus::PUBLIC_ADDRESS_PREFIX,
            spend_public_key: self.spend_public_key,
            view_public_key: public_key_from_secret(&self.view_secret),
            payment_id: None,
        }
    }

    /// Transfer the account's public address and secret-key handles to the in-process Rust engine.
    /// The caller must keep these keys only in private process memory and must not log them.
    pub(crate) fn into_engine_parts(self) -> (String, u64, Address, SecretKey, Option<SecretKey>) {
        let address = self.primary_address();
        (self.wallet_name, self.restore_height, address, self.view_secret, self.spend_secret)
    }
}

pub struct WalletFile;
impl WalletFile {
    /// Encrypt the new Rust-format wallet from native Rust account keys.
    pub fn seal_account(
        wallet_name: &str,
        restore_height: u64,
        account: &AccountKeys,
        password: &[u8],
    ) -> Result<Vec<u8>, StorageError> {
        Self::seal(wallet_name, restore_height, account.spend_public_key(), Some(account.spend_secret()), account.view_secret(), password)
    }

    /// Restore a Rust account from an English Nerva seed and encrypt it in the new Rust wallet format.
    /// This does not import the legacy upstream `.keys` file format.
    pub fn seal_recovery_seed(
        wallet_name: &str,
        restore_height: u64,
        seed: &str,
        password: &[u8],
    ) -> Result<Vec<u8>, StorageError> {
        let account = recover_account(seed).map_err(|e: MnemonicError| StorageError::Mnemonic(e.to_string()))?;
        Self::seal_account(wallet_name, restore_height, &account, password)
    }

    /// Encrypt the new Rust-format wallet. Pass `None` for `spend_secret` to create a view-only wallet.
    pub fn seal(
        wallet_name: &str,
        restore_height: u64,
        spend_public_key: [u8; 32],
        spend_secret: Option<&SecretKey>,
        view_secret: &SecretKey,
        password: &[u8],
    ) -> Result<Vec<u8>, StorageError> {
        validate_password(password)?;
        if wallet_name.trim().is_empty() || wallet_name.len() > 128 || wallet_name.chars().any(char::is_control) {
            return Err(StorageError::InvalidName);
        }
        // Ensure public points are valid before committing any file.
        decode_public_key(&spend_public_key).map_err(|_| StorageError::InvalidPublicKey)?;
        if let Some(spend) = spend_secret {
            if public_key_from_secret(spend) != spend_public_key { return Err(StorageError::SpendKeyMismatch); }
        }
        let payload = WalletPayload {
            schema: 1,
            wallet_name: wallet_name.to_owned(),
            restore_height,
            spend_public_key,
            spend_secret: spend_secret.map(|s| *s.as_bytes()),
            view_secret: *view_secret.as_bytes(),
        };
        let plaintext = Zeroizing::new(serde_json::to_vec(&payload).map_err(|e| StorageError::Json(e.to_string()))?);
        let mut salt = [0u8; SALT_LEN]; let mut nonce = [0u8; NONCE_LEN];
        OsRng.fill_bytes(&mut salt); OsRng.fill_bytes(&mut nonce);
        let key = derive_key(password, &salt)?;
        let cipher = ChaCha20Poly1305::new_from_slice(&key[..]).map_err(|_| StorageError::KeyDerivation)?;
        let mut aad = Vec::with_capacity(8 + SALT_LEN); aad.extend_from_slice(MAGIC); aad.extend_from_slice(&salt);
        let ciphertext = cipher.encrypt(Nonce::from_slice(&nonce), Payload { msg: &plaintext, aad: &aad })
            .map_err(|_| StorageError::AuthenticationFailed)?;
        let mut out = Vec::with_capacity(HEADER_LEN + ciphertext.len());
        out.extend_from_slice(MAGIC); out.extend_from_slice(&salt); out.extend_from_slice(&nonce); out.extend_from_slice(&ciphertext);
        Ok(out)
    }

    /// Encrypt and atomically persist a wallet file. The plaintext keys are never written to disk.
    pub fn seal_to_path(
        path: impl AsRef<Path>, wallet_name: &str, restore_height: u64,
        spend_public_key: [u8; 32], spend_secret: Option<&SecretKey>,
        view_secret: &SecretKey, password: &[u8],
    ) -> Result<(), StorageError> {
        let encrypted = Self::seal(wallet_name, restore_height, spend_public_key, spend_secret, view_secret, password)?;
        write_atomic(path.as_ref(), &encrypted)
    }

    /// Open and authenticate an encrypted wallet from a file in the app-private directory.
    pub fn open_path(path: impl AsRef<Path>, password: &[u8]) -> Result<UnlockedWallet, StorageError> {
        let file = File::open(path.as_ref()).map_err(|e| StorageError::Io(e.to_string()))?;
        let metadata = file.metadata().map_err(|e| StorageError::Io(e.to_string()))?;
        if metadata.len() > MAX_WALLET_FILE as u64 { return Err(StorageError::InvalidFile); }
        let mut bytes = Vec::with_capacity(metadata.len() as usize);
        file.take((MAX_WALLET_FILE + 1) as u64).read_to_end(&mut bytes).map_err(|e| StorageError::Io(e.to_string()))?;
        if bytes.len() > MAX_WALLET_FILE { return Err(StorageError::InvalidFile); }
        Self::open(&bytes, password)
    }

    /// Decrypt and validate the stored wallet; wrong passwords and tampering share one error.
    pub fn open(bytes: &[u8], password: &[u8]) -> Result<UnlockedWallet, StorageError> {
        validate_password(password)?;
        if bytes.len() < HEADER_LEN + 16 || bytes.len() > MAX_WALLET_FILE || &bytes[..8] != MAGIC {
            return Err(StorageError::InvalidFile);
        }
        let salt = &bytes[8..8 + SALT_LEN];
        let nonce_start = 8 + SALT_LEN;
        let nonce = &bytes[nonce_start..nonce_start + NONCE_LEN];
        let ciphertext = &bytes[HEADER_LEN..];
        let key = derive_key(password, salt)?;
        let cipher = ChaCha20Poly1305::new_from_slice(&key[..]).map_err(|_| StorageError::KeyDerivation)?;
        let mut aad = Vec::with_capacity(8 + SALT_LEN); aad.extend_from_slice(MAGIC); aad.extend_from_slice(salt);
        let plain = cipher.decrypt(Nonce::from_slice(nonce), Payload { msg: ciphertext, aad: &aad })
            .map_err(|_| StorageError::AuthenticationFailed)?;
        let plaintext = Zeroizing::new(plain);
        let payload: WalletPayload = serde_json::from_slice(&plaintext).map_err(|_| StorageError::AuthenticationFailed)?;
        if payload.schema != 1 || payload.wallet_name.trim().is_empty() || payload.wallet_name.len() > 128 {
            return Err(StorageError::InvalidFile);
        }
        // Verify that the stored public key and, where present, spend secret really belong together.
        decode_public_key(&payload.spend_public_key).map_err(|_| StorageError::InvalidPublicKey)?;
        let spend_secret = match payload.spend_secret.as_ref() {
            Some(bytes) => {
                let key = SecretKey::from_bytes(*bytes).map_err(|_| StorageError::InvalidSecret)?;
                if public_key_from_secret(&key) != payload.spend_public_key { return Err(StorageError::SpendKeyMismatch); }
                Some(key)
            }
            None => None,
        };
        let view_secret = SecretKey::from_bytes(payload.view_secret).map_err(|_| StorageError::InvalidSecret)?;
        Ok(UnlockedWallet {
            wallet_name: payload.wallet_name.clone(),
            restore_height: payload.restore_height,
            spend_public_key: payload.spend_public_key,
            spend_secret,
            view_secret,
        })
    }
}

fn write_atomic(path: &Path, contents: &[u8]) -> Result<(), StorageError> {
    let parent = path.parent().filter(|p| !p.as_os_str().is_empty()).unwrap_or_else(|| Path::new("."));
    fs::create_dir_all(parent).map_err(|e| StorageError::Io(e.to_string()))?;
    let file_name = path.file_name().ok_or_else(|| StorageError::Io("wallet path has no file name".into()))?.to_string_lossy();
    let mut suffix_bytes = [0u8; 8]; OsRng.fill_bytes(&mut suffix_bytes);
    let suffix: String = suffix_bytes.iter().map(|b| format!("{b:02x}")).collect();
    let tmp: PathBuf = parent.join(format!(".{file_name}.{suffix}.tmp"));
    let write_result = (|| -> Result<(), StorageError> {
        let mut options = OpenOptions::new(); options.write(true).create_new(true);
        #[cfg(unix)] { use std::os::unix::fs::OpenOptionsExt; options.mode(0o600); }
        let mut file = options.open(&tmp).map_err(|e| StorageError::Io(e.to_string()))?;
        file.write_all(contents).map_err(|e| StorageError::Io(e.to_string()))?;
        file.sync_all().map_err(|e| StorageError::Io(e.to_string()))?;
        fs::rename(&tmp, path).map_err(|e| StorageError::Io(e.to_string()))?;
        if let Ok(directory) = File::open(parent) { let _ = directory.sync_all(); }
        Ok(())
    })();
    if write_result.is_err() { let _ = fs::remove_file(&tmp); }
    write_result
}

fn validate_password(password: &[u8]) -> Result<(), StorageError> {
    if password.is_empty() { Err(StorageError::EmptyPassword) } else { Ok(()) }
}
fn derive_key(password: &[u8], salt: &[u8]) -> Result<Zeroizing<[u8; KEY_LEN]>, StorageError> {
    let params = Params::new(ARGON2_MEMORY_KIB, ARGON2_ITERATIONS, ARGON2_LANES, Some(KEY_LEN)).map_err(|_| StorageError::KeyDerivation)?;
    let argon = Argon2::new(Algorithm::Argon2id, Version::V0x13, params);
    let mut key = Zeroizing::new([0u8; KEY_LEN]);
    argon.hash_password_into(password, salt, &mut *key).map_err(|_| StorageError::KeyDerivation)?;
    Ok(key)
}

#[cfg(test)]
mod tests {
    use super::*;
    fn sk(n: u8) -> SecretKey { let mut b=[0u8;32]; b[0]=n; SecretKey::from_bytes(b).unwrap() }

    #[test]
    fn encrypted_wallet_roundtrips_and_checks_keys() {
        let spend=sk(7); let view=sk(11); let spend_public=public_key_from_secret(&spend);
        let bytes=WalletFile::seal("test wallet", 123_456, spend_public, Some(&spend), &view, b"correct horse battery") .unwrap();
        assert!(bytes.starts_with(MAGIC));
        let opened=WalletFile::open(&bytes,b"correct horse battery").unwrap();
        assert_eq!(opened.wallet_name(),"test wallet"); assert_eq!(opened.restore_height(),123_456);
        assert!(!opened.is_watch_only()); assert_eq!(opened.primary_address().spend_public_key,spend_public);
    }

    #[test]
    fn wrong_password_and_tampering_do_not_release_payload() {
        let spend=sk(7); let view=sk(11); let mut bytes=WalletFile::seal("wallet",0,public_key_from_secret(&spend),Some(&spend),&view,b"secret").unwrap();
        assert!(matches!(WalletFile::open(&bytes,b"wrong"),Err(StorageError::AuthenticationFailed)));
        let idx=bytes.len()-1; bytes[idx]^=1;
        assert!(matches!(WalletFile::open(&bytes,b"secret"),Err(StorageError::AuthenticationFailed)));
    }

    #[test]
    fn account_wallet_produces_restore_seed_and_roundtrips_account() {
        let spend=sk(7);
        let account=AccountKeys::from_spend_secret(spend).unwrap();
        let bytes=WalletFile::seal_account("wallet",77,&account,b"strong password").unwrap();
        let opened=WalletFile::open(&bytes,b"strong password").unwrap();
        let seed=opened.recovery_seed().unwrap();
        assert_eq!(seed.split_whitespace().count(),25);
        let restored=WalletFile::seal_recovery_seed("restored",77,&seed,b"other password").unwrap();
        let roundtrip=WalletFile::open(&restored,b"other password").unwrap().into_account_keys().unwrap();
        assert_eq!(roundtrip.address(),account.address());
    }

    #[test]
    fn supports_watch_only_wallets() {
        let spend=sk(7); let view=sk(11); let bytes=WalletFile::seal("watch-only",42,public_key_from_secret(&spend),None,&view,b"pw").unwrap();
        let opened=WalletFile::open(&bytes,b"pw").unwrap();
        assert!(opened.is_watch_only());
        assert!(opened.recovery_seed().is_none());
    }

    #[test]
    fn custom_view_key_does_not_offer_a_misleading_spend_seed() {
        let spend=sk(7); let view=sk(11);
        let account=AccountKeys::from_secret_keys(spend,view).unwrap();
        let bytes=WalletFile::seal_account("custom",0,&account,b"pw").unwrap();
        assert!(WalletFile::open(&bytes,b"pw").unwrap().recovery_seed().is_none());
    }
}
