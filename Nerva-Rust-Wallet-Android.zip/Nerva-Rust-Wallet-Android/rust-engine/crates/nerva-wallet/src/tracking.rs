//! Wallet-side record tracking for incoming outputs, transaction history and known key-image spends.
//!
//! This module intentionally does not manufacture key images: a spend-capable output must be
//! assigned a key image by a separately verified wallet-key implementation before the Rust engine
//! can reliably recognise it as spent. Records are block-hash anchored so reorg reconciliation
//! removes noncanonical incoming outputs and outgoing transactions.
use crate::scan_journal::{BlockRef, JournalError, ReconcileReport, ScanJournal};
use nerva_core::tx_prefix::{ParsedTxPrefix, TxInput};
use serde::{Deserialize, Serialize};
use std::{
    collections::{BTreeMap, HashSet},
    fs::{self, File, OpenOptions},
    io::{Read, Write},
    path::{Path, PathBuf},
};
use rand::{rngs::OsRng, RngCore};
use thiserror::Error;

const MAX_TRACKED_ITEMS: usize = 2_000_000;
const MAX_TRACKED_FILE_BYTES: u64 = 128 * 1024 * 1024;

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub struct OutputId {
    pub txid: [u8; 32],
    pub output_index: u32,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct OwnedOutputRecord {
    pub id: OutputId,
    pub block_height: u64,
    pub block_hash: [u8; 32],
    pub amount: u64,
    pub key_image: Option<[u8; 32]>,
    pub spent_by_txid: Option<[u8; 32]>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Direction { Incoming, Outgoing, Coinbase, SelfTransfer }

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct TransactionRecord {
    pub txid: [u8; 32],
    pub block_height: u64,
    pub block_hash: [u8; 32],
    pub direction: Direction,
    /// Net wallet-relevant amount in atomic units. Fee is recorded separately.
    pub amount: u64,
    pub fee: Option<u64>,
}

#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum TrackingError {
    #[error("scan journal error: {0}")]
    Journal(#[from] JournalError),
    #[error("record is not anchored to a known scanned block")]
    UnknownBlock,
    #[error("wallet scan record count exceeds the safety limit")]
    TooManyItems,
    #[error("an output key image is already assigned to another output")]
    DuplicateKeyImage,
    #[error("amount totals overflow uint64 atomic units")]
    AmountOverflow,
    #[error("wallet scan state I/O failed: {0}")]
    Io(String),
    #[error("wallet scan state encoding is invalid: {0}")]
    Encoding(String),
    #[error("wallet scan state exceeds the configured size limit")]
    TooLarge,
    #[error("wallet scan state is internally inconsistent")]
    InvalidPersistedState,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct WalletScanState {
    journal: ScanJournal,
    #[serde(with = "map_as_vec")]
    outputs: BTreeMap<OutputId, OwnedOutputRecord>,
    #[serde(with = "map_as_vec")]
    transactions: BTreeMap<[u8; 32], TransactionRecord>,
}

/// JSON object keys must be strings, whereas wallet indices use binary IDs. Serialize maps as
/// ordered key/value arrays so IDs remain lossless and duplicate keys can be rejected on load.
mod map_as_vec {
    use serde::{de::Error as DeError, Deserialize, Deserializer, Serialize, Serializer};
    use std::collections::BTreeMap;

    pub fn serialize<K, V, S>(map: &BTreeMap<K, V>, serializer: S) -> Result<S::Ok, S::Error>
    where K: Serialize + Ord, V: Serialize, S: Serializer {
        map.iter().collect::<Vec<(&K, &V)>>().serialize(serializer)
    }

    pub fn deserialize<'de, K, V, D>(deserializer: D) -> Result<BTreeMap<K, V>, D::Error>
    where K: Deserialize<'de> + Ord, V: Deserialize<'de>, D: Deserializer<'de> {
        let entries = Vec::<(K, V)>::deserialize(deserializer)?;
        let original_len = entries.len();
        let map: BTreeMap<K, V> = entries.into_iter().collect();
        if map.len() != original_len { return Err(D::Error::custom("duplicate key in wallet scan state")); }
        Ok(map)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct BalanceSummary {
    pub total_received: u64,
    pub unspent: u64,
    pub spent: u64,
    pub output_count: usize,
    pub unspent_output_count: usize,
}

impl WalletScanState {
    pub fn journal(&self) -> &ScanJournal { &self.journal }
    pub fn outputs(&self) -> impl Iterator<Item = &OwnedOutputRecord> { self.outputs.values() }
    pub fn transactions(&self) -> impl Iterator<Item = &TransactionRecord> { self.transactions.values() }

    /// Initialise or reconcile the scanned canonical header window. On a reorg, records in the
    /// replaced suffix are removed and spend markers created by removed transactions are cleared.
    pub fn reconcile_chain(&mut self, canonical: &[BlockRef]) -> Result<ReconcileReport, TrackingError> {
        let report = self.journal.reconcile(canonical)?;
        let remove_txids: Vec<[u8; 32]> = self.transactions.values()
            .filter(|tx| !self.journal.blocks().iter().any(|b| b.height == tx.block_height && b.hash == tx.block_hash))
            .map(|tx| tx.txid).collect();
        for txid in &remove_txids { self.transactions.remove(txid); }
        let remove_outputs: Vec<OutputId> = self.outputs.values()
            .filter(|o| !self.journal.blocks().iter().any(|b| b.height == o.block_height && b.hash == o.block_hash))
            .map(|o| o.id.clone()).collect();
        for id in remove_outputs { self.outputs.remove(&id); }
        if !remove_txids.is_empty() {
            let removed: HashSet<[u8; 32]> = remove_txids.iter().copied().collect();
            for output in self.outputs.values_mut() {
                if output.spent_by_txid.is_some_and(|txid| removed.contains(&txid)) {
                    output.spent_by_txid = None;
                }
            }
        }
        Ok(report)
    }

    /// Load private-app-directory transaction metadata from a bounded JSON file. This file does
    /// not contain account secrets; callers should still keep it in app-private storage because it
    /// reveals addresses' history and balances.
    pub fn load_or_default(path: impl AsRef<Path>) -> Result<Self, TrackingError> {
        match File::open(path.as_ref()) {
            Ok(file) => Self::load_file(file),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(Self::default()),
            Err(error) => Err(TrackingError::Io(error.to_string())),
        }
    }

    pub fn load_from_path(path: impl AsRef<Path>) -> Result<Self, TrackingError> {
        let file = File::open(path.as_ref()).map_err(|e| TrackingError::Io(e.to_string()))?;
        Self::load_file(file)
    }

    fn load_file(file: File) -> Result<Self, TrackingError> {
        let metadata = file.metadata().map_err(|e| TrackingError::Io(e.to_string()))?;
        if metadata.len() > MAX_TRACKED_FILE_BYTES { return Err(TrackingError::TooLarge); }
        let mut bytes = Vec::with_capacity(metadata.len() as usize);
        file.take(MAX_TRACKED_FILE_BYTES + 1).read_to_end(&mut bytes).map_err(|e| TrackingError::Io(e.to_string()))?;
        if bytes.len() as u64 > MAX_TRACKED_FILE_BYTES { return Err(TrackingError::TooLarge); }
        let state: WalletScanState = serde_json::from_slice(&bytes).map_err(|e| TrackingError::Encoding(e.to_string()))?;
        state.validate_persisted_state()?;
        Ok(state)
    }

    /// Persist transaction metadata with an atomic same-directory rename and owner-only file
    /// permissions on Unix. A crash leaves either the previous state or the new complete state.
    pub fn save_atomic(&self, path: impl AsRef<Path>) -> Result<(), TrackingError> {
        self.validate_persisted_state()?;
        let bytes = serde_json::to_vec(self).map_err(|e| TrackingError::Encoding(e.to_string()))?;
        if bytes.len() as u64 > MAX_TRACKED_FILE_BYTES { return Err(TrackingError::TooLarge); }
        let path = path.as_ref();
        let parent = path.parent().filter(|p| !p.as_os_str().is_empty()).unwrap_or_else(|| Path::new("."));
        fs::create_dir_all(parent).map_err(|e| TrackingError::Io(e.to_string()))?;
        let file_name = path.file_name().ok_or_else(|| TrackingError::Io("scan-state path has no file name".into()))?.to_string_lossy();
        let mut random = [0u8; 8]; OsRng.fill_bytes(&mut random);
        let suffix = random.iter().map(|b| format!("{b:02x}")).collect::<String>();
        let tmp: PathBuf = parent.join(format!(".{file_name}.{suffix}.tmp"));
        let result = (|| -> Result<(), TrackingError> {
            let mut options = OpenOptions::new(); options.write(true).create_new(true);
            #[cfg(unix)] { use std::os::unix::fs::OpenOptionsExt; options.mode(0o600); }
            let mut file = options.open(&tmp).map_err(|e| TrackingError::Io(e.to_string()))?;
            file.write_all(&bytes).map_err(|e| TrackingError::Io(e.to_string()))?;
            file.sync_all().map_err(|e| TrackingError::Io(e.to_string()))?;
            fs::rename(&tmp, path).map_err(|e| TrackingError::Io(e.to_string()))?;
            if let Ok(dir) = File::open(parent) { let _ = dir.sync_all(); }
            Ok(())
        })();
        if result.is_err() { let _ = fs::remove_file(&tmp); }
        result
    }

    fn validate_persisted_state(&self) -> Result<(), TrackingError> {
        self.journal.validate()?;
        if self.outputs.len() > MAX_TRACKED_ITEMS || self.transactions.len() > MAX_TRACKED_ITEMS {
            return Err(TrackingError::TooManyItems);
        }
        let blocks: BTreeMap<u64, [u8; 32]> = self.journal.blocks().iter().map(|b| (b.height, b.hash)).collect();
        let mut seen_key_images = HashSet::new();
        for (id, output) in &self.outputs {
            if id != &output.id || blocks.get(&output.block_height) != Some(&output.block_hash) {
                return Err(TrackingError::InvalidPersistedState);
            }
            if let Some(key_image) = output.key_image {
                if !seen_key_images.insert(key_image) { return Err(TrackingError::DuplicateKeyImage); }
            }
        }
        for (txid, tx) in &self.transactions {
            if txid != &tx.txid || blocks.get(&tx.block_height) != Some(&tx.block_hash) {
                return Err(TrackingError::InvalidPersistedState);
            }
        }
        Ok(())
    }

    pub fn record_output(&mut self, id: OutputId, block: &BlockRef, amount: u64) -> Result<(), TrackingError> {
        self.record_outputs(&[(id, amount)], block)
    }

    /// Record the outputs from one transaction atomically: all IDs and capacities are validated
    /// before any record is mutated.
    pub fn record_outputs(&mut self, outputs: &[(OutputId, u64)], block: &BlockRef) -> Result<(), TrackingError> {
        self.require_known_block(block)?;
        let mut pending = BTreeMap::new();
        for (id, amount) in outputs {
            if let Some((existing_amount, existing_height, existing_hash)) = self.outputs.get(id)
                .map(|old| (old.amount, old.block_height, old.block_hash)) {
                if existing_amount != *amount || existing_height != block.height || existing_hash != block.hash {
                    return Err(TrackingError::InvalidPersistedState);
                }
            }
            if pending.insert(id.clone(), *amount).is_some() { return Err(TrackingError::InvalidPersistedState); }
        }
        let new_records = pending.keys().filter(|id| !self.outputs.contains_key(*id)).count();
        if self.outputs.len().saturating_add(new_records) > MAX_TRACKED_ITEMS { return Err(TrackingError::TooManyItems); }
        for (id, amount) in pending {
            let (key_image, spent_by_txid) = self.outputs.get(&id)
                .map(|old| (old.key_image, old.spent_by_txid)).unwrap_or((None, None));
            self.outputs.insert(id.clone(), OwnedOutputRecord {
                id, block_height: block.height, block_hash: block.hash, amount, key_image, spent_by_txid,
            });
        }
        Ok(())
    }

    /// Verify that the canonical block is known and the history table has room before a caller
    /// mutates output records. This makes the subsequent `record_transaction` call infallible
    /// except for a mismatched block when used within one exclusive wallet-engine operation.
    pub fn can_record_transaction(&self, txid: &[u8; 32], block: &BlockRef) -> Result<(), TrackingError> {
        if !self.journal.blocks().iter().any(|b| b.height == block.height && b.hash == block.hash) {
            return Err(TrackingError::UnknownBlock);
        }
        self.ensure_transaction_capacity(txid)
    }

    pub fn record_transaction(&mut self, record: TransactionRecord) -> Result<(), TrackingError> {
        if !self.journal.blocks().iter().any(|b| b.height == record.block_height && b.hash == record.block_hash) {
            return Err(TrackingError::UnknownBlock);
        }
        self.ensure_transaction_capacity(&record.txid)?;
        self.transactions.insert(record.txid, record);
        Ok(())
    }

    fn ensure_transaction_capacity(&self, txid: &[u8; 32]) -> Result<(), TrackingError> {
        if !self.transactions.contains_key(txid) && self.transactions.len() >= MAX_TRACKED_ITEMS {
            Err(TrackingError::TooManyItems)
        } else {
            Ok(())
        }
    }

    /// Find owned outputs referenced by key images in a parsed transaction, without changing
    /// spent flags. Returned amounts allow history to be prepared before any mutation. Reprocessing
    /// the same spending transaction is idempotent; an output marked spent by another tx is excluded.
    pub fn matching_spend_outputs(&self, spending_txid: &[u8; 32], prefix: &ParsedTxPrefix) -> Vec<(OutputId, u64)> {
        let images: HashSet<[u8; 32]> = prefix.inputs.iter().filter_map(|input| match input {
            TxInput::ToKey { key_image, .. } => Some(*key_image),
            _ => None,
        }).collect();
        self.outputs.values().filter(|output| {
            output.key_image.is_some_and(|ki| images.contains(&ki))
                && (output.spent_by_txid.is_none() || output.spent_by_txid == Some(*spending_txid))
        }).map(|output| (output.id.clone(), output.amount)).collect()
    }

    /// Attach a key image produced by a future verified output-key/key-image implementation.
    /// Duplicate key images are rejected to avoid corrupting spend attribution.
    pub fn assign_key_image(&mut self, id: &OutputId, key_image: [u8; 32]) -> Result<(), TrackingError> {
        if self.outputs.values().any(|output| output.key_image == Some(key_image) && output.id != *id) {
            return Err(TrackingError::DuplicateKeyImage);
        }
        let output = self.outputs.get_mut(id).ok_or(TrackingError::UnknownBlock)?;
        output.key_image = Some(key_image);
        Ok(())
    }

    /// Mark owned outputs spent by matching key images in a decoded transaction prefix.
    /// Returns the output IDs that were newly marked as spent.
    pub fn apply_spend_inputs(&mut self, spending_txid: [u8; 32], prefix: &ParsedTxPrefix) -> Vec<OutputId> {
        let candidates: HashSet<OutputId> = self.matching_spend_outputs(&spending_txid, prefix).into_iter()
            .map(|(id, _)| id).collect();
        let mut newly_spent = Vec::new();
        for output in self.outputs.values_mut() {
            if candidates.contains(&output.id) && output.spent_by_txid.is_none() {
                output.spent_by_txid = Some(spending_txid);
                newly_spent.push(output.id.clone());
            }
        }
        newly_spent
    }

    pub fn balance_summary(&self) -> Result<BalanceSummary, TrackingError> {
        let mut total_received = 0u64;
        let mut unspent = 0u64;
        let mut spent = 0u64;
        let mut unspent_output_count = 0usize;
        for output in self.outputs.values() {
            total_received = total_received.checked_add(output.amount).ok_or(TrackingError::AmountOverflow)?;
            if output.spent_by_txid.is_some() {
                spent = spent.checked_add(output.amount).ok_or(TrackingError::AmountOverflow)?;
            } else {
                unspent = unspent.checked_add(output.amount).ok_or(TrackingError::AmountOverflow)?;
                unspent_output_count += 1;
            }
        }
        Ok(BalanceSummary { total_received, unspent, spent, output_count: self.outputs.len(), unspent_output_count })
    }

    fn require_known_block(&self, block: &BlockRef) -> Result<(), TrackingError> {
        if self.journal.blocks().iter().any(|stored| stored.height == block.height && stored.hash == block.hash) {
            Ok(())
        } else { Err(TrackingError::UnknownBlock) }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nerva_core::tx_prefix::{OutputTarget, TxOutput};

    fn block(height: u64, hash: u8, parent: u8) -> BlockRef { BlockRef { height, hash: [hash; 32], parent_hash: [parent; 32] } }
    fn id(txid: u8, output_index: u32) -> OutputId { OutputId { txid: [txid; 32], output_index } }

    #[test]
    fn records_outputs_detects_key_image_spend_and_tracks_balance() {
        let mut state=WalletScanState::default();
        let b10=block(10,1,0); let b11=block(11,2,1);
        state.reconcile_chain(&[b10.clone(),b11.clone()]).unwrap();
        let output=id(8,1); state.record_output(output.clone(),&b10,250).unwrap();
        state.assign_key_image(&output,[0xa5;32]).unwrap();
        let prefix=ParsedTxPrefix { version:2, unlock_time:0, input_count:1,
            inputs:vec![TxInput::ToKey { amount:0, relative_offsets:vec![1], key_image:[0xa5;32] }],
            outputs:vec![TxOutput { amount:0, target:OutputTarget::ToKey([0x33;32]) }], extra:vec![], prefix_bytes:0 };
        assert_eq!(state.matching_spend_outputs(&[9;32], &prefix), vec![(output.clone(), 250)]);
        assert_eq!(state.apply_spend_inputs([9;32],&prefix),vec![output.clone()]);
        // Reprocessing the same transaction must recover the same history amount without
        // treating its already-marked input as a different conflicting spend.
        assert_eq!(state.matching_spend_outputs(&[9;32], &prefix), vec![(output, 250)]);
        assert!(state.apply_spend_inputs([9;32],&prefix).is_empty());
        let balance=state.balance_summary().unwrap();
        assert_eq!((balance.total_received,balance.unspent,balance.spent),(250,0,250));
    }

    #[test]
    fn state_roundtrips_atomically_and_rejects_unknown_chain_records() {
        let mut state=WalletScanState::default();
        let b10=block(10,1,0); state.reconcile_chain(&[b10.clone()]).unwrap();
        state.record_output(id(4,0),&b10,123).unwrap();
        let base=std::env::temp_dir().join(format!("nerva-wallet-state-{}",std::process::id()));
        let path=base.join("state.json");
        state.save_atomic(&path).unwrap();
        let loaded=WalletScanState::load_from_path(&path).unwrap();
        assert_eq!(loaded.balance_summary().unwrap().unspent,123);
        let mut invalid=loaded.clone();
        invalid.outputs.get_mut(&id(4,0)).unwrap().block_hash=[9;32];
        assert_eq!(invalid.validate_persisted_state(),Err(TrackingError::InvalidPersistedState));
        let _=fs::remove_dir_all(&base);
    }

    #[test]
    fn reorg_removes_noncanonical_records_and_restores_prior_spend_status() {
        let mut state=WalletScanState::default();
        let b10=block(10,1,0); let b11=block(11,2,1); let b11_alt=block(11,9,1);
        state.reconcile_chain(&[b10.clone(),b11.clone()]).unwrap();
        let output=id(8,0); state.record_output(output.clone(),&b10,100).unwrap();
        state.assign_key_image(&output,[0xaa;32]).unwrap();
        state.record_transaction(TransactionRecord { txid:[7;32], block_height:11, block_hash:b11.hash, direction:Direction::Outgoing, amount:100, fee:Some(1) }).unwrap();
        state.apply_spend_inputs([7;32],&ParsedTxPrefix { version:2, unlock_time:0, input_count:1,
            inputs:vec![TxInput::ToKey { amount:0, relative_offsets:vec![1], key_image:[0xaa;32] }], outputs:vec![], extra:vec![], prefix_bytes:0 });
        state.reconcile_chain(&[b10,b11_alt]).unwrap();
        assert_eq!(state.transactions().count(),0);
        assert_eq!(state.outputs().next().unwrap().spent_by_txid,None);
        assert_eq!(state.balance_summary().unwrap().unspent,100);
    }
}
