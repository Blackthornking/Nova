#![allow(clippy::needless_return)]

use axum::{
    body::Body,
    extract::{DefaultBodyLimit, Query, State},
    http::{header, HeaderMap, HeaderValue, Request, StatusCode},
    middleware::{self, Next},
    response::{IntoResponse, Response},
    routing::{get, post},
    Json, Router,
};
use rand::{rngs::OsRng, RngCore};
use reqwest::Client;
use serde_json::{json, Map, Number, Value};
use std::{
    collections::HashMap,
    net::TcpListener as StdTcpListener,
    path::{Path, PathBuf},
    process::{Child, Command, Stdio},
    sync::{
        atomic::{AtomicBool, AtomicU32, Ordering},
        Arc, Mutex, OnceLock, RwLock,
    },
    thread,
    time::Duration,
};
use tokio::{net::TcpListener, sync::watch, time::timeout};
use tower_http::cors::CorsLayer;

const UI_PORT: u16 = 8765;
const RPC_PORT: u16 = 18082;
const DEFAULT_DAEMON: &str = "node.nerva.one:17566";
const MAX_BODY: usize = 128 * 1024;
const MAX_RPC_RESPONSE: usize = 2 * 1024 * 1024;

static APP: OnceLock<Arc<AppState>> = OnceLock::new();
static STARTED: AtomicBool = AtomicBool::new(false);
static SHUTDOWN: OnceLock<watch::Sender<bool>> = OnceLock::new();

#[derive(Clone)]
struct RpcConfig {
    url: String,
    username: String,
    password: String,
}

struct AppState {
    token: String,
    rpc: RwLock<RpcConfig>,
    daemon: RwLock<String>,
    connected: AtomicBool,
    rpc_version: RwLock<Option<String>>,
    wallet_binary: PathBuf,
    wallet_dir: PathBuf,
    engine_dir: PathBuf,
    child: Mutex<Option<Child>>,
    digest_nonce_count: AtomicU32,
    client: Client,
}

impl AppState {
    fn new(binary: PathBuf, wallet_dir: PathBuf, daemon: String, token: String) -> Self {
        let mut password_bytes = [0u8; 32];
        OsRng.fill_bytes(&mut password_bytes);
        let password = hex::encode(password_bytes);
        let engine_dir = binary.parent().unwrap_or(Path::new(".")).to_path_buf();
        Self {
            token,
            rpc: RwLock::new(RpcConfig {
                url: format!("http://127.0.0.1:{RPC_PORT}"),
                username: "nerva".to_string(),
                password,
            }),
            daemon: RwLock::new(daemon),
            connected: AtomicBool::new(false),
            rpc_version: RwLock::new(None),
            wallet_binary: binary,
            wallet_dir,
            engine_dir,
            child: Mutex::new(None),
            digest_nonce_count: AtomicU32::new(0),
            client: Client::builder()
                .connect_timeout(Duration::from_secs(5))
                .timeout(Duration::from_secs(125))
                .redirect(reqwest::redirect::Policy::none())
                .build()
                .expect("reqwest client construction is infallible with fixed options"),
        }
    }

    fn start_engine(&self) -> Result<(), String> {
        if !self.wallet_binary.is_file() {
            return Err(format!("Nerva wallet engine not found at {}", self.wallet_binary.display()));
        }
        let mut guard = self.child.lock().map_err(|_| "Engine process lock failed".to_string())?;
        let existing_status = match guard.as_mut() { Some(child) => Some(child.try_wait()), None => None };
        match existing_status {
            Some(Ok(None)) => {
                // Restarting after a daemon configuration change takes the child out deliberately below.
                return Ok(());
            }
            Some(Ok(Some(_))) | Some(Err(_)) => { let _ = guard.take(); }
            None => {}
        }
        let cfg = self.rpc.read().map_err(|_| "RPC config lock failed".to_string())?.clone();
        let daemon = self.daemon.read().map_err(|_| "Daemon config lock failed".to_string())?.clone();
        std::fs::create_dir_all(&self.wallet_dir).map_err(|e| format!("Cannot create private wallet directory: {e}"))?;
        let login = format!("{}:{}", cfg.username, cfg.password);
        let mut child = Command::new("/system/bin/linker64")
            .arg(&self.wallet_binary)
            .arg("--wallet-dir").arg(&self.wallet_dir)
            .arg("--daemon-address").arg(&daemon)
            .arg("--rpc-bind-ip").arg("127.0.0.1")
            .arg("--rpc-bind-port").arg(RPC_PORT.to_string())
            .arg("--rpc-login").arg(login)
            .env("LD_LIBRARY_PATH", &self.engine_dir)
            .stdin(Stdio::null())
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .spawn()
            .map_err(|e| format!("Could not start the Nerva wallet engine: {e}. Confirm the ARM64 engine is installed."))?;
        // Give the process a chance to fail immediately (wrong ABI / missing runtime library).
        std::thread::sleep(Duration::from_millis(120));
        match child.try_wait() {
            Ok(Some(status)) => return Err(format!("Nerva wallet engine exited during startup ({status}). The engine bundle may be incompatible with this Android version.")),
            Err(e) => return Err(format!("Could not check Nerva engine startup: {e}")),
            Ok(None) => {}
        }
        *guard = Some(child);
        self.connected.store(false, Ordering::SeqCst);
        if let Ok(mut v) = self.rpc_version.write() { *v = None; }
        Ok(())
    }

    async fn restart_engine(&self, new_daemon: String) -> Result<(), String> {
        validate_daemon(&new_daemon)?;
        // Flush an open wallet before stopping the native process. A forced process
        // restart without store can lose its latest cached scan/transaction state.
        let _ = timeout(Duration::from_secs(30), rpc_call(self, "store", json!({}))).await;
        {
            let mut child_guard = self.child.lock().map_err(|_| "Engine process lock failed".to_string())?;
            if let Some(mut child) = child_guard.take() {
                let _ = child.kill();
                let _ = child.wait();
            }
        }
        *self.daemon.write().map_err(|_| "Daemon config lock failed".to_string())? = new_daemon.clone();
        self.start_engine()?;
        let path = self.wallet_dir.join("daemon-address.txt");
        let tmp = self.wallet_dir.join("daemon-address.txt.tmp");
        std::fs::write(&tmp, format!("{}\n", new_daemon)).map_err(|e| format!("Could not save daemon settings: {e}"))?;
        std::fs::rename(&tmp, &path).map_err(|e| format!("Could not save daemon settings: {e}"))?;
        Ok(())
    }

    fn stop_engine(&self) {
        if let Ok(mut guard) = self.child.lock() {
            if let Some(mut child) = guard.take() {
                let _ = child.kill();
                let _ = child.wait();
            }
        }
        self.connected.store(false, Ordering::SeqCst);
    }
}

fn validate_daemon(address: &str) -> Result<(), String> {
    let s = address.trim();
    if s.is_empty() || s.len() > 260 || s.contains('/') || s.contains('@') || s.contains(' ')
        || s.contains('\\') || s.contains('?') || s.contains('#') || s.contains('\n') || s.contains('\r') {
        return Err("Enter a daemon host and port, for example node.nerva.one:17566".into());
    }
    let (host, port) = s.rsplit_once(':').ok_or("Daemon address must include a port, e.g. node.nerva.one:17566")?;
    if host.is_empty() || host.len() > 253 || host.starts_with('.') || host.ends_with('.') || host.contains("..") {
        return Err("Daemon hostname is invalid.".into());
    }
    if !host.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'.' || b == b'-') {
        return Err("Daemon hostname contains unsupported characters. IPv4/hostname and port are supported.".into());
    }
    let p: u16 = port.parse().map_err(|_| "Daemon port must be between 1 and 65535")?;
    if p == 0 { return Err("Daemon port must be between 1 and 65535".into()); }
    Ok(())
}

fn allowed_method(method: &str) -> bool {
    matches!(method,
        "get_version" | "get_height" | "get_address" | "get_balance" | "get_transfers" |
        "get_transfer_by_txid" | "get_address_book" | "get_accounts" | "get_languages" |
        "create_wallet" | "open_wallet" | "restore_wallet_from_seed" | "close_wallet" |
        "store" | "refresh" | "transfer" | "query_key" | "validate_address" | "make_uri" |
        "get_tx_key" | "check_tx_key" | "relay_tx")
}

fn atomic_safe(v: Value, key: &str) -> Value {
    const ATOMIC_KEYS: &[&str] = &["balance", "unlocked_balance", "amount", "fee", "reward", "amount_in", "amount_out", "locked_amount", "dust", "dust_threshold", "total_amount"];
    match v {
        Value::Object(obj) => Value::Object(obj.into_iter().map(|(k, x)| {
            let value = if let Some(i) = x.as_u64().filter(|_| ATOMIC_KEYS.contains(&k.as_str())) {
                Value::String(i.to_string())
            } else { atomic_safe(x, &k) };
            (k, value)
        }).collect()),
        Value::Array(items) => Value::Array(items.into_iter().map(|x| atomic_safe(x, key)).collect()),
        other => other,
    }
}

fn normalise_transfer_params(params: &mut Value) -> Result<(), String> {
    if let Some(destinations) = params.get_mut("destinations").and_then(Value::as_array_mut) {
        for dest in destinations {
            if let Some(amount) = dest.get("amount").cloned() {
                if let Some(s) = amount.as_str() {
                    if s.is_empty() || !s.bytes().all(|b| b.is_ascii_digit()) { return Err("Transfer amount must be a positive integer number of atomic units.".into()); }
                    let n: u64 = s.parse().map_err(|_| "Transfer amount is outside the supported integer range")?;
                    if n == 0 { return Err("Transfer amount must be positive.".into()); }
                    if let Some(obj) = dest.as_object_mut() { obj.insert("amount".into(), Value::Number(Number::from(n))); }
                }
            }
        }
    }
    Ok(())
}

fn digest_fields(challenge: &str) -> Result<HashMap<String, String>, String> {
    let rest = challenge.trim().strip_prefix("Digest ").ok_or("Wallet RPC did not offer HTTP Digest authentication")?;
    let bytes = rest.as_bytes();
    let mut i = 0;
    let mut out = HashMap::new();
    while i < bytes.len() {
        while i < bytes.len() && (bytes[i] == b',' || bytes[i].is_ascii_whitespace()) { i += 1; }
        let key_start = i;
        while i < bytes.len() && bytes[i] != b'=' && bytes[i] != b',' { i += 1; }
        if i >= bytes.len() || bytes[i] != b'=' { break; }
        let key = rest[key_start..i].trim().to_ascii_lowercase();
        i += 1;
        while i < bytes.len() && bytes[i].is_ascii_whitespace() { i += 1; }
        let value = if i < bytes.len() && bytes[i] == b'"' {
            i += 1; let mut value = String::new();
            while i < bytes.len() {
                if bytes[i] == b'\\' && i + 1 < bytes.len() { value.push(bytes[i + 1] as char); i += 2; }
                else if bytes[i] == b'"' { i += 1; break; }
                else { value.push(bytes[i] as char); i += 1; }
            }
            value
        } else {
            let start = i;
            while i < bytes.len() && bytes[i] != b',' { i += 1; }
            rest[start..i].trim().to_string()
        };
        if !key.is_empty() { out.insert(key, value); }
        while i < bytes.len() && bytes[i] != b',' { i += 1; }
    }
    Ok(out)
}

fn md5_hex(s: &str) -> String { format!("{:x}", md5::compute(s.as_bytes())) }

async fn rpc_call(state: &AppState, method: &str, params: Value) -> Result<Value, String> {
    if !allowed_method(method) { return Err("This wallet operation is not enabled.".into()); }
    let mut params = if params.is_object() { params } else { return Err("RPC parameters must be a JSON object.".into()); };
    if method == "transfer" { normalise_transfer_params(&mut params)?; }
    let cfg = state.rpc.read().map_err(|_| "RPC config unavailable".to_string())?.clone();
    let endpoint = format!("{}/json_rpc", cfg.url.trim_end_matches('/'));
    let body = json!({"jsonrpc":"2.0","id":"nerva-simple-wallet","method":method,"params":params});
    let first = timeout(Duration::from_secs(if matches!(method, "refresh"|"restore_wallet_from_seed"|"create_wallet"|"open_wallet") { 120 } else { 45 }),
        state.client.post(&endpoint).header(header::CONTENT_TYPE, "application/json").json(&body).send())
        .await.map_err(|_| "Wallet RPC timed out. Check the daemon and retry.".to_string())?
        .map_err(|_| "Cannot reach local Nerva wallet RPC. Check whether the wallet engine is running.".to_string())?;
    let response = if first.status() == StatusCode::UNAUTHORIZED {
        let challenge = first.headers().get(header::WWW_AUTHENTICATE).and_then(|x| x.to_str().ok()).ok_or("Wallet RPC authentication challenge missing")?;
        let f = digest_fields(challenge)?;
        let realm = f.get("realm").ok_or("Digest realm missing")?;
        let nonce = f.get("nonce").ok_or("Digest nonce missing")?;
        let qop = f.get("qop").map(|s| s.split(',').map(str::trim).any(|q| q == "auth")).unwrap_or(false);
        let algorithm = f.get("algorithm").map(|x| x.as_str()).unwrap_or("MD5");
        if !qop || !algorithm.eq_ignore_ascii_case("MD5") { return Err("Wallet RPC Digest settings are not supported (expected MD5 with qop=auth).".into()); }
        let uri = "/json_rpc";
        let mut bytes = [0u8; 16]; OsRng.fill_bytes(&mut bytes); let cnonce = hex::encode(bytes);
        // Use a monotonic nonce count rather than replaying nc=00000001 on every
        // request. This remains safe when the RPC server keeps a nonce alive.
        let nc_value = state.digest_nonce_count.fetch_add(1, Ordering::Relaxed).wrapping_add(1);
        let nc = format!("{nc_value:08x}");
        let ha1 = md5_hex(&format!("{}:{}:{}", cfg.username, realm, cfg.password));
        let ha2 = md5_hex(&format!("POST:{}", uri));
        let response_hash = md5_hex(&format!("{}:{}:{}:{}:auth:{}", ha1, nonce, nc, cnonce, ha2));
        let mut auth = format!("Digest username=\"{}\", realm=\"{}\", nonce=\"{}\", uri=\"{}\", algorithm=MD5, response=\"{}\", qop=auth, nc={}, cnonce=\"{}\"",
            quoted(&cfg.username), quoted(realm), quoted(nonce), uri, response_hash, nc, cnonce);
        if let Some(opaque) = f.get("opaque") { auth.push_str(&format!(", opaque=\"{}\"", quoted(opaque))); }
        timeout(Duration::from_secs(125), state.client.post(&endpoint).header(header::AUTHORIZATION, auth).header(header::CONTENT_TYPE, "application/json").json(&body).send())
            .await.map_err(|_| "Wallet RPC timed out.".to_string())?
            .map_err(|_| "Cannot reach local Nerva wallet RPC.".to_string())?
    } else { first };
    if !response.status().is_success() {
        return Err(match response.status() { StatusCode::UNAUTHORIZED => "Wallet RPC authentication failed.".to_string(), StatusCode::NOT_FOUND => "Wallet RPC path was not found.".to_string(), s => format!("Wallet RPC returned HTTP {s}.") });
    }
    let bytes = response.bytes().await.map_err(|_| "Could not read the wallet RPC response.".to_string())?;
    if bytes.len() > MAX_RPC_RESPONSE { return Err("Wallet RPC response exceeded its size limit.".into()); }
    let data: Value = serde_json::from_slice(&bytes).map_err(|_| "Wallet RPC returned invalid JSON.".to_string())?;
    if let Some(error) = data.get("error").filter(|value| !value.is_null()) {
        let message = error.get("message").and_then(Value::as_str).unwrap_or("Nerva wallet RPC returned an error");
        return Err(message.chars().take(500).collect());
    }
    Ok(atomic_safe(data.get("result").cloned().unwrap_or_else(|| json!({})), ""))
}

fn quoted(s: &str) -> String { s.replace('\\', "\\\\").replace('"', "\\\"") }

fn json_response(status: StatusCode, body: Value) -> Response {
    let mut response = (status, Json(body)).into_response();
    security_headers(response.headers_mut());
    response
}
fn security_headers(headers: &mut HeaderMap) {
    headers.insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
    headers.insert(axum::http::HeaderName::from_static("x-content-type-options"), HeaderValue::from_static("nosniff"));
    headers.insert(axum::http::HeaderName::from_static("referrer-policy"), HeaderValue::from_static("no-referrer"));
    headers.insert(axum::http::HeaderName::from_static("x-frame-options"), HeaderValue::from_static("DENY"));
    headers.insert(axum::http::HeaderName::from_static("content-security-policy"), HeaderValue::from_static("default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'"));
    // Chromium-based Android WebViews may send a Private Network Access preflight
    // when the appassets origin calls the loopback API; CORS still limits origin.
    headers.insert(axum::http::HeaderName::from_static("access-control-allow-private-network"), HeaderValue::from_static("true"));
}

async fn host_guard(req: Request<Body>, next: Next) -> Response {
    let host = req.headers().get(header::HOST).and_then(|x| x.to_str().ok()).unwrap_or("").to_ascii_lowercase();
    if host != format!("127.0.0.1:{UI_PORT}") && host != format!("localhost:{UI_PORT}") {
        return json_response(StatusCode::FORBIDDEN, json!({"ok":false,"error":"Local host check failed."}));
    }
    next.run(req).await
}

// Apply security headers outside CORS as well, because CORS can short-circuit a
// browser preflight without calling the route middleware. Chromium WebView's
// loopback Private Network Access preflight needs the allow-private-network header.
async fn security_headers_layer(req: Request<Body>, next: Next) -> Response {
    let mut response = next.run(req).await;
    security_headers(response.headers_mut());
    response
}

fn constant_time_equal(a: &[u8], b: &[u8]) -> bool {
    if a.len() != b.len() { return false; }
    a.iter().zip(b.iter()).fold(0u8, |acc, (x, y)| acc | (x ^ y)) == 0
}

fn require_session(state: &AppState, headers: &HeaderMap) -> Result<(), Response> {
    let token = headers.get("x-nerva-session").and_then(|x| x.to_str().ok()).unwrap_or("");
    if !constant_time_equal(token.as_bytes(), state.token.as_bytes()) {
        return Err(json_response(StatusCode::FORBIDDEN, json!({"ok":false,"error":"Session check failed. Reload the wallet."})));
    }
    if let Some(origin) = headers.get(header::ORIGIN).and_then(|x| x.to_str().ok()) {
        if origin != "https://appassets.androidplatform.net" && origin != format!("http://127.0.0.1:{UI_PORT}") && origin != format!("http://localhost:{UI_PORT}") {
            return Err(json_response(StatusCode::FORBIDDEN, json!({"ok":false,"error":"Cross-origin requests are not allowed."})));
        }
    }
    Ok(())
}

async fn status(State(state): State<Arc<AppState>>) -> Json<Value> {
    Json(json!({"ok":true,"connected":state.connected.load(Ordering::SeqCst),"url":format!("http://127.0.0.1:{RPC_PORT}"),"username":"nerva","version":state.rpc_version.read().ok().and_then(|v| v.clone()),"connected_at":null}))
}
async fn connect(State(state): State<Arc<AppState>>, headers: HeaderMap) -> Response {
    if let Err(r) = require_session(&state, &headers) { return r; }
    let mut last_error = "Wallet engine is starting; try again shortly.".to_string();
    for attempt in 0..20 {
        match rpc_call(&state, "get_version", json!({})).await {
            Ok(version) => {
                let text = version.get("version").map(|v| v.to_string().trim_matches('"').to_string()).unwrap_or_else(|| "connected".into());
                if let Ok(mut v) = state.rpc_version.write() { *v = Some(text.clone()); }
                state.connected.store(true, Ordering::SeqCst);
                return json_response(StatusCode::OK, json!({"ok":true,"version":text,"message":"Connected to the local Nerva wallet engine."}));
            },
            Err(e) => {
                last_error = e;
                if attempt < 19 { tokio::time::sleep(Duration::from_millis(350)).await; }
            }
        }
    }
    json_response(StatusCode::BAD_GATEWAY, json!({"ok":false,"error":last_error}))
}
async fn disconnect(State(state): State<Arc<AppState>>, headers: HeaderMap) -> Response {
    if let Err(r) = require_session(&state, &headers) { return r; }
    state.connected.store(false, Ordering::SeqCst);
    json_response(StatusCode::OK, json!({"ok":true}))
}
#[derive(serde::Deserialize)]
struct CallRequest { method: String, #[serde(default = "empty_obj")] params: Value }
fn empty_obj() -> Value { json!({}) }
async fn call(State(state): State<Arc<AppState>>, headers: HeaderMap, Json(body): Json<Value>) -> Response {
    if let Err(r) = require_session(&state, &headers) { return r; }
    let request: CallRequest = match serde_json::from_value(body) { Ok(x) => x, Err(_) => return json_response(StatusCode::BAD_REQUEST, json!({"ok":false,"error":"Invalid RPC method or parameters."})) };
    if !state.connected.load(Ordering::SeqCst) { return json_response(StatusCode::BAD_REQUEST, json!({"ok":false,"error":"Connect to the wallet engine first."})); }
    match rpc_call(&state, &request.method, request.params).await {
        Ok(result) => json_response(StatusCode::OK, json!({"ok":true,"result":result})),
        Err(e) => json_response(StatusCode::BAD_GATEWAY, json!({"ok":false,"error":e})),
    }
}
async fn network(State(state): State<Arc<AppState>>) -> Json<Value> {
    let value = timeout(Duration::from_secs(7), state.client.post("https://api.nerva.one/daemon/get_info/").json(&json!({})).send()).await;
    let result = match value {
        Ok(Ok(resp)) if resp.status().is_success() => {
            match resp.json::<Value>().await {
                Ok(v) => {
                    let source = v.get("result").unwrap_or(&v);
                    let mut out = Map::new();
                    for key in ["height", "target_height", "difficulty", "outgoing_connections_count", "incoming_connections_count", "status", "version"] {
                        if let Some(val) = source.get(key) { out.insert(key.to_string(), val.clone()); }
                    }
                    out.insert("available".into(), Value::Bool(!out.is_empty())); Value::Object(out)
                },
                _ => json!({"available":false,"message":"Network status unavailable."}),
            }
        },
        _ => json!({"available":false,"message":"Network status unavailable. The wallet may still sync through its daemon."}),
    };
    Json(json!({"ok":true,"network":result}))
}
#[derive(serde::Deserialize)]
struct QrQuery { text: String }
async fn qr(Query(q): Query<QrQuery>) -> Response {
    if q.text.is_empty() || q.text.len() > 256 { return json_response(StatusCode::BAD_REQUEST, json!({"ok":false,"error":"Invalid QR content."})); }
    match qrcode::QrCode::new(q.text.as_bytes()) {
        Ok(code) => {
            let svg = code.render::<qrcode::render::svg::Color>().min_dimensions(210, 210).build();
            let mut r = (StatusCode::OK, [(header::CONTENT_TYPE, "image/svg+xml; charset=utf-8")], svg).into_response(); security_headers(r.headers_mut()); r
        },
        Err(_) => json_response(StatusCode::BAD_REQUEST, json!({"ok":false,"error":"Could not encode QR content."})),
    }
}
#[derive(serde::Deserialize)]
struct AddressCheckRequest { address: String }
async fn validate_address_local(State(state): State<Arc<AppState>>, headers: HeaderMap, Json(body): Json<AddressCheckRequest>) -> Response {
    // Address validation is now executed by the Rust Nerva core, without a daemon round-trip.
    // It does not imply the address is controlled by the wallet or that a payment is confirmed.
    if body.address.trim().is_empty() || body.address.len() > 256 {
        return json_response(StatusCode::BAD_REQUEST, json!({"ok":false,"error":"Enter a Nerva address."}));
    }
    if let Err(r) = require_session(&state, &headers) { return r; }
    match nerva_core::address::Address::decode(body.address.trim()) {
        Ok(address) => {
            let kind = match address.kind {
                nerva_core::address::AddressKind::Standard => "standard",
                nerva_core::address::AddressKind::Integrated => "integrated",
                nerva_core::address::AddressKind::Subaddress => "subaddress",
            };
            json_response(StatusCode::OK, json!({"ok":true,"valid":true,"kind":kind,"prefix":address.prefix}))
        },
        Err(_) => json_response(StatusCode::OK, json!({"ok":true,"valid":false,"message":"Address is invalid for the supported Nerva mainnet formats."})),
    }
}

#[derive(serde::Deserialize)]
struct AmountParseRequest { amount: String }
async fn parse_amount_local(State(state): State<Arc<AppState>>, headers: HeaderMap, Json(body): Json<AmountParseRequest>) -> Response {
    if let Err(r) = require_session(&state, &headers) { return r; }
    match nerva_core::amount::Amount::parse_xnv(&body.amount) {
        Ok(amount) => json_response(StatusCode::OK, json!({"ok":true,"atomic_units":amount.atomic().to_string(),"formatted":amount.format_xnv()})),
        Err(e) => json_response(StatusCode::BAD_REQUEST, json!({"ok":false,"error":e.to_string()})),
    }
}

async fn daemon_get(State(state): State<Arc<AppState>>) -> Json<Value> {
    Json(json!({"ok":true,"address":state.daemon.read().map(|d| d.clone()).unwrap_or_else(|_| DEFAULT_DAEMON.to_string())}))
}
async fn daemon_set(State(state): State<Arc<AppState>>, headers: HeaderMap, Json(body): Json<Value>) -> Response {
    if let Err(r) = require_session(&state, &headers) { return r; }
    let address = body.get("address").and_then(Value::as_str).unwrap_or("").trim().to_string();
    if let Err(e) = validate_daemon(&address) { return json_response(StatusCode::BAD_REQUEST, json!({"ok":false,"error":e})); }
    match state.restart_engine(address.clone()).await {
        Ok(()) => json_response(StatusCode::OK, json!({"ok":true,"address":address,"message":"Daemon changed. Reconnect to the wallet engine."})),
        Err(e) => json_response(StatusCode::BAD_GATEWAY, json!({"ok":false,"error":e})),
    }
}
async fn serve(state: Arc<AppState>, listener: StdTcpListener, mut stop_rx: watch::Receiver<bool>) -> Result<(), String> {
    listener.set_nonblocking(true).map_err(|e| e.to_string())?;
    let listener = TcpListener::from_std(listener).map_err(|e| e.to_string())?;
    let app = Router::new()
        .route("/api/status", get(status))
        .route("/api/network", get(network))
        .route("/api/qr", get(qr))
        .route("/api/daemon", get(daemon_get).post(daemon_set))
        .route("/api/connect", post(connect))
        .route("/api/disconnect", post(disconnect))
        .route("/api/call", post(call))
        .route("/api/validate-address", post(validate_address_local))
        .route("/api/amount/parse", post(parse_amount_local))
        .layer(DefaultBodyLimit::max(MAX_BODY))
        .layer(CorsLayer::new()
            .allow_origin(HeaderValue::from_static("https://appassets.androidplatform.net"))
            .allow_methods([axum::http::Method::GET, axum::http::Method::POST])
            .allow_headers([header::CONTENT_TYPE, axum::http::HeaderName::from_static("x-nerva-session")]))
        .route_layer(middleware::from_fn(host_guard))
        .layer(middleware::from_fn(security_headers_layer))
        .with_state(state);
    axum::serve(listener, app).with_graceful_shutdown(async move { let _ = stop_rx.changed().await; }).await.map_err(|e| e.to_string())
}

fn start_server(binary: PathBuf, wallet_dir: PathBuf, daemon: String, session_token: String) -> Result<(), String> {
    validate_daemon(&daemon)?;
    if session_token.len() < 64 || !session_token.bytes().all(|b| b.is_ascii_hexdigit()) {
        return Err("Invalid session token supplied by Android host".into());
    }
    if STARTED.swap(true, Ordering::SeqCst) { return Ok(()); }
    let listener = match StdTcpListener::bind(("127.0.0.1", UI_PORT)) {
        Ok(x) => x,
        Err(e) => { STARTED.store(false, Ordering::SeqCst); return Err(format!("Could not bind local wallet service: {e}")); }
    };
    let selected_daemon = std::fs::read_to_string(wallet_dir.join("daemon-address.txt"))
        .ok().map(|v| v.trim().to_string()).filter(|v| validate_daemon(v).is_ok()).unwrap_or(daemon);
    let state = Arc::new(AppState::new(binary, wallet_dir, selected_daemon, session_token));
    if let Err(e) = state.start_engine() { STARTED.store(false, Ordering::SeqCst); return Err(e); }
    let (tx, rx) = watch::channel(false);
    let _ = SHUTDOWN.set(tx);
    if APP.set(state.clone()).is_err() { state.stop_engine(); STARTED.store(false, Ordering::SeqCst); return Err("Wallet service was already initialised in this process.".into()); }
    thread::spawn(move || {
        let result = tokio::runtime::Builder::new_multi_thread().enable_all().build()
            .map_err(|e| e.to_string())
            .and_then(|rt| rt.block_on(serve(state.clone(), listener, rx)));
        if let Err(e) = result { eprintln!("Nerva local service stopped: {e}"); }
        state.stop_engine();
        STARTED.store(false, Ordering::SeqCst);
    });
    Ok(())
}

#[no_mangle]
pub extern "system" fn Java_com_nervasimple_MainActivity_startNativeServer(
    mut env: jni::JNIEnv<'_>,
    _this: jni::objects::JObject<'_>,
    binary_path: jni::objects::JString<'_>,
    wallet_dir: jni::objects::JString<'_>,
    daemon: jni::objects::JString<'_>,
    session_token: jni::objects::JString<'_>,
) -> jni::sys::jint {
    let get = |env: &mut jni::JNIEnv<'_>, s: jni::objects::JString<'_>| -> Result<String, String> {
        env.get_string(&s).map(|x| x.into()).map_err(|e| e.to_string())
    };
    let binary = match get(&mut env, binary_path) { Ok(v) => v, Err(_) => return -1 };
    let wallet = match get(&mut env, wallet_dir) { Ok(v) => v, Err(_) => return -1 };
    let daemon = match get(&mut env, daemon) { Ok(v) => v, Err(_) => return -1 };
    let token = match get(&mut env, session_token) { Ok(v) => v, Err(_) => return -1 };
    match start_server(PathBuf::from(binary), PathBuf::from(wallet), daemon, token) {
        Ok(()) => 0,
        Err(_) => -2,
    }
}

#[no_mangle]
pub extern "system" fn Java_com_nervasimple_MainActivity_stopNativeServer(
    _env: jni::JNIEnv<'_>,
    _this: jni::objects::JObject<'_>,
) {
    if let Some(tx) = SHUTDOWN.get() { let _ = tx.send(true); }
    if let Some(state) = APP.get() { state.stop_engine(); }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn allows_only_safe_wallet_methods() {
        assert!(allowed_method("transfer"));
        assert!(allowed_method("relay_tx"));
        assert!(!allowed_method("start_mining"));
        assert!(!allowed_method("stop_mining"));
        assert!(!allowed_method("save_bc"));
    }
    #[test]
    fn daemon_validation_rejects_injection() {
        assert!(validate_daemon("node.nerva.one:17566").is_ok());
        assert!(validate_daemon("127.0.0.1:17566").is_ok());
        assert!(validate_daemon("https://node.nerva.one:17566").is_err());
        assert!(validate_daemon("node.nerva.one:17566 --rpc-login bad").is_err());
        assert!(validate_daemon("node.nerva.one:0").is_err());
    }
    #[test]
    fn digest_challenge_parses_quoted_qop() {
        let fields = digest_fields("Digest realm=\"nerva\", nonce=\"abc\", qop=\"auth,auth-int\", algorithm=MD5").unwrap();
        assert_eq!(fields.get("realm").unwrap(), "nerva");
        assert_eq!(fields.get("nonce").unwrap(), "abc");
        assert_eq!(fields.get("qop").unwrap(), "auth,auth-int");
    }
    #[test]
    fn digest_response_matches_rfc_2617_example() {
        let ha1 = md5_hex("Mufasa:testrealm@host.com:Circle Of Life");
        let ha2 = md5_hex("GET:/dir/index.html");
        let response = md5_hex(&format!("{}:{}:{}:{}:auth:{}", ha1, "dcd98b7102dd2f0e8b11d0f600bfb0c093", "00000001", "0a4f113b", ha2));
        assert_eq!(response, "6629fae49393a05397450978507c4ef1");
    }
    #[test]
    fn session_comparison_detects_mismatch() {
        assert!(constant_time_equal(b"abcdef", b"abcdef"));
        assert!(!constant_time_equal(b"abcdef", b"abcdeg"));
        assert!(!constant_time_equal(b"abc", b"abcd"));
    }
    #[test]
    fn strings_atomic_amounts_become_rpc_integers() {
        let mut p = json!({"destinations":[{"address":"x","amount":"1230000000000"}]});
        normalise_transfer_params(&mut p).unwrap();
        assert_eq!(p["destinations"][0]["amount"].as_u64().unwrap(), 1230000000000);
    }
}
