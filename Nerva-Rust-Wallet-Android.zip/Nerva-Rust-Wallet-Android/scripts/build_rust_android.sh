#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

command -v cargo >/dev/null 2>&1 || { echo "Rust is required. Install rustup + Cargo from https://rustup.rs/" >&2; exit 2; }
command -v rustup >/dev/null 2>&1 || { echo "rustup is required to install the Android Rust target." >&2; exit 2; }

rustup target add aarch64-linux-android
if ! command -v cargo-ndk >/dev/null 2>&1; then
  cargo install cargo-ndk --locked
fi
if [[ -z "${ANDROID_NDK_HOME:-}" && -z "${ANDROID_NDK_ROOT:-}" && -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "Set ANDROID_NDK_HOME or ANDROID_SDK_ROOT after installing Android NDK (Side by side)." >&2
  exit 2
fi
mkdir -p android/app/src/main/jniLibs
cargo ndk -t arm64-v8a -o android/app/src/main/jniLibs build --release

test -s android/app/src/main/jniLibs/arm64-v8a/libnerva_rust.so || { echo "Rust JNI library output is missing." >&2; exit 4; }
echo "Built libnerva_rust.so for Android ARM64."
