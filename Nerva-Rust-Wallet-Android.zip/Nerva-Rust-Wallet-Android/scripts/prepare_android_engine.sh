#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/android/app/src/main/assets/engine"
VERSION="v0.3.0.0"
ARCHIVE="nerva-android-armv8-v0.3.0.0.tar.bz2"
URL="https://github.com/nerva-project/nerva/releases/download/v0.3.0.0/$ARCHIVE"
EXPECTED_SHA256="905716a117a1575c67925b929b2f2c15cafac0ff94394b4c00610448e522e401"
CACHE="$ROOT/.build-cache"
mkdir -p "$CACHE" "$OUT"

if [[ -x "$OUT/nerva-wallet-rpc" && -f "$OUT/ENGINE-METADATA.txt" ]] && grep -Fq "$EXPECTED_SHA256" "$OUT/ENGINE-METADATA.txt"; then
  echo "Nerva wallet-RPC engine already prepared from the pinned official release."
  exit 0
fi

FILE="$CACHE/$ARCHIVE"
if [[ ! -f "$FILE" ]]; then
  echo "Downloading official Nerva $VERSION Android ARM64 release..."
  if command -v curl >/dev/null 2>&1; then
    curl --fail --location --retry 3 --output "$FILE.part" "$URL"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$FILE.part" "$URL"
  else
    echo "Install curl or wget to download the official Nerva engine." >&2; exit 2
  fi
  mv "$FILE.part" "$FILE"
fi

if command -v sha256sum >/dev/null 2>&1; then
  ACTUAL="$(sha256sum "$FILE" | awk '{print $1}')"
elif command -v shasum >/dev/null 2>&1; then
  ACTUAL="$(shasum -a 256 "$FILE" | awk '{print $1}')"
else
  echo "Install sha256sum or shasum to verify the Nerva release." >&2; exit 2
fi
if [[ "$ACTUAL" != "$EXPECTED_SHA256" ]]; then
  rm -f "$FILE"
  echo "SHA-256 mismatch for official Nerva release. Expected $EXPECTED_SHA256, got $ACTUAL" >&2
  exit 3
fi

tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
mkdir -p "$tmp/unpacked"
tar -xjf "$FILE" -C "$tmp/unpacked"
RPC="$(find "$tmp/unpacked" -type f -name 'nerva-wallet-rpc' -print -quit)"
if [[ -z "$RPC" ]]; then
  echo "The official archive did not contain nerva-wallet-rpc; refusing to substitute another binary." >&2
  exit 4
fi
# Keep the original layout, plus a canonical entry point and libraries near it for Android's linker.
cp -a "$tmp/unpacked/." "$OUT/"
cp "$RPC" "$OUT/nerva-wallet-rpc"
find "$tmp/unpacked" -type f \( -name '*.so' -o -name '*.so.*' \) -exec cp -f '{}' "$OUT/" \;
chmod 700 "$OUT/nerva-wallet-rpc"
cat > "$OUT/ENGINE-METADATA.txt" <<META
Nerva wallet RPC binary source: official nerva-project/nerva $VERSION Android ARM v8 release.
Release archive: $ARCHIVE
Release archive SHA-256: $EXPECTED_SHA256
Verified before extraction by scripts/prepare_android_engine.sh.
Do not replace this executable with unverified third-party binaries.
META

echo "Verified Nerva wallet engine prepared at $OUT/nerva-wallet-rpc"
