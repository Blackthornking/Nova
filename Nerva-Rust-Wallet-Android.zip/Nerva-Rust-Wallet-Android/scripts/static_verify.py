#!/usr/bin/env python3
"""Offline source sanity checks; these do not replace compiling or testing a real APK."""
from pathlib import Path
import hashlib
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
errors = []

def need(condition, message):
    if not condition:
        errors.append(message)

rust = (ROOT / "rust/src/lib.rs").read_text("utf-8")
js = (ROOT / "web/app.js").read_text("utf-8")
html = (ROOT / "web/index.html").read_text("utf-8")
activity = (ROOT / "android/app/src/main/java/com/nervasimple/MainActivity.kt").read_text("utf-8")
gradle = (ROOT / "android/app/build.gradle.kts").read_text("utf-8")
prep = (ROOT / "scripts/prepare_android_engine.sh").read_text("utf-8")

for method in ("get_version", "get_balance", "get_transfers", "create_wallet", "open_wallet", "restore_wallet_from_seed", "transfer", "relay_tx"):
    need(f'"{method}"' in rust, f"RPC allowlist missing {method}")
for method in ("start_mining", "stop_mining"):
    need(method not in rust[rust.find("fn allowed_method"):rust.find("fn atomic_safe")], f"Unsafe RPC method unexpectedly allowlisted: {method}")
need('"127.0.0.1"' in rust and '"--rpc-bind-ip"' in rust, "Wallet RPC must bind to loopback only")
need("X-Nerva-Session" in js or "x-nerva-session" in js, "Frontend session header is missing")
need('"x-nerva-session"' in rust.lower(), "Rust session-header check is missing")
need("https://appassets.androidplatform.net" in rust, "WebView origin is not allowlisted for CORS/session checks")
need('WebViewAssetLoader' in activity, "Android UI must load through WebViewAssetLoader instead of a token-serving local HTML route")
need('.route("/", get(index))' not in rust and '.route("/app.js", get(javascript))' not in rust, "Token-bearing UI must not be served to arbitrary loopback clients")
need('access-control-allow-private-network' in rust, "Local private-network preflight support is missing")
need("async fn security_headers_layer" in rust and ".layer(middleware::from_fn(security_headers_layer))" in rust, "CORS preflight responses must also get the local-network security headers")
need('replace("__SESSION_TOKEN__", sessionToken)' in activity, "Android host must inject the in-memory session token into the WebView")
need('"nerva-wallet-rpc"' in activity, "Android host does not launch the Nerva wallet-RPC engine")
need('sha256sum' in prep and '905716a117a1575c67925b929b2f2c15cafac0ff94394b4c00610448e522e401' in prep, "Official release SHA-256 verification is missing")
need('dependsOn("copyWalletWebAssets", "prepareNervaEngine", "buildRustAndroid")' in gradle, "Android preBuild does not depend on UI, engine and Rust library preparation")
need("__SESSION_TOKEN__" in html and "__API_BASE__" in html, "WebView HTML injection markers are missing")
need("fetch(API_BASE + path, options)" in js, "Frontend does not direct local API calls to the Rust service")
need('"/api/call"' in rust and '"/api/connect"' in rust and '"/api/daemon"' in rust, "Core wallet routes are missing")
need('do_not_relay:true' in js and "relay_tx" in js and "finalConfirm" in js, "Send flow must prepare, show review, and require final confirmation before broadcast")
need("node.nerva.one:17566" in rust, "Default daemon is missing")
need("digest_nonce_count" in rust and "fetch_add(1" in rust, "Digest nonce counter must be monotonic across requests")
need('"store", json!({})' in rust and "restart_engine(address.clone()).await" in rust, "Changing daemon must flush wallet state before restarting the engine")
manifest = (ROOT / "android/app/src/main/AndroidManifest.xml").read_text("utf-8")
need('android:networkSecurityConfig="@xml/network_security_config"' in manifest, "Android cleartext exception policy is not attached to the app")
need((ROOT / "android/gradlew").exists() and (ROOT / "android/gradlew.bat").exists(), "Gradle bootstrap scripts are missing")
wrapper_props = (ROOT / "android/gradle/wrapper/gradle-wrapper.properties").read_text("utf-8")
need("d725d707bfabd4dfdc958c624003b3c80accc03f7037b5122c4b1d0ef15cecab" in wrapper_props, "Gradle distribution SHA-256 pin is missing")
need("cargo test" in (ROOT / ".github/workflows/android-apk.yml").read_text("utf-8"), "CI must run Rust unit tests before building the APK")
need("allowFileAccess = false" in activity and "allowUniversalAccessFromFileURLs = false" in activity, "Unsafe WebView file access is enabled")
network_config = ROOT / "android/app/src/main/res/xml/network_security_config.xml"
need(network_config.exists(), "Android network security policy is missing")
if network_config.exists():
    net_xml = network_config.read_text("utf-8")
    need('base-config cleartextTrafficPermitted="false"' in net_xml, "Cleartext should be denied globally")
    need('<domain includeSubdomains="false">127.0.0.1</domain>' in net_xml, "Local cleartext exception should be limited to loopback")
need((ROOT / ".github/workflows/android-apk.yml").exists(), "Reproducible Android APK build workflow is missing")
for name in ("index.html", "app.js", "style.css", "LICENSE"):
    packaged = ROOT / f"android/app/src/main/assets/www/{name}"
    source = ROOT / f"web/{name}"
    need(packaged.exists(), f"Bundled WebView {name} asset is missing")
    if packaged.exists() and source.exists():
        need(packaged.read_bytes() == source.read_bytes(), f"Packaged {name} is out of sync; run Gradle copy task")


# Rust migration invariants: these assertions verify the code is wired into the workspace; they
# are not a substitute for cargo test, C++ differential tests or Android runtime validation.
core_root = ROOT / "rust-engine/crates/nerva-core/src"
wallet_root = ROOT / "rust-engine/crates/nerva-wallet/src"
need((core_root / "ringct.rs").exists(), "Rust RingCT base parser is missing")
need("pub mod ringct;" in (core_root / "lib.rs").read_text("utf-8"), "RingCT parser is not exported from nerva-core")
need("BulletproofPlus" in (core_root / "ringct.rs").read_text("utf-8"), "Current Nerva RingCT type is not represented")
need("pub fn scan_transaction(" in (core_root / "scanner.rs").read_text("utf-8"), "Full serialized-transaction output scanner is missing")
need("CommitmentMismatch" in (core_root / "ringct.rs").read_text("utf-8"), "Recovered amount commitment check is missing")
need("pub mod tracking;" in (wallet_root / "lib.rs").read_text("utf-8"), "Wallet tracking state is not exported")
tracking = (wallet_root / "tracking.rs").read_text("utf-8")
need("apply_spend_inputs" in tracking and "reconcile_chain" in tracking, "Wallet spend/reorg tracking is missing")
need("pub fn save_atomic" in tracking and "pub fn load_from_path" in tracking, "Wallet scan state persistence is missing")
need("pub fn seal_recovery_seed" in (wallet_root / "storage.rs").read_text("utf-8"), "Rust seed-based wallet restore is missing")
need("cargo test --workspace" in (ROOT / ".github/workflows/rust-engine.yml").read_text("utf-8"), "Dedicated Rust workspace test workflow is missing")

if errors:
    print("FAIL")
    for e in errors:
        print(" -", e)
    sys.exit(1)
print("PASS: wallet source invariants and Android packaging checks")
print("NOTE: static checks do not compile Rust/Gradle or prove real transaction correctness.")
