//! LUMA-X experimental recursive spend proof circuit.
//!
//! This is a research implementation candidate, not production cryptocurrency
//! code. It uses the Poseidon random oracle and Nova IVC/Spartan compression
//! provided by `nova-snark` 0.76.0. Its relation is deliberately explicit:
//! - hash-based spend-key ownership;
//! - a depth-32 hidden-index binary Merkle membership path;
//! - a linkable nullifier derived from the spend secret and note serial;
//! - 64-bit range-constrained amounts and input = output_0 + output_1 + fee;
//! - a block-height unlock constraint;
//! - output-commitment and public-transaction-digest binding;
//! - rolling digest aggregation across transactions.
//!
//! It changes Nerva's key/address and output-commitment format, does not retain
//! conventional ring signatures, and is not compatible with current Nerva
//! consensus. The chosen hash-based ownership relation is a proposal requiring
//! independent cryptanalysis. This crate does not implement Nerva's complete
//! RingCT semantics, miner/coinbase rules, unlock_time dual semantics, P2P,
//! persistent databases, wallet scanning, or consensus activation.

pub mod anchor;

use ff::{Field, PrimeField, PrimeFieldBits};
use nova_snark::frontend::{num::AllocatedNum, AllocatedBit, ConstraintSystem, LinearCombination, SynthesisError};
use nova_snark::provider::poseidon::{PoseidonConstantsCircuit, PoseidonRO, PoseidonROCircuit};
use nova_snark::traits::{circuit::StepCircuit, ROCircuitTrait, ROTrait};
use serde::{Deserialize, Serialize};

pub const MERKLE_DEPTH: usize = 32;
pub const MAX_OUTPUTS: usize = 2;

// Fixed protocol domain tags. They are allocated as constrained constants in
// the circuit, rather than untrusted witness inputs.
const D_OWNER: u64 = 0x4c_554d_4101;
const D_NOTE_COMMIT: u64 = 0x4c_554d_4102;
// New domain identifiers for the public-leaf/private-opening schema. These
// intentionally differ from the earlier experimental prototype's domains.
const D_NOTE_LEAF: u64 = 0x4c_554d_4108;
const D_MERKLE_NODE: u64 = 0x4c_554d_4104;
const D_NULLIFIER: u64 = 0x4c_554d_4105;
const D_TRANSACTION: u64 = 0x4c_554d_4109;
const D_BATCH: u64 = 0x4c_554d_410a;

/// Hash a sequence using Nova's built-in standard-strength Poseidon random
/// oracle. The domain tag is absorbed as the first field element. Do not alter
/// this parameter set or its ordering without a protocol version change.
pub fn poseidon_hash<F>(domain: u64, values: &[F]) -> F
where
    F: PrimeField + PrimeFieldBits + Serialize + for<'de> Deserialize<'de>,
{
    let constants = PoseidonConstantsCircuit::<F>::default();
    let mut ro = PoseidonRO::<F>::new(constants);
    ro.absorb(F::from(domain));
    for value in values {
        ro.absorb(*value);
    }
    // NUM_BITS preserves the canonical field representation. The circuit
    // counterpart uses squeeze_scalar() on the same Poseidon constants.
    ro.squeeze(F::NUM_BITS as usize, false)
}

pub fn owner_tag<F>(secret: F) -> F
where
    F: PrimeField + PrimeFieldBits + Serialize + for<'de> Deserialize<'de>,
{
    poseidon_hash(D_OWNER, &[secret])
}

pub fn note_commitment<F>(owner: F, serial: F, amount: u64, blind: F) -> F
where
    F: PrimeField + PrimeFieldBits + Serialize + for<'de> Deserialize<'de>,
{
    poseidon_hash(D_NOTE_COMMIT, &[owner, serial, F::from(amount), blind])
}

/// Public accumulator leaf derived only from fields visible to every node.
/// The sender/owner tag, serial, amount and blinding are openings of `commitment`
/// and are not required to construct this leaf.
pub fn note_leaf_from_commitment<F>(commitment: F, unlock_height: u64) -> F
where
    F: PrimeField + PrimeFieldBits + Serialize + for<'de> Deserialize<'de>,
{
    poseidon_hash(D_NOTE_LEAF, &[commitment, F::from(unlock_height)])
}

/// Helper for fixtures/wallet-side witness construction. The resulting leaf is
/// byte-for-byte the one a full node builds from the public output body.
pub fn note_leaf<F>(owner: F, serial: F, amount: u64, blind: F, unlock_height: u64) -> F
where
    F: PrimeField + PrimeFieldBits + Serialize + for<'de> Deserialize<'de>,
{
    let commitment = note_commitment(owner, serial, amount, blind);
    note_leaf_from_commitment(commitment, unlock_height)
}

pub fn nullifier<F>(secret: F, serial: F) -> F
where
    F: PrimeField + PrimeFieldBits + Serialize + for<'de> Deserialize<'de>,
{
    poseidon_hash(D_NULLIFIER, &[secret, serial])
}

pub fn output_commitment<F>(recipient_tag: F, serial: F, amount: u64, blind: F) -> F
where
    F: PrimeField + PrimeFieldBits + Serialize + for<'de> Deserialize<'de>,
{
    poseidon_hash(
        D_NOTE_COMMIT,
        &[recipient_tag, serial, F::from(amount), blind],
    )
}

/// Public portion of a transaction output. The recipient tag, output serial,
/// amount and blinding are private openings committed by `commitment`. Unlock
/// height remains public in this research schema.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PublicOutput<F: PrimeField> {
    /// The only output-identity value exposed in the public transaction body.
    /// Recipient tag, output serial, amount, and blinding remain private witnesses
    /// committed by this value. The receiver-scanning/address scheme is not yet
    /// implemented by this experimental circuit.
    pub commitment: F,
    pub unlock_height: u64,
}

/// Transaction values that a full node has from the public transaction body.
/// `nullifier` must be included in the node's canonical spent-nullifier set.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PublicTransaction<F: PrimeField> {
    pub nullifier: F,
    pub fee: u64,
    pub outputs: [PublicOutput<F>; MAX_OUTPUTS],
}

/// Public digest for one transaction. Ordering here MUST match the in-circuit
/// digest in `LumaSpendStep::synthesize`.
pub fn transaction_digest<F>(
    chain_tag: F,
    accumulator_root: F,
    spend_height: u64,
    transaction: &PublicTransaction<F>,
) -> F
where
    F: PrimeField + PrimeFieldBits + Serialize + for<'de> Deserialize<'de>,
{
    let o0 = transaction.outputs[0];
    let o1 = transaction.outputs[1];
    poseidon_hash(
        D_TRANSACTION,
        &[
            transaction.nullifier,
            F::from(transaction.fee),
            chain_tag,
            accumulator_root,
            F::from(spend_height),
            o0.commitment,
            F::from(o0.unlock_height),
            o1.commitment,
            F::from(o1.unlock_height),
        ],
    )
}

pub fn append_public_digest<F>(previous: F, transaction_digest: F) -> F
where
    F: PrimeField + PrimeFieldBits + Serialize + for<'de> Deserialize<'de>,
{
    poseidon_hash(D_BATCH, &[previous, transaction_digest])
}

pub fn initial_state<F: PrimeField>(root: F, chain_tag: F, spend_height: u64) -> Vec<F> {
    vec![root, F::ZERO, F::ZERO, chain_tag, F::from(spend_height)]
}

/// Derive the public state the node must compare with the recursive proof's
/// verified final state. This binding ensures hidden openings/nullifiers used
/// in the circuit correspond to public transaction-body values (assuming the
/// protocol hash is collision resistant).
pub fn expected_final_state<F>(
    root: F,
    chain_tag: F,
    spend_height: u64,
    transactions: &[PublicTransaction<F>],
) -> Vec<F>
where
    F: PrimeField + PrimeFieldBits + Serialize + for<'de> Deserialize<'de>,
{
    let mut rolling = F::ZERO;
    for tx in transactions {
        rolling = append_public_digest(
            rolling,
            transaction_digest(chain_tag, root, spend_height, tx),
        );
    }
    vec![
        root,
        rolling,
        F::from(transactions.len() as u64),
        chain_tag,
        F::from(spend_height),
    ]
}

/// One spend transition. All input note data, secret material and membership
/// paths are prover witnesses. Public transaction-body values are bound via
/// the rolling digest in the resulting Nova state.
#[derive(Clone, Debug)]
pub struct LumaSpendStep<F: PrimeField> {
    pub secret: Option<F>,
    pub serial: Option<F>,
    pub input_amount: Option<u64>,
    pub input_blind: Option<F>,
    pub input_unlock_height: Option<u64>,
    /// delta = spend_height - input_unlock_height, range constrained in-circuit.
    /// It cannot exist for a locked note (unlock_height > spend_height).
    pub unlock_delta: Option<u64>,
    pub merkle_siblings: Vec<Option<F>>,
    /// Little-endian leaf index bits; kept private to hide the output position.
    pub path_bits: Vec<Option<bool>>,
    pub fee: Option<u64>,
    pub output_amounts: [Option<u64>; MAX_OUTPUTS],
    pub output_blinds: [Option<F>; MAX_OUTPUTS],
    pub output_recipient_tags: [Option<F>; MAX_OUTPUTS],
    pub output_serials: [Option<F>; MAX_OUTPUTS],
    pub output_unlock_heights: [Option<u64>; MAX_OUTPUTS],
    /// Required witness value for range-checking the public state height z[4].
    pub spend_height: Option<u64>,
}

fn alloc_field<CS, F>(
    mut cs: CS,
    label: &'static str,
    value: Option<F>,
) -> Result<AllocatedNum<F>, SynthesisError>
where
    CS: ConstraintSystem<F>,
    F: PrimeField,
{
    AllocatedNum::alloc(cs.namespace(|| label), || {
        value.ok_or(SynthesisError::AssignmentMissing)
    })
}

/// Constrain an existing field element to the canonical unsigned 64-bit range.
/// Recomposition of 64 Boolean witnesses proves the field value cannot wrap.
fn constrain_u64<CS, F>(
    cs: &mut CS,
    label: &str,
    number: &AllocatedNum<F>,
    value: Option<u64>,
) -> Result<(), SynthesisError>
where
    CS: ConstraintSystem<F>,
    F: PrimeField,
{
    let mut bit_sum = LinearCombination::<F>::zero();
    for i in 0..64 {
        let bit_value = value.map(|v| ((v >> i) & 1) == 1);
        let bit = AllocatedBit::alloc(
            cs.namespace(|| format!("{label} bit {i}")),
            bit_value,
        )?;
        bit_sum = bit_sum + (F::from(1u64 << i), bit.get_variable());
    }
    cs.enforce(
        || format!("{label} is exactly a u64"),
        |lc| lc + number.get_variable() - &bit_sum,
        |lc| lc + CS::one(),
        |lc| lc,
    );
    Ok(())
}

fn alloc_u64<CS, F>(
    cs: &mut CS,
    label: &str,
    value: Option<u64>,
) -> Result<AllocatedNum<F>, SynthesisError>
where
    CS: ConstraintSystem<F>,
    F: PrimeField,
{
    let number = AllocatedNum::alloc(
        cs.namespace(|| format!("{label} field value")),
        || value.map(F::from).ok_or(SynthesisError::AssignmentMissing),
    )?;
    constrain_u64(cs, label, &number, value)?;
    Ok(number)
}

fn enforce_equal<CS, F>(
    cs: &mut CS,
    label: &str,
    left: &AllocatedNum<F>,
    right: &AllocatedNum<F>,
) where
    CS: ConstraintSystem<F>,
    F: PrimeField,
{
    cs.enforce(
        || label.to_string(),
        |lc| lc + left.get_variable() - right.get_variable(),
        |lc| lc + CS::one(),
        |lc| lc,
    );
}

fn hash_gadget<CS, F>(
    mut cs: CS,
    domain: u64,
    values: &[AllocatedNum<F>],
    label: &'static str,
) -> Result<AllocatedNum<F>, SynthesisError>
where
    CS: ConstraintSystem<F>,
    F: PrimeField + PrimeFieldBits + Serialize + for<'de> Deserialize<'de>,
{
    let domain_num = AllocatedNum::alloc(cs.namespace(|| "domain separator"), || {
        Ok(F::from(domain))
    })?;
    cs.enforce(
        || "domain separator is protocol constant",
        |lc| lc + domain_num.get_variable() - (F::from(domain), CS::one()),
        |lc| lc + CS::one(),
        |lc| lc,
    );

    let mut ro = PoseidonROCircuit::<F>::new(PoseidonConstantsCircuit::<F>::default());
    ro.absorb(&domain_num);
    for value in values {
        ro.absorb(value);
    }
    ro.squeeze_scalar(cs.namespace(|| label))
}

impl<F> StepCircuit<F> for LumaSpendStep<F>
where
    F: PrimeField + PrimeFieldBits + Serialize + for<'de> Deserialize<'de>,
{
    fn arity(&self) -> usize {
        5
    }

    fn synthesize<CS: ConstraintSystem<F>>(
        &self,
        cs: &mut CS,
        z: &[AllocatedNum<F>],
    ) -> Result<Vec<AllocatedNum<F>>, SynthesisError> {
        if z.len() != 5
            || self.merkle_siblings.len() != MERKLE_DEPTH
            || self.path_bits.len() != MERKLE_DEPTH
        {
            return Err(SynthesisError::Unsatisfiable(
                "invalid LumaSpendStep input shape".to_string(),
            ));
        }

        // Public recursive state: [anchor_root, rolling_tx_digest, count,
        //                          chain_tag, spend_height]. Height is fixed
        // for every spend aggregated into the same block proof.
        constrain_u64(cs, "public spend height", &z[4], self.spend_height)?;

        let secret = alloc_field(cs.namespace(|| "spend secret"), "spend secret value", self.secret)?;
        let serial = alloc_field(cs.namespace(|| "note serial"), "note serial value", self.serial)?;
        let input_blind = alloc_field(cs.namespace(|| "input blinding"), "input blinding value", self.input_blind)?;
        let input_amount = alloc_u64(cs, "input amount", self.input_amount)?;
        let input_unlock = alloc_u64(cs, "input unlock height", self.input_unlock_height)?;
        let unlock_delta = alloc_u64(cs, "unlock delta", self.unlock_delta)?;
        // Since all three operands are constrained to u64, this field equality
        // is also an integer equality (their sum is far below the field modulus).
        cs.enforce(
            || "input unlock is mature at spend height",
            |lc| lc + input_unlock.get_variable() + unlock_delta.get_variable(),
            |lc| lc + CS::one(),
            |lc| lc + z[4].get_variable(),
        );

        let owner = hash_gadget(
            cs.namespace(|| "derive owner tag"),
            D_OWNER,
            &[secret.clone()],
            "owner Poseidon",
        )?;
        let input_commitment = hash_gadget(
            cs.namespace(|| "derive input note commitment"),
            D_NOTE_COMMIT,
            &[
                owner.clone(),
                serial.clone(),
                input_amount.clone(),
                input_blind.clone(),
            ],
            "input commitment Poseidon",
        )?;
        // Important public-leaf invariant: consensus nodes can compute the leaf
        // from the public commitment and unlock height without learning owner,
        // serial, amount, or blinding. The circuit proves those private values
        // open the same public commitment.
        let leaf = hash_gadget(
            cs.namespace(|| "derive public output leaf"),
            D_NOTE_LEAF,
            &[input_commitment, input_unlock],
            "leaf Poseidon",
        )?;

        // Private-index binary Merkle membership path. At each level the bit
        // controls child ordering; both selection equations are constrained.
        let mut current = leaf;
        for level in 0..MERKLE_DEPTH {
            let sibling = alloc_field(
                cs.namespace(|| format!("membership sibling {level}")),
                "membership sibling value",
                self.merkle_siblings[level],
            )?;
            let bit_value = self.path_bits[level];
            let bit = AllocatedBit::alloc(
                cs.namespace(|| format!("private index bit {level}")),
                bit_value,
            )?;
            let current_value = current.get_value();
            let sibling_value = sibling.get_value();
            let left_value = bit_value.and_then(|b| current_value.zip(sibling_value).map(|(c, s)| if b { s } else { c }));
            let right_value = bit_value.and_then(|b| current_value.zip(sibling_value).map(|(c, s)| if b { c } else { s }));
            let left = AllocatedNum::alloc(
                cs.namespace(|| format!("merkle left child {level}")),
                || left_value.ok_or(SynthesisError::AssignmentMissing),
            )?;
            let right = AllocatedNum::alloc(
                cs.namespace(|| format!("merkle right child {level}")),
                || right_value.ok_or(SynthesisError::AssignmentMissing),
            )?;
            cs.enforce(
                || format!("merkle left selection {level}"),
                |lc| lc + bit.get_variable(),
                |lc| lc + sibling.get_variable() - current.get_variable(),
                |lc| lc + left.get_variable() - current.get_variable(),
            );
            cs.enforce(
                || format!("merkle right selection {level}"),
                |lc| lc + bit.get_variable(),
                |lc| lc + current.get_variable() - sibling.get_variable(),
                |lc| lc + right.get_variable() - sibling.get_variable(),
            );
            current = hash_gadget(
                cs.namespace(|| format!("merkle node {level}")),
                D_MERKLE_NODE,
                &[left, right],
                "membership Poseidon",
            )?;
        }
        enforce_equal(cs, "membership root equals public anchor", &current, &z[0]);

        let spend_nullifier = hash_gadget(
            cs.namespace(|| "derive linkable nullifier"),
            D_NULLIFIER,
            &[secret, serial],
            "nullifier Poseidon",
        )?;

        let fee = alloc_u64(cs, "transaction fee", self.fee)?;
        let mut output_commitments: Vec<AllocatedNum<F>> = Vec::with_capacity(MAX_OUTPUTS);
        let mut output_unlocks: Vec<AllocatedNum<F>> = Vec::with_capacity(MAX_OUTPUTS);
        let mut output_amounts: Vec<AllocatedNum<F>> = Vec::with_capacity(MAX_OUTPUTS);
        for i in 0..MAX_OUTPUTS {
            let amount = alloc_u64(cs, &format!("output {i} amount"), self.output_amounts[i])?;
            let blind = alloc_field(
                cs.namespace(|| format!("output {i} blinding")),
                "output blinding value",
                self.output_blinds[i],
            )?;
            let recipient = alloc_field(
                cs.namespace(|| format!("output {i} recipient tag")),
                "output recipient tag value",
                self.output_recipient_tags[i],
            )?;
            let output_serial = alloc_field(
                cs.namespace(|| format!("output {i} serial")),
                "output serial value",
                self.output_serials[i],
            )?;
            let unlock = alloc_u64(
                cs,
                &format!("output {i} unlock height"),
                self.output_unlock_heights[i],
            )?;
            let commitment = hash_gadget(
                cs.namespace(|| format!("output {i} commitment")),
                D_NOTE_COMMIT,
                &[recipient.clone(), output_serial.clone(), amount.clone(), blind],
                "output commitment Poseidon",
            )?;
            output_commitments.push(commitment);
            output_unlocks.push(unlock);
            output_amounts.push(amount);
        }

        // One hidden input funds exactly two output slots plus the public fee.
        // Zero-valued output slots are allowed but still need canonical fields.
        cs.enforce(
            || "value conservation: input = outputs + fee",
            |lc| {
                lc + input_amount.get_variable()
                    - output_amounts[0].get_variable()
                    - output_amounts[1].get_variable()
                    - fee.get_variable()
            },
            |lc| lc + CS::one(),
            |lc| lc,
        );

        // Digest public transaction data together with the derived nullifier.
        // A full node independently hashes the visible transaction fields and
        // compares its rolling digest to the proof's final state.
        let tx_digest = hash_gadget(
            cs.namespace(|| "public transaction digest"),
            D_TRANSACTION,
            &[
                spend_nullifier,
                fee,
                z[3].clone(),
                z[0].clone(),
                z[4].clone(),
                output_commitments[0].clone(),
                output_unlocks[0].clone(),
                output_commitments[1].clone(),
                output_unlocks[1].clone(),
            ],
            "transaction digest Poseidon",
        )?;
        let rolling_digest = hash_gadget(
            cs.namespace(|| "rolling batch digest"),
            D_BATCH,
            &[z[1].clone(), tx_digest],
            "batch digest Poseidon",
        )?;
        let next_count = AllocatedNum::alloc(
            cs.namespace(|| "next transaction count"),
            || z[2].get_value().map(|v| v + F::ONE).ok_or(SynthesisError::AssignmentMissing),
        )?;
        cs.enforce(
            || "transaction count increments by one",
            |lc| lc + z[2].get_variable() + CS::one(),
            |lc| lc + CS::one(),
            |lc| lc + next_count.get_variable(),
        );

        Ok(vec![z[0].clone(), rolling_digest, next_count, z[3].clone(), z[4].clone()])
    }
}

/// Sparse-tree defaults for a binary 2^32-leaf tree where the empty leaf is 0.
pub fn empty_hashes<F>(depth: usize) -> Vec<F>
where
    F: PrimeField + PrimeFieldBits + Serialize + for<'de> Deserialize<'de>,
{
    let mut defaults = vec![F::ZERO];
    for level in 0..depth {
        let last = defaults[level];
        defaults.push(poseidon_hash(D_MERKLE_NODE, &[last, last]));
    }
    defaults
}

pub fn compute_merkle_root<F>(leaf: F, siblings: &[F], bits: &[bool]) -> Option<F>
where
    F: PrimeField + PrimeFieldBits + Serialize + for<'de> Deserialize<'de>,
{
    if siblings.len() != bits.len() || siblings.is_empty() {
        return None;
    }
    let mut current = leaf;
    for (sibling, bit) in siblings.iter().zip(bits.iter()) {
        current = if *bit {
            poseidon_hash(D_MERKLE_NODE, &[*sibling, current])
        } else {
            poseidon_hash(D_MERKLE_NODE, &[current, *sibling])
        };
    }
    Some(current)
}

/// Build two deterministic test spends whose leaves share one valid depth-32
/// sparse-tree root. Test values are fixtures only, never real key material.
pub fn demo_batch<F>() -> (F, F, u64, Vec<LumaSpendStep<F>>, Vec<PublicTransaction<F>>)
where
    F: PrimeField + PrimeFieldBits + Serialize + for<'de> Deserialize<'de>,
{
    let height = 100u64;
    let chain_tag = F::from(0x4c_554d_4158u64);
    let secrets = [F::from(101u64), F::from(202u64)];
    let serials = [F::from(11u64), F::from(22u64)];
    let amounts = [50u64, 23u64];
    let blinds = [F::from(555u64), F::from(666u64)];
    let unlocks = [50u64, 75u64];
    let owners = [owner_tag(secrets[0]), owner_tag(secrets[1])];
    let leaves = [
        note_leaf(owners[0], serials[0], amounts[0], blinds[0], unlocks[0]),
        note_leaf(owners[1], serials[1], amounts[1], blinds[1], unlocks[1]),
    ];
    let defaults = empty_hashes::<F>(MERKLE_DEPTH);
    let mut root = poseidon_hash(D_MERKLE_NODE, &[leaves[0], leaves[1]]);
    for level in 1..MERKLE_DEPTH {
        root = poseidon_hash(D_MERKLE_NODE, &[root, defaults[level]]);
    }

    let output_amounts = [[30u64, 19u64], [11u64, 11u64]];
    let fees = [1u64, 1u64];
    let output_blinds = [
        [F::from(333u64), F::from(444u64)],
        [F::from(777u64), F::from(888u64)],
    ];
    let recipient_tags = [
        [F::from(1001u64), F::from(1002u64)],
        [F::from(2001u64), F::from(2002u64)],
    ];
    let output_serials = [
        [F::from(9001u64), F::from(9002u64)],
        [F::from(9101u64), F::from(9102u64)],
    ];
    let output_unlocks = [[0u64, 100u64], [100u64, 0u64]];

    let mut steps = Vec::with_capacity(2);
    let mut txs = Vec::with_capacity(2);
    for i in 0..2 {
        let sibling_leaf = leaves[1 - i];
        let mut siblings = vec![sibling_leaf];
        siblings.extend(defaults[1..MERKLE_DEPTH].iter().copied());
        let mut bits = vec![false; MERKLE_DEPTH];
        if i == 1 { bits[0] = true; }
        let path_bits = bits.iter().copied().map(Some).collect::<Vec<_>>();
        let merkle_siblings = siblings.iter().copied().map(Some).collect::<Vec<_>>();
        debug_assert_eq!(compute_merkle_root(leaves[i], &siblings, &bits), Some(root));

        let out0_commit = output_commitment(recipient_tags[i][0], output_serials[i][0], output_amounts[i][0], output_blinds[i][0]);
        let out1_commit = output_commitment(recipient_tags[i][1], output_serials[i][1], output_amounts[i][1], output_blinds[i][1]);
        let tx = PublicTransaction {
            nullifier: nullifier(secrets[i], serials[i]),
            fee: fees[i],
            outputs: [
                PublicOutput { unlock_height: output_unlocks[i][0], commitment: out0_commit },
                PublicOutput { unlock_height: output_unlocks[i][1], commitment: out1_commit },
            ],
        };
        let step = LumaSpendStep {
            secret: Some(secrets[i]),
            serial: Some(serials[i]),
            input_amount: Some(amounts[i]),
            input_blind: Some(blinds[i]),
            input_unlock_height: Some(unlocks[i]),
            unlock_delta: Some(height - unlocks[i]),
            merkle_siblings,
            path_bits,
            fee: Some(fees[i]),
            output_amounts: [Some(output_amounts[i][0]), Some(output_amounts[i][1])],
            output_blinds: [Some(output_blinds[i][0]), Some(output_blinds[i][1])],
            output_recipient_tags: [Some(recipient_tags[i][0]), Some(recipient_tags[i][1])],
            output_serials: [Some(output_serials[i][0]), Some(output_serials[i][1])],
            output_unlock_heights: [Some(output_unlocks[i][0]), Some(output_unlocks[i][1])],
            spend_height: Some(height),
        };
        txs.push(tx);
        steps.push(step);
    }
    (root, chain_tag, height, steps, txs)
}

#[cfg(test)]
mod tests {
    use super::*;
    use nova_snark::{
        nova::{CompressedSNARK, PublicParams, RecursiveSNARK},
        provider::{PallasEngine, VestaEngine, ipa_pc},
        spartan::snark::RelaxedR1CSSNARK,
        traits::{Engine, snark::RelaxedR1CSSNARKTrait},
    };

    type E1 = PallasEngine;
    type E2 = VestaEngine;
    type F = <E1 as Engine>::Scalar;
    type C = LumaSpendStep<F>;
    type EE1 = ipa_pc::EvaluationEngine<E1>;
    type EE2 = ipa_pc::EvaluationEngine<E2>;
    type S1 = RelaxedR1CSSNARK<E1, EE1>;
    type S2 = RelaxedR1CSSNARK<E2, EE2>;

    fn reject_step(pp: &PublicParams<E1, E2, C>, shape: &C, z0: &[F], bad: C) {
        let mut proof = RecursiveSNARK::<E1, E2, C>::new(pp, shape, z0).expect("new proof");
        assert!(proof.prove_step(pp, &bad).is_err(), "malformed spend witness accepted");
    }

    #[test]
    fn recursive_spend_proof_and_adversarial_witnesses() {
        let (root, chain_tag, height, steps, txs) = demo_batch::<F>();
        // The demo uses a trusted synthetic checkpoint. In production this record
        // MUST come from Nerva's active-chain database, not transaction input.
        let registry = anchor::CanonicalAnchorRegistry::from_trusted_checkpoint(
            chain_tag,
            anchor::AnchorRecord {
                height: height.saturating_sub(1),
                chain_tag,
                accumulator_root: root,
                block_hash: [0x42; 32],
                parent_hash: [0x41; 32],
            },
        ).expect("synthetic active-chain checkpoint");
        assert!(registry.validate_anchor(root, chain_tag, height, 2), "anchor root is not canonical");
        assert!(!registry.validate_anchor(F::from(123456u64), chain_tag, height, 2), "arbitrary root was accepted");
        let z0 = initial_state(root, chain_tag, height);
        let shape = steps[0].clone();
        let pp = PublicParams::<E1, E2, C>::setup(&shape, &*S1::ck_floor(), &*S2::ck_floor())
            .expect("Nova public parameter setup");

        let mut recursive = RecursiveSNARK::<E1, E2, C>::new(&pp, &shape, &z0)
            .expect("recursive proof init");
        for step in &steps {
            recursive.prove_step(&pp, step).expect("valid spend must prove");
        }
        let expected = expected_final_state(root, chain_tag, height, &txs);
        let recursive_out = recursive.verify(&pp, steps.len(), &z0).expect("recursive verification");
        assert_eq!(recursive_out, expected);

        // Compress with Spartan over the Pallas/Vesta cycle and transparent IPA
        // commitments; this path has no KZG/Powers-of-Tau trusted setup.
        let (pk, vk) = CompressedSNARK::<_, _, _, S1, S2>::setup(&pp).expect("compressed setup");
        let compressed = CompressedSNARK::<_, _, _, S1, S2>::prove(&pp, &pk, &recursive)
            .expect("compressed proof");
        let compressed_out = compressed.verify(&vk, steps.len(), &z0).expect("compressed verification");
        assert_eq!(compressed_out, expected);

        let mut wrong_secret = steps[0].clone();
        wrong_secret.secret = Some(F::from(999_999u64));
        reject_step(&pp, &shape, &z0, wrong_secret);

        let mut wrong_path = steps[0].clone();
        wrong_path.merkle_siblings[7] = Some(F::from(4242u64));
        reject_step(&pp, &shape, &z0, wrong_path);

        let mut wrong_balance = steps[0].clone();
        wrong_balance.output_amounts[0] = Some(31);
        reject_step(&pp, &shape, &z0, wrong_balance);

        let mut wrong_fee = steps[0].clone();
        wrong_fee.fee = Some(2);
        reject_step(&pp, &shape, &z0, wrong_fee);

        let mut locked_note = steps[0].clone();
        locked_note.input_unlock_height = Some(height + 1);
        locked_note.unlock_delta = Some(0);
        reject_step(&pp, &shape, &z0, locked_note);

        // A changed public transaction body produces a different terminal digest.
        let mut tampered_txs = txs.clone();
        tampered_txs[0].outputs[0].commitment += F::ONE;
        assert_ne!(expected_final_state(root, chain_tag, height, &tampered_txs), expected);
    }

    #[test]
    fn output_leaf_is_buildable_from_public_output_fields_only() {
        let owner = F::from(123u64);
        let serial = F::from(456u64);
        let amount = 789u64;
        let blind = F::from(321u64);
        let unlock = 55u64;
        let commitment = note_commitment(owner, serial, amount, blind);
        assert_eq!(
            note_leaf(owner, serial, amount, blind, unlock),
            note_leaf_from_commitment(commitment, unlock),
        );
    }

    #[test]
    fn demo_paths_are_consistent_with_the_same_anchor() {
        let (root, _chain, _height, steps, _txs) = demo_batch::<F>();
        for step in steps {
            let secret = step.secret.unwrap();
            let serial = step.serial.unwrap();
            let owner = owner_tag(secret);
            let leaf = note_leaf(owner, serial, step.input_amount.unwrap(), step.input_blind.unwrap(), step.input_unlock_height.unwrap());
            let siblings = step.merkle_siblings.iter().map(|x| x.unwrap()).collect::<Vec<_>>();
            let bits = step.path_bits.iter().map(|x| x.unwrap()).collect::<Vec<_>>();
            assert_eq!(compute_merkle_root(leaf, &siblings, &bits), Some(root));
        }
    }
}
